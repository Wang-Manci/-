"""Full activation engine package."""

