from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class EdgeType(str, Enum):
    NAVIGATION = "navigation"
    QUERY = "query"
    SUBMIT = "submit"
    RECOVERY = "recovery"
    DECORATION = "decoration"


class ExecutionResult(str, Enum):
    EFFECTIVE = "effective"
    NO_CHANGE = "no_change"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


class SceneType(str, Enum):
    FEED_HOME = "feed_home"
    VIDEO_DETAIL = "video_detail"
    LIVE_ROOM = "live_room"
    SEARCH_ENTRY = "search_entry"
    SEARCH_RESULT = "search_result"
    MINIAPP_RESULT = "miniapp_result"
    MINIAPP_PAGE = "miniapp_page"
    USER_PROFILE = "user_profile"
    COMMENT_PANEL = "comment_panel"
    MESSAGE_INBOX = "message_inbox"
    MESSAGE_THREAD = "message_thread"
    SHOP_HOME = "shop_home"
    PRODUCT_DETAIL = "product_detail"
    SHARE_PANEL = "share_panel"
    SPLASH_OR_RESTART = "splash_or_restart"
    OUT_OF_SCOPE = "out_of_scope"
    UNKNOWN = "unknown"


@dataclass(slots=True)
class ControlNode:
    control_id: str
    text: str
    type_name: str
    clickable: bool
    event_handler: str = ""
    route_target: str = ""
    resource_id: str = ""
    bounds: str = ""
    extra: Dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class PageSnapshot:
    page_name: str
    route_name: str
    source_digest: str
    title: str
    controls: List[ControlNode]
    form_fields: List[str] = field(default_factory=list)
    component_types: List[str] = field(default_factory=list)
    raw_source_excerpt: str = ""
    popup_type: str = ""
    signature: str = ""
    package_name: str = ""


@dataclass(slots=True)
class ActionCandidate:
    semantic_role: str
    display_name: str
    control_id: str
    edge_type: EdgeType
    priority: int
    repeatable: bool = False
    expected_scene: str = ""
    source_text: str = ""
    novelty_key: str = ""
    goal_hint: str = ""


@dataclass(slots=True)
class SceneObservation:
    scene_type: SceneType
    confidence: float
    package_name: str
    activity_name: str
    keywords: List[str] = field(default_factory=list)


@dataclass(slots=True)
class NetworkEvent:
    url: str
    method: str
    domain: str
    request_type: str
    timestamp_ms: int
    is_noise: bool = False
    noise_reason: str = ""


@dataclass(slots=True)
class FlowWindow:
    flow_window_id: str
    edge_id: str
    page_signature: str
    start_ts_ms: int
    end_ts_ms: int = 0
    baseline_delta: int = 0
    events: List[NetworkEvent] = field(default_factory=list)
    noise_score: float = 0.0
    noise_reason: List[str] = field(default_factory=list)
    traffic_accuracy_grade: str = "D"


@dataclass(slots=True)
class FlowActionRecord:
    step_index: int
    scene_type: str
    action_semantic: str
    action_label: str
    control_id: str
    result: str
    target_scene_type: str
    duration_ms: int
    notes: str = ""


@dataclass(slots=True)
class TrafficBundleRecord:
    bundle_id: str
    flow_id: str
    flow_name: str
    start_scene: str
    final_scene: str
    request_count: int
    noise_count: int
    business_count: int
    primary_domain: str
    grade: str
    requests: List[Dict[str, str]] = field(default_factory=list)
    payload_path: str = ""


@dataclass(slots=True)
class FlowRecord:
    flow_id: str
    flow_name: str
    description: str
    entry_scene: str
    final_scene: str
    status: str
    clicked_buttons: List[str] = field(default_factory=list)
    actions: List[FlowActionRecord] = field(default_factory=list)
    bundle_id: str = ""
    rollback_count: int = 0
    duration_ms: int = 0
    score: float = 0.0
    notes: List[str] = field(default_factory=list)
    query_text: str = ""
    flow_signature: str = ""
    flow_goal: str = ""
    bundle: Optional[TrafficBundleRecord] = None


@dataclass(slots=True)
class RoundRecord:
    round_index: int
    round_name: str
    flows: List[FlowRecord] = field(default_factory=list)
    bundles: List[TrafficBundleRecord] = field(default_factory=list)
    total_score: float = 0.0
    issues: List[str] = field(default_factory=list)
    selected: bool = False


@dataclass(slots=True)
class ChainRecord:
    chain_id: str
    root_page: str
    scene_history: List[str] = field(default_factory=list)
    flows: List[FlowRecord] = field(default_factory=list)
    bundles: List[TrafficBundleRecord] = field(default_factory=list)
    rounds: List[RoundRecord] = field(default_factory=list)
    chain_goal: str = ""
    chain_status: str = "running"
    unresolved_points: List[str] = field(default_factory=list)


@dataclass(slots=True)
class AnalysisEvidence:
    chain_record: Optional[ChainRecord] = None
    prompt_questions: List[str] = field(default_factory=list)


@dataclass(slots=True)
class AnalysisResult:
    title: str
    summary: str
    confidence: float
    chain_goal: str = ""
    chain_steps: List[str] = field(default_factory=list)
    critical_edges: List[str] = field(default_factory=list)
    traffic_value_edges: List[str] = field(default_factory=list)
    noise_edges: List[str] = field(default_factory=list)
    unresolved_points: List[str] = field(default_factory=list)
