"""Automation adapters."""

