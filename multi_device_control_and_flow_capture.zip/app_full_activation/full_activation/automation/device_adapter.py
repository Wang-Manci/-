from __future__ import annotations

import json
import subprocess
import time
from abc import ABC, abstractmethod
from copy import deepcopy
from pathlib import Path
from typing import Dict, List

from full_activation.config import DeviceConfig
from full_activation.models import ControlNode, PageSnapshot


class DeviceAdapter(ABC):
    """Abstraction for code-aware mobile automation drivers."""

    @abstractmethod
    def get_current_page(self) -> PageSnapshot:
        """Return a page snapshot built from source and control metadata."""

    @abstractmethod
    def click_control(self, control_id: str) -> None:
        """Execute one control click."""

    @abstractmethod
    def input_text(self, control_id: str, value: str) -> None:
        """Fill text into a form field."""

    @abstractmethod
    def go_back(self) -> None:
        """Recover to the previous page when the branch is done."""

    @abstractmethod
    def recover_target_app(self, reason: str = "") -> bool:
        """Try to bring the target app back to foreground and return whether it succeeded."""


class MockDeviceAdapter(DeviceAdapter):
    """A deterministic in-memory app graph used for local verification."""

    def __init__(self) -> None:
        self._pages: Dict[str, Dict[str, object]] = {
            "home": {
                "snapshot": PageSnapshot(
                    page_name="首页",
                    route_name="home",
                    source_digest="src-home-v1",
                    title="APP首页",
                    component_types=["Banner", "Button", "NavTab"],
                    controls=[
                        ControlNode("c1", "立即体验", "Button", True, "goFeature", "feature"),
                        ControlNode("c2", "搜索", "Button", True, "doSearch", ""),
                        ControlNode("c3", "关闭弹窗", "Button", True, "closePopup", ""),
                    ],
                ),
                "transitions": {"c1": "feature", "c2": "search", "c3": "home"},
            },
            "feature": {
                "snapshot": PageSnapshot(
                    page_name="功能页",
                    route_name="feature",
                    source_digest="src-feature-v1",
                    title="功能办理",
                    component_types=["Form", "Button", "Input"],
                    form_fields=["name", "phone"],
                    controls=[
                        ControlNode("f1", "姓名", "Input", False),
                        ControlNode("f2", "手机号", "Input", False),
                        ControlNode("f3", "下一步", "Button", True, "goConfirm", "confirm"),
                    ],
                ),
                "transitions": {"f3": "confirm"},
            },
            "confirm": {
                "snapshot": PageSnapshot(
                    page_name="确认页",
                    route_name="confirm",
                    source_digest="src-confirm-v1",
                    title="确认信息",
                    component_types=["Summary", "Button"],
                    controls=[
                        ControlNode("k1", "确认提交", "Button", True, "submitOrder", "result"),
                        ControlNode("k2", "返回", "Button", True, "goBack", "feature"),
                    ],
                ),
                "transitions": {"k1": "result", "k2": "feature"},
            },
            "search": {
                "snapshot": PageSnapshot(
                    page_name="搜索页",
                    route_name="search",
                    source_digest="src-search-v1",
                    title="搜索服务",
                    component_types=["Input", "Button", "List"],
                    form_fields=["search"],
                    controls=[
                        ControlNode("s1", "立即搜索", "Button", True, "submitSearch", ""),
                    ],
                ),
                "transitions": {"s1": "search"},
            },
            "result": {
                "snapshot": PageSnapshot(
                    page_name="结果页",
                    route_name="result",
                    source_digest="src-result-v1",
                    title="提交成功",
                    component_types=["Result", "Button"],
                    controls=[
                        ControlNode("r1", "完成", "Button", True, "finish", "home"),
                    ],
                ),
                "transitions": {"r1": "home"},
            },
        }
        self._stack: List[str] = ["home"]

    def get_current_page(self) -> PageSnapshot:
        page_key = self._stack[-1]
        return deepcopy(self._pages[page_key]["snapshot"])

    def click_control(self, control_id: str) -> None:
        page_key = self._stack[-1]
        next_page = self._pages[page_key]["transitions"].get(control_id, page_key)
        if next_page == page_key:
            return
        self._stack.append(next_page)

    def input_text(self, control_id: str, value: str) -> None:
        _ = (control_id, value)

    def go_back(self) -> None:
        if len(self._stack) > 1:
            self._stack.pop()

    def recover_target_app(self, reason: str = "") -> bool:
        _ = reason
        return False


class AppiumDeviceAdapter(DeviceAdapter):
    """A real device adapter backed by Appium."""

    def __init__(self, config: DeviceConfig) -> None:
        self.config = config
        self.driver = self._create_driver()
        self.debug_path = Path("output") / "page_debug.json"
        self.runtime_log_path = Path("output") / "runtime_debug.log"
        self.page_source_dir = Path("output") / "page_sources"
        self._did_initial_wait = False
        self._snapshot_counter = 0

    def get_current_page(self) -> PageSnapshot:
        self._ensure_target_app_context()
        initial_activity = getattr(self.driver, "current_activity", "") or ""
        self._wait_for_ready_page(initial_only=True, activity_hint=initial_activity)
        controls: List[ControlNode] = []
        form_fields: List[str] = []
        component_types: List[str] = []
        activity = getattr(self.driver, "current_activity", "") or ""
        package_name = getattr(self.driver, "current_package", "") or self.config.app_package or ""
        effective_activity = self._resolve_effective_activity(activity, initial_activity)
        self._snapshot_counter += 1
        self._log(
            f"snapshot-start activity={activity} effective_activity={effective_activity} package={package_name or '-'}"
        )
        try:
            page_source = self.driver.page_source
        except Exception as exc:
            self._log(f"page-source-failed activity={initial_activity or '-'} error={exc}")
            page_source = ""

        if "android:id/aerr_wait" in page_source or "android:id/aerr_close" in page_source:
            self._log("anr-dialog-detected action=close_and_recover")
            try:
                self.driver.find_element(by="id", value="android:id/aerr_close").click()
                time.sleep(1.0)
            except Exception:
                try:
                    self.driver.find_element(by="id", value="android:id/aerr_wait").click()
                    time.sleep(1.0)
                except Exception:
                    pass
            self.recover_target_app(reason="anr_dialog")
            try:
                page_source = self.driver.page_source
            except Exception as exc:
                self._log(f"page-source-after-anr-failed error={exc}")
                page_source = ""

        self._dump_page_source(effective_activity, page_source)

        snapshot_elements = self._find_snapshot_elements()
        for index, element in enumerate(snapshot_elements):
            control_id = self._build_control_id(element, index)
            text = self._read_element_attr(element, "text")
            if not text:
                text = self._read_element_attr(element, "content-desc")
            class_name = self._read_element_attr(element, "className") or self._read_element_attr(element, "class")
            resource_id = self._read_element_attr(element, "resource-id")
            clickable = self._read_element_attr(element, "clickable") == "true"
            bounds = self._read_element_attr(element, "bounds")
            route_target = self._read_element_attr(element, "hint")
            if class_name and class_name not in component_types:
                component_types.append(class_name)

            controls.append(
                ControlNode(
                    control_id=control_id,
                    text=text,
                    type_name=class_name or "Unknown",
                    clickable=clickable,
                    resource_id=resource_id,
                    bounds=bounds,
                    route_target=route_target,
                )
            )
            if "EditText" in (class_name or ""):
                form_fields.append(control_id)

        meaningful_controls = [
            control for control in controls
            if (control.text or "").strip() or (control.resource_id or "").strip()
        ]
        home_fallback_controls = []
        if len(meaningful_controls) < 3:
            home_fallback_controls = self._build_home_fallback_controls(effective_activity, controls)
        if home_fallback_controls:
            controls.extend(home_fallback_controls)
            for control in home_fallback_controls:
                if control.type_name not in component_types:
                    component_types.append(control.type_name)
            self._log(
                f"snapshot-home-fallback-controls injected={len(home_fallback_controls)} activity={activity} effective_activity={effective_activity}"
            )
        fallback_controls = self._build_video_fallback_controls(effective_activity, controls)
        if fallback_controls:
            controls.extend(fallback_controls)
            for control in fallback_controls:
                if control.type_name not in component_types:
                    component_types.append(control.type_name)
            self._log(
                f"snapshot-fallback-controls injected={len(fallback_controls)} activity={activity} effective_activity={effective_activity}"
            )
        home_fallback_controls = []
        if "splash" not in effective_activity.lower():
            home_fallback_controls = self._build_home_fallback_controls(effective_activity, controls)
        if home_fallback_controls:
            controls.extend(home_fallback_controls)
            for control in home_fallback_controls:
                if control.type_name not in component_types:
                    component_types.append(control.type_name)
            self._log(
                f"snapshot-home-fallback-controls injected={len(home_fallback_controls)} activity={activity} effective_activity={effective_activity}"
            )
        self._log(
            f"snapshot-collected activity={activity} effective_activity={effective_activity} controls={len(controls)} form_fields={len(form_fields)}"
        )

        page_name = effective_activity or self.config.app_activity or "unknown"
        snapshot = PageSnapshot(
            page_name=page_name,
            route_name=page_name,
            source_digest=str(hash(page_source)),
            title=page_name,
            controls=controls,
            form_fields=form_fields,
            component_types=component_types,
            raw_source_excerpt=page_source[:1000],
            package_name=package_name,
        )
        self._write_debug_snapshot(snapshot, activity, page_source)
        return snapshot

    def click_control(self, control_id: str) -> None:
        self._log(f"click-control control_id={control_id}")
        self._find_element(control_id).click()

    def input_text(self, control_id: str, value: str) -> None:
        self._log(f"input-text control_id={control_id}")
        element = self._find_element(control_id)
        element.clear()
        element.send_keys(value)
        lowered = control_id.lower()
        if any(token in lowered for token in ("search", "搜", "query", "edit")):
            try:
                self.driver.press_keycode(66)
                self._log("input-text-submit-enter")
            except Exception:
                pass

    def go_back(self) -> None:
        self._log("go-back")
        self.driver.back()

    def recover_target_app(self, reason: str = "") -> bool:
        self._log(f"recover-target-app reason={reason or 'unknown'}")
        self._did_initial_wait = False
        recovered = False
        force_restart = reason.startswith("prepare_") or reason.startswith("force_home") or reason in {
            "out_of_scope_package",
            "anr_dialog",
        }
        try:
            if not force_restart and hasattr(self.driver, "activate_app"):
                self.driver.activate_app(self.config.app_package)
                time.sleep(1.2)
            current_package = getattr(self.driver, "current_package", "") or ""
            current_activity = getattr(self.driver, "current_activity", "") or ""
            recovered = (not force_restart) and current_package == self.config.app_package and "splash" not in current_activity.lower()
            if recovered:
                self._did_initial_wait = True
                self._log(
                    f"recover-target-app-success mode=activate_app package={current_package} activity={current_activity}"
                )
                return True
        except Exception as exc:
            self._log(f"recover-target-app-activate-failed error={exc}")

        try:
            if hasattr(self.driver, "start_activity"):
                previous_activity = getattr(self.driver, "current_activity", "") or ""
                self.driver.start_activity(self.config.app_package, self.config.app_activity)
                time.sleep(2.0)
            current_package = getattr(self.driver, "current_package", "") or ""
            current_activity = getattr(self.driver, "current_activity", "") or ""
            recovered = current_package == self.config.app_package and (
                ("previous_activity" in locals() and current_activity != previous_activity)
                or "splash" in current_activity.lower()
            )
            if recovered:
                self._did_initial_wait = True
                self._log(
                    f"recover-target-app-success mode=start_activity package={current_package} activity={current_activity}"
                )
                return True
        except Exception as exc:
            self._log(f"recover-target-app-start-activity-failed error={exc}")
        try:
            adb_command = ["adb"]
            if self.config.udid:
                adb_command.extend(["-s", self.config.udid])
            adb_command.extend(
                [
                    "shell",
                    "am",
                    "start",
                    "-n",
                    f"{self.config.app_package}/{self.config.app_activity}",
                ]
            )
            completed = subprocess.run(adb_command, capture_output=True, text=True, timeout=15)
            if completed.returncode == 0:
                time.sleep(2.2)
                current_package = getattr(self.driver, "current_package", "") or ""
                current_activity = getattr(self.driver, "current_activity", "") or ""
                recovered = current_package == self.config.app_package
                if recovered:
                    self._did_initial_wait = True
                    self._log(
                        f"recover-target-app-success mode=adb_am_start package={current_package} activity={current_activity}"
                    )
                    return True
            else:
                self._log(f"recover-target-app-adb-failed code={completed.returncode} stderr={completed.stderr.strip()}")
        except Exception as exc:
            self._log(f"recover-target-app-adb-exception error={exc}")
        self._log("recover-target-app-failed")
        return False

    def _create_driver(self):
        try:
            from appium import webdriver
            from appium.options.android import UiAutomator2Options
        except ImportError as exc:
            raise RuntimeError("Appium Python client is not installed. Run: pip install Appium-Python-Client") from exc

        if not self.config.app_package or not self.config.app_activity:
            raise ValueError("DeviceConfig.app_package and DeviceConfig.app_activity are required when use_mock=False")

        capabilities = {
            "platformName": self.config.platform_name,
            "automationName": self.config.automation_name,
            "deviceName": self.config.device_name,
            "appPackage": self.config.app_package,
            "appActivity": self.config.app_activity,
            "noReset": self.config.no_reset,
            "newCommandTimeout": self.config.new_command_timeout,
        }
        if self.config.udid:
            capabilities["udid"] = self.config.udid

        options = UiAutomator2Options().load_capabilities(capabilities)
        last_error: Exception | None = None
        for attempt in range(2):
            try:
                return webdriver.Remote(self.config.server_url, options=options)
            except Exception as exc:
                last_error = exc
                error_text = str(exc).lower()
                if "invalidsessionid" not in error_text and "session identified by" not in error_text:
                    raise
                time.sleep(1.5)
        assert last_error is not None
        raise last_error

    def _find_snapshot_elements(self):
        try:
            elements = self.driver.find_elements(
                by="xpath",
                value="//*[@clickable='true' or contains(@class, 'EditText') or @resource-id or @text or @content-desc]",
            )
        except Exception as exc:
            self._log(f"find-snapshot-elements-failed error={exc}")
            return []
        self._log_raw_element_preview(elements)
        filtered = []
        for element in elements:
            class_name = self._read_element_attr(element, "className") or self._read_element_attr(element, "class")
            clickable = self._read_element_attr(element, "clickable") == "true"
            resource_id = self._read_element_attr(element, "resource-id")
            text = self._read_element_attr(element, "text") or self._read_element_attr(element, "content-desc")
            is_input = "EditText" in (class_name or "")
            is_visible = self._read_element_attr(element, "displayed") != "false"
            is_enabled = self._read_element_attr(element, "enabled") != "false"
            bounds = self._read_element_attr(element, "bounds")

            # Keep only actionable elements and drop blank structural wrappers.
            if not (clickable or is_input):
                continue
            if not is_visible or not is_enabled:
                continue
            if not (resource_id or text or is_input):
                continue
            if self._is_structural_container(resource_id, class_name, text, bounds):
                continue
            filtered.append(element)
        self._log(f"find-snapshot-elements raw={len(elements)} filtered={len(filtered)}")
        return filtered

    def _find_element(self, control_id: str):
        if control_id.startswith("resource-id:"):
            resource_id = control_id.split(":", 1)[1]
            try:
                return self.driver.find_element(by="id", value=resource_id)
            except Exception:
                pass
        if control_id.startswith("accessibility:"):
            label = control_id.split(":", 1)[1]
            try:
                return self.driver.find_element(by="accessibility id", value=label)
            except Exception:
                pass
        if control_id.startswith("text:"):
            text = control_id.split(":", 1)[1]
            try:
                return self.driver.find_element(by="xpath", value=f"//*[@text={self._xpath_literal(text)}]")
            except Exception:
                pass
        if control_id.startswith("bounds:"):
            bounds = control_id.split(":", 1)[1]
            self._tap_bounds_center(bounds)
            return _CoordinateTapSentinel()
        if control_id.startswith("xpath-index:"):
            index = int(control_id.split(":", 1)[1])
            elements = self._find_snapshot_elements()
            if 0 <= index < len(elements):
                return elements[index]
        return self.driver.find_element(by="id", value=control_id)

    def _build_control_id(self, element, index: int) -> str:
        resource_id = self._read_element_attr(element, "resource-id")
        bounds = self._read_element_attr(element, "bounds")
        if resource_id.endswith(":id/c18") and bounds:
            return f"bounds:{bounds}"
        if resource_id.endswith(":id/d-e") and bounds:
            return f"bounds:{bounds}"
        if resource_id and resource_id.lower() != "null":
            return f"resource-id:{resource_id}"
        content_desc = self._read_element_attr(element, "content-desc")
        if content_desc:
            return f"accessibility:{content_desc}"
        text = self._read_element_attr(element, "text")
        if text:
            return f"text:{text}"
        if bounds:
            return f"bounds:{bounds}"
        return f"xpath-index:{index}"

    @staticmethod
    def _read_element_attr(element, name: str) -> str:
        try:
            value = element.get_attribute(name)
        except Exception:
            return ""
        value = value or ""
        if isinstance(value, str) and value.strip().lower() == "null":
            return ""
        return value

    @staticmethod
    def _xpath_literal(value: str) -> str:
        if '"' not in value:
            return f'"{value}"'
        if "'" not in value:
            return f"'{value}'"
        parts = value.split('"')
        return "concat(" + ', \'"\', '.join(f'"{part}"' for part in parts) + ")"

    def _wait_for_ready_page(self, initial_only: bool = False, activity_hint: str = "") -> None:
        if initial_only and self._did_initial_wait:
            return

        initial_activity = (activity_hint or getattr(self.driver, "current_activity", "") or "").lower()
        is_video_like = self._is_video_like_activity(initial_activity)
        deadline = time.time() + (4 if is_video_like else (12 if initial_only else 3))
        zero_filtered_count = 0
        while time.time() < deadline:
            activity = (getattr(self.driver, "current_activity", "") or "").lower()
            if "splash" in activity and initial_only and initial_activity and "splash" not in initial_activity:
                self._did_initial_wait = True
                self._log(f"wait-ready-reset-to-splash initial={initial_activity} current={activity}")
                return
            elements = self._find_snapshot_elements()
            if not elements:
                zero_filtered_count += 1
            else:
                zero_filtered_count = 0
            has_meaningful_control = False
            for element in elements:
                text = self._read_element_attr(element, "text") or self._read_element_attr(element, "content-desc")
                resource_id = self._read_element_attr(element, "resource-id")
                if text.strip() or resource_id.strip():
                    has_meaningful_control = True
                    break
            if is_video_like and zero_filtered_count >= 2:
                self._did_initial_wait = True
                self._log(f"wait-ready-fast-fallback activity={activity} zero_filtered_count={zero_filtered_count}")
                return
            if "splash" in activity and has_meaningful_control and len(elements) >= 3:
                self._did_initial_wait = True
                self._log(f"wait-ready-splash-accepted activity={activity} meaningful_controls=true elements={len(elements)}")
                return
            if "splash" not in activity and has_meaningful_control:
                self._did_initial_wait = True
                self._log(f"wait-ready-finished activity={activity} meaningful_controls=true")
                return
            self._log(f"wait-ready activity={activity} elements={len(elements)} meaningful_controls={has_meaningful_control}")
            time.sleep(1.0)
        self._did_initial_wait = True
        self._log("wait-ready-timeout")

    def _ensure_target_app_context(self) -> None:
        current_package = getattr(self.driver, "current_package", "") or ""
        current_activity = getattr(self.driver, "current_activity", "") or ""
        if self._needs_recovery(current_package, current_activity):
            reason = "out_of_scope_package" if current_package and current_package != self.config.app_package else "splash_activity"
            self.recover_target_app(reason=reason)

    def _needs_recovery(self, current_package: str, current_activity: str) -> bool:
        if current_package and current_package != self.config.app_package:
            return True
        return False

    @staticmethod
    def _resolve_effective_activity(activity: str, initial_activity: str) -> str:
        normalized_current = (activity or "").lower()
        normalized_initial = (initial_activity or "").lower()
        if "splash" in normalized_current and normalized_initial and "splash" not in normalized_initial:
            return initial_activity
        return activity or initial_activity

    def _write_debug_snapshot(self, snapshot: PageSnapshot, activity: str, page_source: str) -> None:
        self.debug_path.parent.mkdir(parents=True, exist_ok=True)
        payload = []
        if self.debug_path.exists():
            try:
                payload = json.loads(self.debug_path.read_text(encoding="utf-8"))
            except Exception:
                payload = []

        payload.append(
            {
                "activity": activity,
                "page_name": snapshot.page_name,
                "route_name": snapshot.route_name,
                "title": snapshot.title,
                "source_digest": snapshot.source_digest,
                "form_fields": snapshot.form_fields,
                "component_types": snapshot.component_types,
                "controls": [
                    {
                        "control_id": control.control_id,
                        "text": control.text,
                        "type_name": control.type_name,
                        "clickable": control.clickable,
                        "resource_id": control.resource_id,
                        "bounds": control.bounds,
                        "route_target": control.route_target,
                    }
                    for control in snapshot.controls
                ],
                "source_excerpt": page_source[:2000],
            }
        )
        self.debug_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _log(self, message: str) -> None:
        self.runtime_log_path.parent.mkdir(parents=True, exist_ok=True)
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] [device] {message}"
        try:
            print(line, flush=True)
        except UnicodeEncodeError:
            safe_line = line.encode("gbk", errors="replace").decode("gbk", errors="replace")
            print(safe_line, flush=True)
        with self.runtime_log_path.open("a", encoding="utf-8") as handle:
            handle.write(f"{line}\n")

    def _log_raw_element_preview(self, elements) -> None:
        preview_parts = []
        for index, element in enumerate(elements[:20]):
            class_name = self._read_element_attr(element, "className") or self._read_element_attr(element, "class")
            text = self._read_element_attr(element, "text") or self._read_element_attr(element, "content-desc")
            resource_id = self._read_element_attr(element, "resource-id")
            clickable = self._read_element_attr(element, "clickable")
            bounds = self._read_element_attr(element, "bounds")
            preview_parts.append(
                f"#{index} class={class_name or '-'} text={text or '-'} id={resource_id or '-'} clickable={clickable or '-'} bounds={bounds or '-'}"
            )
        if preview_parts:
            self._log("raw-elements-preview " + " | ".join(preview_parts))

    def _dump_page_source(self, activity: str, page_source: str) -> None:
        self.page_source_dir.mkdir(parents=True, exist_ok=True)
        safe_activity = "".join(ch if ch.isalnum() or ch in {"_", "-", "."} else "_" for ch in (activity or "unknown"))
        file_path = self.page_source_dir / f"{self._snapshot_counter:03d}_{safe_activity}.xml"
        file_path.write_text(page_source, encoding="utf-8")
        self._log(f"page-source-saved path={file_path}")

    def _tap_bounds_center(self, bounds: str) -> None:
        coords = bounds.strip().replace("][", ",").replace("[", "").replace("]", "").split(",")
        if len(coords) != 4:
            raise ValueError(f"Invalid bounds: {bounds}")
        x1, y1, x2, y2 = [int(value) for value in coords]
        x = (x1 + x2) // 2
        y = (y1 + y2) // 2
        self._log(f"tap-bounds-center bounds={bounds} x={x} y={y}")
        self.driver.tap([(x, y)])

    @staticmethod
    def _is_structural_container(resource_id: str, class_name: str, text: str, bounds: str) -> bool:
        normalized_id = resource_id.lower()
        normalized_class = class_name.lower()
        normalized_text = text.strip()
        full_screen_bounds = bounds in {"[0,0][1080,2360]", "[0,0][1080,2400]", "[0,0][1440,3200]"}

        # Drop root containers that cover the whole page and carry no business meaning.
        if normalized_id.endswith("root_layout") and not normalized_text:
            return True
        if normalized_id.endswith(":id/content") and not normalized_text:
            return True
        if (
            full_screen_bounds
            and not normalized_text
            and any(name in normalized_class for name in ("framelayout", "linearlayout", "viewgroup"))
        ):
            return True
        return False

    @staticmethod
    def _is_video_like_activity(activity: str) -> bool:
        return any(keyword in activity for keyword in ("detail", "ultra", "finder", "feed", "live"))

    def _build_video_fallback_controls(self, activity: str, controls: List[ControlNode]) -> List[ControlNode]:
        normalized_activity = activity.lower()
        if not any(key in normalized_activity for key in ("detail", "ultra", "finder", "feed", "live")):
            return []

        # When the page mostly exposes containers, inject a few semantic regions as fallback actions.
        meaningful_controls = [
            control
            for control in controls
            if control.text.strip() or ("edittext" in control.type_name.lower())
        ]
        if len(meaningful_controls) >= 4:
            return []

        existing_ids = {control.control_id for control in controls}
        fallback_specs = [
            ("bounds:[820,260][1040,520]", "头像区域", "VideoAvatarRegion", "user_profile_region"),
            ("bounds:[820,760][1040,1180]", "评论交互区", "VideoCommentRegion", "comment_panel_region"),
            ("bounds:[720,1540][1060,1920]", "商品挂件区", "VideoCommerceRegion", "commerce_anchor_region"),
            ("bounds:[80,120][420,260]", "顶部搜索区", "VideoSearchRegion", "search_entry_region"),
        ]
        fallback_controls = []
        for control_id, text, type_name, route_target in fallback_specs:
            if control_id in existing_ids:
                continue
            fallback_controls.append(
                ControlNode(
                    control_id=control_id,
                    text=text,
                    type_name=type_name,
                    clickable=True,
                    route_target=route_target,
                    bounds=control_id.split(":", 1)[1],
                )
            )
        if fallback_controls:
            self._log(
                "inject-fallback-controls "
                + " | ".join(f"{control.text}:{control.control_id}" for control in fallback_controls)
            )
        return fallback_controls

    def _build_home_fallback_controls(self, activity: str, controls: List[ControlNode]) -> List[ControlNode]:
        normalized_activity = activity.lower()
        if "splash" not in normalized_activity:
            return []
        if any(any(keyword in (control.text or "") for keyword in ("没有响应", "关闭应用", "等待")) for control in controls):
            return []

        if any("search" in (control.text or "").lower() or "搜索" in (control.text or "") for control in controls):
            return []

        control = ControlNode(
            control_id="bounds:[924,72][1080,204]",
            text="搜索",
            type_name="HomeSearchRegion",
            clickable=True,
            route_target="search_entry_region",
            bounds="[924,72][1080,204]",
        )
        self._log(f"inject-home-fallback-control {control.text}:{control.control_id}")
        return [control]

    def _build_home_fallback_controls(self, activity: str, controls: List[ControlNode]) -> List[ControlNode]:
        normalized_activity = activity.lower()
        if "splash" not in normalized_activity:
            return []
        if any(any(keyword in (control.text or "") for keyword in ("没有响应", "关闭应用", "等待")) for control in controls):
            return []

        existing_text = " ".join((control.text or "") for control in controls)
        fallback_controls: List[ControlNode] = []
        fallback_specs = [
            ("bounds:[924,72][1080,204]", "搜索", "HomeSearchRegion", "search_entry_region"),
            ("bounds:[0,72][160,204]", "私信", "HomeMessageRegion", "message_inbox_region"),
            ("bounds:[180,72][360,204]", "商城", "HomeShopRegion", "shop_home_region"),
            ("bounds:[420,72][620,204]", "直播", "HomeLiveRegion", "live_room_region"),
        ]
        for control_id, text, type_name, route_target in fallback_specs:
            if text in existing_text:
                continue
            fallback_controls.append(
                ControlNode(
                    control_id=control_id,
                    text=text,
                    type_name=type_name,
                    clickable=True,
                    route_target=route_target,
                    bounds=control_id.split(":", 1)[1],
                )
            )
        if fallback_controls:
            self._log(
                "inject-home-fallback-controls "
                + " | ".join(f"{control.text}:{control.control_id}" for control in fallback_controls)
            )
        return fallback_controls


class _CoordinateTapSentinel:
    def click(self) -> None:
        return None
