from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(slots=True)
class ExplorerConfig:
    max_rounds: int = 4
    stable_wait_seconds: float = 1.2
    action_timeout_seconds: float = 8.0
    page_stall_timeout_seconds: float = 8.0
    flow_timeout_seconds: float = 28.0
    max_steps_per_flow: int = 5
    max_same_scene_hits: int = 2
    target_flow_limit: int = 50
    per_scene_sample_limit: int = 3
    per_action_sample_limit: int = 2
    low_gain_limit: int = 2
    search_query: str = "抖音小程序"
    allowed_form_defaults: Dict[str, str] = field(
        default_factory=lambda: {
            "name": "测试用户",
            "phone": "13800138000",
            "email": "demo@example.com",
            "search": "抖音小程序",
            "city": "上海",
        }
    )


@dataclass(slots=True)
class TrafficConfig:
    ignored_domains: List[str] = field(default_factory=list)
    heartbeat_keywords: List[str] = field(default_factory=lambda: ["heartbeat", "ping"])
    preload_keywords: List[str] = field(default_factory=lambda: ["preload", "prefetch"])
    min_business_requests: int = 1


@dataclass(slots=True)
class DeviceConfig:
    use_mock: bool = True
    server_url: str = "http://127.0.0.1:4723/wd/hub"
    platform_name: str = "Android"
    automation_name: str = "UiAutomator2"
    device_name: str = "Android"
    app_package: str = ""
    app_activity: str = ""
    udid: str = ""
    system_port: int = 0
    no_reset: bool = True
    new_command_timeout: int = 120

    @classmethod
    def from_env(cls) -> "DeviceConfig":
        return cls(
            use_mock=os.getenv("FULL_ACTIVATION_USE_MOCK", "false").lower() not in {"0", "false", "no"},
            server_url=os.getenv("APPIUM_SERVER_URL", "http://127.0.0.1:4723/wd/hub"),
            platform_name=os.getenv("APPIUM_PLATFORM_NAME", "Android"),
            automation_name=os.getenv("APPIUM_AUTOMATION_NAME", "UiAutomator2"),
            device_name=os.getenv("APPIUM_DEVICE_NAME", "Android"),
            app_package=os.getenv("APPIUM_APP_PACKAGE", "com.ss.android.ugc.aweme"),
            app_activity=os.getenv("APPIUM_APP_ACTIVITY", "com.ss.android.ugc.aweme.splash.SplashActivity"),
            udid=os.getenv("APPIUM_UDID", "192.168.31.229:5555"),
            system_port=int(os.getenv("APPIUM_SYSTEM_PORT", "0")),
            no_reset=os.getenv("APPIUM_NO_RESET", "true").lower() not in {"0", "false", "no"},
            new_command_timeout=int(os.getenv("APPIUM_NEW_COMMAND_TIMEOUT", "120")),
        )


@dataclass(slots=True)
class DatasetConfig:
    aggregate_view_limit: int = 80
    output_flow_limit: int = 50
    rollback_page_timeout_seconds: int = 8
    rollback_flow_timeout_seconds: int = 28
    experiment_rounds: int = 4
    scene_repeat_limit: int = 2
    flow_repeat_limit: int = 1
    llm_enabled: bool = False
    llm_scene_understanding: bool = False
    llm_action_understanding: bool = False

    @classmethod
    def from_env(cls) -> "DatasetConfig":
        return cls(
            aggregate_view_limit=max(1, int(os.getenv("FULL_ACTIVATION_AGGREGATE_LIMIT", "80"))),
            output_flow_limit=max(1, int(os.getenv("FULL_ACTIVATION_OUTPUT_FLOW_LIMIT", "50"))),
            rollback_page_timeout_seconds=max(3, int(os.getenv("FULL_ACTIVATION_PAGE_TIMEOUT", "8"))),
            rollback_flow_timeout_seconds=max(10, int(os.getenv("FULL_ACTIVATION_FLOW_TIMEOUT", "28"))),
            experiment_rounds=max(1, int(os.getenv("FULL_ACTIVATION_EXPERIMENT_ROUNDS", "4"))),
            scene_repeat_limit=max(1, int(os.getenv("FULL_ACTIVATION_SCENE_REPEAT_LIMIT", "2"))),
            flow_repeat_limit=max(1, int(os.getenv("FULL_ACTIVATION_FLOW_REPEAT_LIMIT", "1"))),
            llm_enabled=os.getenv("FULL_ACTIVATION_LLM_ENABLED", "false").lower() in {"1", "true", "yes"},
            llm_scene_understanding=os.getenv("FULL_ACTIVATION_LLM_SCENE", "false").lower() in {"1", "true", "yes"},
            llm_action_understanding=os.getenv("FULL_ACTIVATION_LLM_ACTION", "false").lower() in {"1", "true", "yes"},
        )


@dataclass(slots=True)
class LLMConfig:
    base_url: str = os.getenv("OPENAI_BASE_URL", "https://api.aipaibox.com/v1")
    api_key: str = os.getenv("OPENAI_API_KEY", "")
    model: str = os.getenv("OPENAI_MODEL", "claude-opus-4-6")
    timeout_seconds: int = int(os.getenv("OPENAI_TIMEOUT_SECONDS", "30"))
