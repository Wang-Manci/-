from __future__ import annotations

import hashlib
import json

from full_activation.models import PageSnapshot


def build_page_signature(snapshot: PageSnapshot) -> str:
    """Build a stable signature from route, source digest and key controls."""

    payload = {
        "package_name": snapshot.package_name,
        "route_name": snapshot.route_name,
        "source_digest": snapshot.source_digest,
        "title": snapshot.title,
        "component_types": sorted(snapshot.component_types),
        "form_fields": sorted(snapshot.form_fields),
        "main_controls": sorted(
            [
                {
                    "text": control.text,
                    "type_name": control.type_name,
                    "handler": control.event_handler,
                    "route_target": control.route_target,
                }
                for control in snapshot.controls
                if control.clickable
            ],
            key=lambda item: (
                item["text"],
                item["type_name"],
                item["handler"],
                item["route_target"],
            ),
        ),
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]
