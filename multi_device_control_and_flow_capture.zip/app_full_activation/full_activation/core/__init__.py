"""Core exploration modules."""

