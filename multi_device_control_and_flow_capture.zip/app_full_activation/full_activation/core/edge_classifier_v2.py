from __future__ import annotations

from collections import Counter

from full_activation.models import ActionCandidate, ControlNode, EdgeType, PageSnapshot, SceneObservation, SceneType


LIKE_IDS = {"com.ss.android.ugc.aweme:id/gbd", "com.ss.android.ugc.aweme:id/gas"}
FAVORITE_IDS = {"com.ss.android.ugc.aweme:id/d-e", "com.ss.android.ugc.aweme:id/d-z", "com.ss.android.ugc.aweme:id/d=6"}
AVATAR_IDS = {"com.ss.android.ugc.aweme:id/iv_avatar", "com.ss.android.ugc.aweme:id/user_avatar"}
SEARCH_RESULT_IDS = {"com.ss.android.ugc.aweme:id/c18"}

COMMENT_HINTS = ("评论", "comment", "留言")
SHARE_HINTS = ("分享", "share", "转发")
PRODUCT_HINTS = ("商品", "橱窗", "购物", "商城", "cart", "product")
MESSAGE_HINTS = ("消息", "私信", "message", "chat")
SHOP_HINTS = ("商城", "购物", "shop", "mall")
LIVE_HINTS = ("直播", "live", "room")
SEARCH_HINTS = ("搜索", "search")
PROFILE_HINTS = ("头像", "作者", "profile", "avatar", "主页")
MINIAPP_HINTS = ("小程序", "miniapp")
THREAD_HINTS = ("会话", "聊天", "thread")


def infer_scene(snapshot: PageSnapshot) -> SceneObservation:
    signal = " ".join(
        [
            snapshot.package_name or "",
            snapshot.page_name or "",
            snapshot.route_name or "",
            snapshot.title or "",
            " ".join(snapshot.component_types),
            " ".join(control.text for control in snapshot.controls if control.text),
            " ".join(control.resource_id for control in snapshot.controls if control.resource_id),
            " ".join(control.route_target for control in snapshot.controls if control.route_target),
        ]
    ).lower()
    package_name = snapshot.package_name or ""
    activity_name = snapshot.page_name or snapshot.route_name or ""

    if any(keyword in signal for keyword in ("没有响应", "关闭应用", "等待", "aerr_wait", "aerr_close")):
        return SceneObservation(SceneType.OUT_OF_SCOPE, 0.99, package_name, activity_name, ["system_dialog"])
    if package_name and "ugc.aweme" not in package_name:
        return SceneObservation(SceneType.OUT_OF_SCOPE, 0.99, package_name, activity_name, ["package_out_of_scope"])
    if "searchresultactivity" in signal or "search_result" in signal:
        return SceneObservation(SceneType.SEARCH_RESULT, 0.95, package_name, activity_name, ["search_result"])
    if "splash" in activity_name.lower():
        return SceneObservation(SceneType.FEED_HOME, 0.88, package_name, activity_name, ["splash_home"])
    if any(keyword in signal for keyword in MINIAPP_HINTS):
        return SceneObservation(SceneType.MINIAPP_PAGE, 0.9, package_name, activity_name, ["miniapp"])
    if any(keyword in signal for keyword in LIVE_HINTS):
        return SceneObservation(SceneType.LIVE_ROOM, 0.9, package_name, activity_name, ["live"])
    if any(keyword in signal for keyword in THREAD_HINTS):
        return SceneObservation(SceneType.MESSAGE_THREAD, 0.86, package_name, activity_name, ["message_thread"])
    if any(keyword in signal for keyword in MESSAGE_HINTS):
        return SceneObservation(SceneType.MESSAGE_INBOX, 0.88, package_name, activity_name, ["message"])
    if any(keyword in signal for keyword in SHOP_HINTS):
        return SceneObservation(SceneType.SHOP_HOME, 0.88, package_name, activity_name, ["shop"])
    if any(keyword in signal for keyword in PRODUCT_HINTS):
        return SceneObservation(SceneType.PRODUCT_DETAIL, 0.84, package_name, activity_name, ["product"])
    if any(keyword in signal for keyword in SHARE_HINTS):
        return SceneObservation(SceneType.SHARE_PANEL, 0.8, package_name, activity_name, ["share"])
    if any(keyword in signal for keyword in ("flowpageactivity", "detail", "ultra")) and _has_any_control(snapshot, LIKE_IDS | FAVORITE_IDS):
        return SceneObservation(SceneType.VIDEO_DETAIL, 0.93, package_name, activity_name, ["video_detail"])
    if snapshot.form_fields and any(keyword in signal for keyword in SEARCH_HINTS):
        return SceneObservation(SceneType.SEARCH_ENTRY, 0.85, package_name, activity_name, ["search_entry"])
    if any(keyword in signal for keyword in PROFILE_HINTS):
        return SceneObservation(SceneType.USER_PROFILE, 0.78, package_name, activity_name, ["profile"])
    if any(keyword in signal for keyword in COMMENT_HINTS):
        return SceneObservation(SceneType.COMMENT_PANEL, 0.76, package_name, activity_name, ["comment"])
    return SceneObservation(SceneType.UNKNOWN, 0.45, package_name, activity_name, ["unknown"])


def build_action_candidates(snapshot: PageSnapshot, scene: SceneObservation) -> list[ActionCandidate]:
    controls = [control for control in snapshot.controls if control.clickable]
    candidates: list[ActionCandidate] = []

    if scene.scene_type in {SceneType.FEED_HOME, SceneType.SPLASH_OR_RESTART, SceneType.UNKNOWN}:
        _append_if(candidates, _pick_search_control(controls), "open_search", "打开搜索栏", EdgeType.QUERY, 100, "search_entry")
        _append_if(candidates, _pick_message_control(controls), "open_message_inbox", "打开私信", EdgeType.NAVIGATION, 96, "message_inbox")
        _append_if(candidates, _pick_shop_control(controls), "open_shop", "打开抖音商城", EdgeType.NAVIGATION, 95, "shop_home")
        _append_if(candidates, _pick_live_control(controls), "open_live_tab", "进入直播间", EdgeType.NAVIGATION, 94, "live_room")

    if scene.scene_type == SceneType.SEARCH_ENTRY:
        _append_if(candidates, _pick_search_submit_control(controls), "submit_search", "提交搜索", EdgeType.SUBMIT, 99, "search_result")

    if scene.scene_type == SceneType.SEARCH_RESULT:
        _append_if(candidates, _pick_search_result_control(controls), "open_search_result", "打开搜索结果", EdgeType.NAVIGATION, 95, "search_result", True)
        _append_if(candidates, _pick_profile_control(controls), "open_profile", "打开作者主页", EdgeType.NAVIGATION, 88, "user_profile")
        _append_if(candidates, _pick_product_control(controls), "open_shop_product", "打开商品详情", EdgeType.NAVIGATION, 87, "product_detail")
        _append_if(candidates, _pick_live_control(controls), "open_live_tab", "进入直播结果", EdgeType.NAVIGATION, 86, "live_room")

    if scene.scene_type == SceneType.VIDEO_DETAIL:
        _append_if(candidates, _pick_exact_control(controls, LIKE_IDS), "video_like", "视频点赞", EdgeType.NAVIGATION, 93, "video_detail")
        _append_if(candidates, _pick_exact_control(controls, FAVORITE_IDS), "video_favorite", "视频收藏", EdgeType.NAVIGATION, 92, "video_detail")
        _append_if(candidates, _pick_comment_control(controls), "open_comment", "打开评论区", EdgeType.NAVIGATION, 90, "comment_panel")
        _append_if(candidates, _pick_share_control(controls), "video_share", "视频分享", EdgeType.NAVIGATION, 89, "share_panel")
        _append_if(candidates, _pick_profile_control(controls), "open_profile", "打开作者主页", EdgeType.NAVIGATION, 88, "user_profile")
        _append_if(candidates, _pick_product_control(controls), "open_video_product", "打开视频商品页", EdgeType.NAVIGATION, 87, "product_detail")

    if scene.scene_type == SceneType.LIVE_ROOM:
        _append_if(candidates, _pick_live_like_control(controls), "live_like", "直播间点赞", EdgeType.NAVIGATION, 95, "live_room")
        _append_if(candidates, _pick_share_control(controls), "live_share", "直播间分享", EdgeType.NAVIGATION, 94, "share_panel")
        _append_if(candidates, _pick_product_control(controls), "open_live_product", "打开直播商品页", EdgeType.NAVIGATION, 93, "product_detail")

    if scene.scene_type == SceneType.MESSAGE_INBOX:
        _append_if(candidates, _pick_message_thread_control(controls), "open_message_thread", "打开私信会话", EdgeType.NAVIGATION, 90, "message_thread", True)

    if scene.scene_type == SceneType.SHOP_HOME:
        _append_if(candidates, _pick_product_control(controls), "open_shop_product", "打开商城商品页", EdgeType.NAVIGATION, 92, "product_detail", True)
        _append_if(candidates, _pick_cart_control(controls), "open_cart", "打开购物车", EdgeType.NAVIGATION, 89, "shop_home")

    if scene.scene_type == SceneType.PRODUCT_DETAIL:
        _append_if(candidates, _pick_add_to_cart_control(controls), "add_to_cart", "加入购物车", EdgeType.SUBMIT, 94, "product_detail")
        _append_if(candidates, _pick_buy_now_control(controls), "buy_now", "立即购买", EdgeType.SUBMIT, 93, "product_detail")
        _append_if(candidates, _pick_share_control(controls), "product_share", "分享商品", EdgeType.NAVIGATION, 88, "share_panel")

    candidates.sort(key=lambda item: -item.priority)
    return _dedupe_candidates(candidates)


def describe_scene(scene: SceneObservation) -> str:
    mapping = {
        SceneType.FEED_HOME: "视频首页",
        SceneType.VIDEO_DETAIL: "视频详情页",
        SceneType.LIVE_ROOM: "直播间",
        SceneType.SEARCH_ENTRY: "搜索输入页",
        SceneType.SEARCH_RESULT: "搜索结果页",
        SceneType.MINIAPP_RESULT: "小程序结果页",
        SceneType.MINIAPP_PAGE: "小程序页面",
        SceneType.USER_PROFILE: "作者主页",
        SceneType.COMMENT_PANEL: "评论面板",
        SceneType.MESSAGE_INBOX: "私信页",
        SceneType.MESSAGE_THREAD: "私信会话页",
        SceneType.SHOP_HOME: "商城页",
        SceneType.PRODUCT_DETAIL: "商品详情页",
        SceneType.SHARE_PANEL: "分享面板",
        SceneType.SPLASH_OR_RESTART: "启动/恢复页",
        SceneType.OUT_OF_SCOPE: "越界页面",
        SceneType.UNKNOWN: "未知页面",
    }
    return mapping.get(scene.scene_type, scene.scene_type.value)


def _append_if(
    candidates: list[ActionCandidate],
    control: ControlNode | None,
    semantic: str,
    label: str,
    edge_type: EdgeType,
    priority: int,
    expected_scene: str,
    repeatable: bool = False,
) -> None:
    if control is None:
        return
    source_text = control.text.strip() or label
    candidates.append(
        ActionCandidate(
            semantic_role=semantic,
            display_name=label,
            control_id=control.control_id,
            edge_type=edge_type,
            priority=priority,
            repeatable=repeatable,
            expected_scene=expected_scene,
            source_text=source_text,
            novelty_key=f"{semantic}:{expected_scene}",
            goal_hint=expected_scene,
        )
    )


def _has_any_control(snapshot: PageSnapshot, ids: set[str]) -> bool:
    return any(control.resource_id in ids or control.control_id.replace("resource-id:", "") in ids for control in snapshot.controls)


def _pick_exact_control(controls: list[ControlNode], resource_ids: set[str]) -> ControlNode | None:
    for control in controls:
        resource_id = control.resource_id or control.control_id.replace("resource-id:", "")
        if resource_id in resource_ids:
            return control
    return None


def _pick_by_keywords(controls: list[ControlNode], include_tokens: tuple[str, ...], exclude_tokens: tuple[str, ...] = ()) -> ControlNode | None:
    scored: list[tuple[int, ControlNode]] = []
    for control in controls:
        resource_id = "" if (control.resource_id or "").strip().lower() == "null" else (control.resource_id or "")
        control_id = control.control_id or ""
        signal = " ".join([control.text, resource_id, control.route_target, control_id, control.type_name]).lower()
        if not any(token.lower() in signal for token in include_tokens):
            continue
        if any(token.lower() in signal for token in exclude_tokens):
            continue
        score = 0
        if control.text.strip():
            score += 3
        if resource_id:
            score += 2
        if control_id.startswith("bounds:"):
            score += 1
        if control_id == "resource-id:null":
            score -= 10
        scored.append((score, control))
    if not scored:
        return None
    scored.sort(key=lambda item: (-item[0], item[1].control_id))
    return scored[0][1]


def _pick_search_control(controls: list[ControlNode]) -> ControlNode | None:
    preferred: list[ControlNode] = []
    fallback: list[ControlNode] = []
    for control in controls:
        resource_id = "" if (control.resource_id or "").strip().lower() == "null" else (control.resource_id or "")
        control_id = control.control_id or ""
        type_name = (control.type_name or "").lower()
        text = (control.text or "").lower()
        signal = " ".join([text, resource_id.lower(), control_id.lower(), type_name])

        if not any(token.lower() in signal for token in SEARCH_HINTS):
            continue
        if "结果" in signal or "输入搜索框" in signal:
            continue

        score = 0
        if "button" in type_name:
            score += 5
        if resource_id:
            score += 3
        if "搜索" in text or "search" in text:
            score += 2
        if control.bounds and control.bounds.startswith("[924,"):
            score += 2
        if control_id == "resource-id:null":
            score -= 10

        if score >= 5:
            preferred.append(control)
        else:
            fallback.append(control)

    if preferred:
        preferred.sort(key=lambda item: item.control_id)
        return preferred[0]
    if fallback:
        fallback.sort(key=lambda item: item.control_id)
        return fallback[0]
    return None


def _pick_search_submit_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, ("搜索", "提交", "确认", "search"), ("结果", "扫一扫", "返回"))


def _pick_search_result_control(controls: list[ControlNode]) -> ControlNode | None:
    exact_match = _pick_exact_control(controls, SEARCH_RESULT_IDS)
    if exact_match is not None:
        return exact_match
    for control in controls:
        signal = " ".join([control.text, control.resource_id, control.route_target, control.control_id, control.type_name]).lower()
        if any(token in signal for token in ("result", "card", "item", "c18")) and "输入搜索框" not in control.text:
            return control
    textful = [control for control in controls if control.text.strip()]
    if textful:
        textful.sort(key=lambda item: (-len(item.text.strip()), item.control_id))
        return textful[0]
    bounds_candidates = [control for control in controls if control.control_id.startswith("bounds:")]
    if bounds_candidates:
        bounds_candidates.sort(key=lambda item: item.control_id)
        return bounds_candidates[0]
    return None


def _pick_comment_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, COMMENT_HINTS)


def _pick_share_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, SHARE_HINTS)


def _pick_profile_control(controls: list[ControlNode]) -> ControlNode | None:
    exact = _pick_exact_control(controls, AVATAR_IDS)
    return exact or _pick_by_keywords(controls, PROFILE_HINTS)


def _pick_product_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, PRODUCT_HINTS)


def _pick_message_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, MESSAGE_HINTS)


def _pick_shop_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, SHOP_HINTS)


def _pick_live_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, LIVE_HINTS)


def _pick_live_like_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, ("点赞", "喜欢", "like", "live_like"))


def _pick_message_thread_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, THREAD_HINTS + MESSAGE_HINTS)


def _pick_cart_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, ("购物车", "cart"))


def _pick_add_to_cart_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, ("加入购物车", "加购", "add to cart"))


def _pick_buy_now_control(controls: list[ControlNode]) -> ControlNode | None:
    return _pick_by_keywords(controls, ("立即购买", "buy now", "马上抢", "购买"))


def _dedupe_candidates(candidates: list[ActionCandidate]) -> list[ActionCandidate]:
    deduped: list[ActionCandidate] = []
    seen: Counter[str] = Counter()
    for candidate in candidates:
        key = f"{candidate.semantic_role}:{candidate.control_id}"
        if seen[key]:
            continue
        seen[key] += 1
        deduped.append(candidate)
    return deduped
