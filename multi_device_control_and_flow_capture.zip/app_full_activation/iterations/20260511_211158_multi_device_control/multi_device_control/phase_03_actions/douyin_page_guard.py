from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from full_activation.core.edge_classifier_v2 import describe_scene, infer_scene
from full_activation.models import PageSnapshot, SceneType


PRODUCT_KEYWORDS = (
    "商品",
    "购物",
    "购物车",
    "商城",
    "店铺",
    "小店",
    "橱窗",
    "加购",
    "立即购买",
    "马上购买",
    "领券",
    "优惠券",
    "cart",
    "mall",
    "shop",
    "product",
    "buy now",
)

AD_KEYWORDS = (
    "广告",
    "赞助",
    "推广",
    "了解详情",
    "查看详情",
    "立即下载",
    "打开应用",
    "安装",
    "去看看",
    "点击查看",
    "ad",
    "ads",
    "sponsor",
    "download",
    "install",
)

LIVE_KEYWORDS = (
    "直播",
    "直播中",
    "进入直播间",
    "正在直播",
    "主播",
    "连麦",
    "live",
    "living",
)


class PageGuardDecision(str, Enum):
    """Action the runner should take after inspecting the current page."""

    KEEP = "keep"
    SKIP = "skip"
    RECOVER = "recover"
    FAIL = "fail"


@dataclass(slots=True)
class DouyinPageGuardConfig:
    """Runtime switches for the feed page guard."""

    enabled: bool = True
    skip_product_pages: bool = True
    skip_ad_pages: bool = True
    skip_live_pages: bool = True
    recover_non_feed_pages: bool = True
    max_skip_attempts: int = 3
    keep_alive_check_interval_seconds: int = 5
    unknown_page_policy: str = "skip_once_then_recover"
    product_keywords: tuple[str, ...] = PRODUCT_KEYWORDS
    ad_keywords: tuple[str, ...] = AD_KEYWORDS
    live_keywords: tuple[str, ...] = LIVE_KEYWORDS


@dataclass(slots=True)
class PageGuardResult:
    """Single page-guard decision, safe to serialize into ledgers."""

    udid: str
    decision: PageGuardDecision
    scene_type: str
    scene_value: str
    reason: str
    confidence: float = 0.0
    package_name: str = ""
    activity_name: str = ""
    attempt: int = 0
    keywords: list[str] = field(default_factory=list)
    duration_ms: int = 0

    @property
    def success(self) -> bool:
        """Return True only when the page can be used for traffic collection."""

        return self.decision == PageGuardDecision.KEEP

    def as_dict(self) -> dict[str, Any]:
        """Convert the decision to a plain JSON-ready dictionary."""

        return {
            "udid": self.udid,
            "decision": self.decision.value,
            "scene_type": self.scene_type,
            "scene_value": self.scene_value,
            "reason": self.reason,
            "confidence": self.confidence,
            "package_name": self.package_name,
            "activity_name": self.activity_name,
            "attempt": self.attempt,
            "keywords": list(self.keywords),
            "duration_ms": self.duration_ms,
        }


@dataclass(slots=True)
class PageGuardOutcome:
    """Final guard result plus the snapshot that matched that result."""

    final_result: PageGuardResult
    snapshot: PageSnapshot | None
    trace: list[PageGuardResult] = field(default_factory=list)

    @property
    def success(self) -> bool:
        """Return True when the final page is collectable."""

        return self.final_result.success

    def trace_as_dicts(self) -> list[dict[str, Any]]:
        """Return all guard steps as JSON-ready dictionaries."""

        return [item.as_dict() for item in self.trace]


class DouyinPageGuard:
    """Keep Douyin traffic collection on collectable feed pages."""

    _COLLECTABLE_SCENES = {
        SceneType.FEED_HOME,
        SceneType.VIDEO_DETAIL,
    }
    _SKIP_SCENES = {
        SceneType.PRODUCT_DETAIL,
        SceneType.SHOP_HOME,
    }
    _RECOVER_SCENES = {
        SceneType.COMMENT_PANEL,
        SceneType.SHARE_PANEL,
        SceneType.SEARCH_ENTRY,
        SceneType.SEARCH_RESULT,
        SceneType.MINIAPP_PAGE,
        SceneType.MINIAPP_RESULT,
        SceneType.MESSAGE_INBOX,
        SceneType.MESSAGE_THREAD,
        SceneType.USER_PROFILE,
        SceneType.LIVE_ROOM,
        SceneType.SPLASH_OR_RESTART,
        SceneType.OUT_OF_SCOPE,
    }

    def __init__(self, verifier, config: DouyinPageGuardConfig | None = None) -> None:
        """Store shared verifier and guard configuration."""

        self.verifier = verifier
        self.config = config or DouyinPageGuardConfig()

    def ensure_collectable_feed(self, session, initial_snapshot: PageSnapshot | None = None) -> PageGuardOutcome:
        """Skip or recover until the device is on a collectable feed page."""

        trace: list[PageGuardResult] = []
        snapshot = initial_snapshot
        max_attempts = max(0, int(self.config.max_skip_attempts))

        for attempt in range(max_attempts + 1):
            snapshot = snapshot or self._safe_capture(session)
            result = self.decide(session, snapshot=snapshot, attempt=attempt)
            trace.append(result)
            if result.decision == PageGuardDecision.KEEP:
                return PageGuardOutcome(final_result=result, snapshot=snapshot, trace=trace)
            if result.decision == PageGuardDecision.FAIL:
                return PageGuardOutcome(final_result=result, snapshot=snapshot, trace=trace)
            if attempt >= max_attempts:
                break
            if result.decision == PageGuardDecision.SKIP:
                if not self._safe_swipe_next(session):
                    failure = self._build_result(
                        session=session,
                        snapshot=snapshot,
                        decision=PageGuardDecision.FAIL,
                        reason="page_guard_skip_failed",
                        attempt=attempt,
                    )
                    trace.append(failure)
                    return PageGuardOutcome(final_result=failure, snapshot=snapshot, trace=trace)
                snapshot = self._safe_capture(session)
                continue
            if result.decision == PageGuardDecision.RECOVER:
                if not self._safe_recover(session):
                    failure = self._build_result(
                        session=session,
                        snapshot=snapshot,
                        decision=PageGuardDecision.FAIL,
                        reason="page_guard_recover_failed",
                        attempt=attempt,
                    )
                    trace.append(failure)
                    return PageGuardOutcome(final_result=failure, snapshot=snapshot, trace=trace)
                snapshot = self._safe_capture(session)

        final_result = self._build_result(
            session=session,
            snapshot=snapshot,
            decision=PageGuardDecision.FAIL,
            reason="page_guard_attempt_limit_reached",
            attempt=max_attempts,
        )
        trace.append(final_result)
        return PageGuardOutcome(final_result=final_result, snapshot=snapshot, trace=trace)

    def decide(self, session, snapshot: PageSnapshot | None = None, attempt: int = 0) -> PageGuardResult:
        """Classify the current page without changing device state."""

        start = time.time()
        snapshot = snapshot or self._safe_capture(session)
        if snapshot is None:
            return self._build_result(
                session=session,
                snapshot=None,
                decision=PageGuardDecision.FAIL,
                reason="page_guard_snapshot_unavailable",
                attempt=attempt,
                start=start,
            )
        if not self.config.enabled:
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.KEEP,
                reason="page_guard_disabled",
                attempt=attempt,
                start=start,
            )

        scene = infer_scene(snapshot)
        keyword_hits = self._matched_keywords(snapshot)
        if self.config.skip_live_pages and scene.scene_type == SceneType.LIVE_ROOM:
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.SKIP,
                reason="skip_live_scene",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if self.config.skip_live_pages and self._has_live_signal(keyword_hits):
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.SKIP,
                reason="skip_live_keyword",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if self.config.skip_product_pages and scene.scene_type in self._SKIP_SCENES:
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.SKIP,
                reason=f"skip_scene:{scene.scene_type.value}",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if self.config.skip_product_pages and self._has_product_signal(keyword_hits):
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.SKIP,
                reason="skip_product_keyword",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if self.config.skip_ad_pages and self._has_ad_signal(keyword_hits):
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.SKIP,
                reason="skip_ad_keyword",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if scene.scene_type in self._COLLECTABLE_SCENES and self.verifier.is_feed_page(snapshot):
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.KEEP,
                reason=f"collectable_scene:{scene.scene_type.value}",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if self._is_screenshot_feed_fallback(session, snapshot):
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.KEEP,
                reason="collectable_screenshot_fallback",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if self.config.recover_non_feed_pages and scene.scene_type in self._RECOVER_SCENES:
            return self._build_result(
                session=session,
                snapshot=snapshot,
                decision=PageGuardDecision.RECOVER,
                reason=f"recover_scene:{scene.scene_type.value}",
                attempt=attempt,
                keywords=keyword_hits,
                start=start,
            )
        if scene.scene_type == SceneType.UNKNOWN:
            return self._decide_unknown_page(session, snapshot, attempt, keyword_hits, start)
        return self._build_result(
            session=session,
            snapshot=snapshot,
            decision=PageGuardDecision.RECOVER,
            reason=f"recover_unhandled_scene:{scene.scene_type.value}",
            attempt=attempt,
            keywords=keyword_hits,
            start=start,
        )

    def _decide_unknown_page(
        self,
        session,
        snapshot: PageSnapshot,
        attempt: int,
        keyword_hits: list[str],
        start: float,
    ) -> PageGuardResult:
        """Apply the configured policy for unknown Douyin pages."""

        policy = str(self.config.unknown_page_policy or "").lower()
        if policy == "keep":
            decision = PageGuardDecision.KEEP
            reason = "unknown_policy_keep"
        elif policy == "recover":
            decision = PageGuardDecision.RECOVER
            reason = "unknown_policy_recover"
        elif policy == "skip_once_then_recover" and attempt == 0:
            decision = PageGuardDecision.SKIP
            reason = "unknown_policy_skip_once"
        else:
            decision = PageGuardDecision.RECOVER
            reason = "unknown_policy_recover_after_skip"
        return self._build_result(
            session=session,
            snapshot=snapshot,
            decision=decision,
            reason=reason,
            attempt=attempt,
            keywords=keyword_hits,
            start=start,
        )

    def _matched_keywords(self, snapshot: PageSnapshot) -> list[str]:
        """Find product and ad keywords in the current UI snapshot."""

        signal = self._snapshot_signal(snapshot)
        keywords = (
            tuple(self.config.product_keywords)
            + tuple(self.config.ad_keywords)
            + tuple(self.config.live_keywords)
        )
        return [keyword for keyword in keywords if keyword.lower() in signal]

    def _snapshot_signal(self, snapshot: PageSnapshot) -> str:
        """Build a normalized searchable text blob from page metadata."""

        parts = [
            snapshot.package_name or "",
            snapshot.page_name or "",
            snapshot.route_name or "",
            snapshot.title or "",
            snapshot.raw_source_excerpt or "",
            " ".join(snapshot.component_types),
            " ".join(control.text for control in snapshot.controls if control.text),
            " ".join(control.resource_id for control in snapshot.controls if control.resource_id),
            " ".join(control.control_id for control in snapshot.controls if control.control_id),
            " ".join(control.route_target for control in snapshot.controls if control.route_target),
        ]
        return " ".join(parts).lower()

    def _has_product_signal(self, keyword_hits: list[str]) -> bool:
        """Return True when keyword hits include a product or shopping cue."""

        product_keywords = {keyword.lower() for keyword in self.config.product_keywords}
        return any(keyword.lower() in product_keywords for keyword in keyword_hits)

    def _has_ad_signal(self, keyword_hits: list[str]) -> bool:
        """Return True when keyword hits include an advertising cue."""

        ad_keywords = {keyword.lower() for keyword in self.config.ad_keywords}
        return any(keyword.lower() in ad_keywords for keyword in keyword_hits)

    def _has_live_signal(self, keyword_hits: list[str]) -> bool:
        """Return True when keyword hits include a live-stream cue."""

        live_keywords = {keyword.lower() for keyword in self.config.live_keywords}
        return any(keyword.lower() in live_keywords for keyword in keyword_hits)

    @staticmethod
    def _is_screenshot_feed_fallback(session, snapshot: PageSnapshot) -> bool:
        """Accept screenshot-only snapshots when Douyin is still foreground."""

        return (
            snapshot.package_name == session.profile.target_app_package
            and str(snapshot.raw_source_excerpt or "").startswith("screenshot_sha1:")
        )

    def _safe_capture(self, session) -> PageSnapshot | None:
        """Capture the current page without leaking exceptions to callers."""

        try:
            return session.capture_page()
        except Exception:
            return None

    @staticmethod
    def _safe_swipe_next(session) -> bool:
        """Swipe away a skipped page and wait briefly for the next page."""

        try:
            session.adapter.swipe_up()
            time.sleep(0.8)
            return session.adapter.wait_for_feed_ready(timeout_seconds=5.0) or True
        except Exception as exc:
            session.status.last_error = str(exc)
            return False

    @staticmethod
    def _safe_recover(session) -> bool:
        """Return the app to the Douyin feed through the session recovery path."""

        try:
            return session.ensure_feed_ready()
        except Exception as exc:
            session.status.last_error = str(exc)
            return False

    def _build_result(
        self,
        session,
        snapshot: PageSnapshot | None,
        decision: PageGuardDecision,
        reason: str,
        attempt: int,
        keywords: list[str] | None = None,
        start: float | None = None,
    ) -> PageGuardResult:
        """Create a serialized guard decision from a snapshot."""

        scene = infer_scene(snapshot) if snapshot is not None else None
        duration_ms = int((time.time() - start) * 1000) if start is not None else 0
        return PageGuardResult(
            udid=session.profile.udid,
            decision=decision,
            scene_type=describe_scene(scene) if scene is not None else session.status.last_scene,
            scene_value=scene.scene_type.value if scene is not None else "",
            reason=reason,
            confidence=scene.confidence if scene is not None else 0.0,
            package_name=scene.package_name if scene is not None else "",
            activity_name=scene.activity_name if scene is not None else "",
            attempt=attempt,
            keywords=keywords or [],
            duration_ms=duration_ms,
        )
