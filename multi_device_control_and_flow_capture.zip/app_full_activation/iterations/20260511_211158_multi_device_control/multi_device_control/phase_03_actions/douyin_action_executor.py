from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from full_activation.core.edge_classifier_v2 import build_action_candidates, describe_scene, infer_scene
from multi_device_control.phase_02_runtime import DeviceHealthState


@dataclass(slots=True)
class DouyinActionResult:
    udid: str
    action_name: str
    success: bool
    scene_type: str
    video_signature: str
    duration_ms: int
    dwell_seconds: int = 0
    error_message: str = ""
    guard_decision: str = ""
    guard_reason: str = ""
    guard_attempts: int = 0
    guard_trace: list[dict[str, Any]] = field(default_factory=list)
    engagement_trace: list[dict[str, Any]] = field(default_factory=list)


class DouyinActionExecutor:
    """Execute Douyin feed-safe actions for one session."""

    def __init__(self, verifier, policy=None, page_guard=None) -> None:
        self.verifier = verifier
        self.policy = policy
        self.page_guard = page_guard

    def ensure_feed(self, session) -> DouyinActionResult:
        start = time.time()
        session.status.last_action = "ensure_feed"
        success = session.ensure_feed_ready()
        snapshot = session.capture_page() if success else None
        guard_trace: list[dict[str, Any]] = []
        if success:
            snapshot, guard_trace = self._ensure_collectable_feed(session, snapshot)
            success = bool(snapshot is not None and (not guard_trace or guard_trace[-1].get("decision") == "keep"))
        scene_type = self._scene_type_for_snapshot(snapshot, session)
        video_signature = self.verifier.build_video_signature(snapshot) if snapshot is not None else ""
        error_message = "" if success else self._guard_error_or_default(guard_trace, "ensure_feed_failed")
        self._apply_result_status(session, success=success, error_message=error_message)
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name="ensure_feed",
            success=success,
            scene_type=scene_type,
            video_signature=video_signature,
            duration_ms=int((time.time() - start) * 1000),
            error_message=error_message,
            **self._guard_fields(guard_trace),
        )

    def swipe_next_video(self, session) -> DouyinActionResult:
        start = time.time()
        session.status.last_action = "swipe_next_video"
        before = session.capture_page()
        before, pre_guard_trace = self._ensure_collectable_feed(session, before)
        if before is None or (pre_guard_trace and pre_guard_trace[-1].get("decision") != "keep"):
            guard_trace = pre_guard_trace
            error_message = self._guard_error_or_default(guard_trace, "feed_not_ready")
            self._apply_result_status(session, success=False, error_message=error_message)
            return DouyinActionResult(
                udid=session.profile.udid,
                action_name="swipe_next_video",
                success=False,
                scene_type=self._scene_type_for_snapshot(before, session),
                video_signature="",
                duration_ms=int((time.time() - start) * 1000),
                error_message=error_message,
                **self._guard_fields(guard_trace),
            )
        before_signature = self.verifier.build_video_signature(before)
        if not self.verifier.is_feed_page(before):
            repaired = session.ensure_feed_ready()
            if not repaired:
                self._apply_result_status(session, success=False, error_message="feed_not_ready")
                return DouyinActionResult(
                    udid=session.profile.udid,
                    action_name="swipe_next_video",
                    success=False,
                    scene_type=session.status.last_scene,
                    video_signature=before_signature,
                    duration_ms=int((time.time() - start) * 1000),
                    error_message="feed_not_ready",
                    **self._guard_fields(pre_guard_trace),
                )
            before = session.capture_page()
            before, repair_guard_trace = self._ensure_collectable_feed(session, before)
            pre_guard_trace = [*pre_guard_trace, *repair_guard_trace]
            if before is None or (repair_guard_trace and repair_guard_trace[-1].get("decision") != "keep"):
                error_message = self._guard_error_or_default(pre_guard_trace, "feed_not_ready_after_repair")
                self._apply_result_status(session, success=False, error_message=error_message)
                return DouyinActionResult(
                    udid=session.profile.udid,
                    action_name="swipe_next_video",
                    success=False,
                    scene_type=self._scene_type_for_snapshot(before, session),
                    video_signature=before_signature,
                    duration_ms=int((time.time() - start) * 1000),
                    error_message=error_message,
                    **self._guard_fields(pre_guard_trace),
                )
            before_signature = self.verifier.build_video_signature(before)

        session.adapter.swipe_up()
        session.adapter.wait_for_feed_ready(timeout_seconds=8.0)
        after = session.capture_page()
        after, post_guard_trace = self._ensure_collectable_feed(session, after)
        guard_trace = [*pre_guard_trace, *post_guard_trace]
        after_signature = self.verifier.build_video_signature(after) if after is not None else ""
        scene_type = self._scene_type_for_snapshot(after, session)
        guard_success = not post_guard_trace or post_guard_trace[-1].get("decision") == "keep"
        feed_page_after = bool(after is not None and self.verifier.is_feed_page(after))
        video_changed = self.verifier.did_video_change(before_signature, after_signature)
        success = bool(after is not None and guard_success and feed_page_after and video_changed)
        if success:
            error_message = ""
        elif after is not None and guard_success and feed_page_after and not video_changed:
            error_message = "network_slow:video_signature_not_changed"
        else:
            error_message = self._guard_error_or_default(
                guard_trace,
                "video_not_changed_or_feed_not_ready",
            )
        if hasattr(session, "record_video_signature"):
            session.record_video_signature(after_signature or before_signature)
        self._apply_result_status(
            session,
            success=success,
            error_message=error_message,
        )
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name="swipe_next_video",
            success=success,
            scene_type=scene_type,
            video_signature=after_signature or before_signature,
            duration_ms=int((time.time() - start) * 1000),
            error_message=error_message,
            **self._guard_fields(guard_trace),
        )

    def advance_to_next_collectable_video(self, session) -> DouyinActionResult:
        """Swipe once, then let the page guard skip non-collectable cards."""

        start = time.time()
        session.status.last_action = "advance_to_next_collectable_video"
        before_signature = ""
        try:
            before = session.capture_page()
            before_signature = self.verifier.build_video_signature(before)
        except Exception:
            before_signature = ""

        try:
            session.adapter.swipe_up()
            session.adapter.wait_for_feed_ready(timeout_seconds=8.0)
        except Exception as exc:
            error_message = str(exc) or "swipe_failed"
            self._apply_result_status(session, success=False, error_message=error_message)
            return DouyinActionResult(
                udid=session.profile.udid,
                action_name="advance_to_next_collectable_video",
                success=False,
                scene_type=session.status.last_scene,
                video_signature=before_signature,
                duration_ms=int((time.time() - start) * 1000),
                error_message=error_message,
            )

        after = session.capture_page()
        after, guard_trace = self._ensure_collectable_feed(session, after)
        after_signature = self.verifier.build_video_signature(after) if after is not None else ""
        scene_type = self._scene_type_for_snapshot(after, session)
        guard_success = not guard_trace or guard_trace[-1].get("decision") == "keep"
        feed_page_after = bool(after is not None and self.verifier.is_feed_page(after))
        video_changed = True
        if before_signature and after_signature:
            video_changed = self.verifier.did_video_change(before_signature, after_signature)
        success = bool(after is not None and guard_success and feed_page_after and video_changed)
        if success:
            error_message = ""
        elif after is not None and guard_success and feed_page_after and not video_changed:
            error_message = "network_slow:video_signature_not_changed"
        else:
            error_message = self._guard_error_or_default(
                guard_trace,
                "video_not_changed_or_feed_not_ready",
            )
        if hasattr(session, "record_video_signature"):
            session.record_video_signature(after_signature or before_signature)
        self._apply_result_status(session, success=success, error_message=error_message)
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name="advance_to_next_collectable_video",
            success=success,
            scene_type=scene_type,
            video_signature=after_signature or before_signature,
            duration_ms=int((time.time() - start) * 1000),
            error_message=error_message,
            **self._guard_fields(guard_trace),
        )

    def dwell_on_current_video(
        self,
        session,
        dwell_seconds: int,
        scheduled_actions: list[Any] | None = None,
        engagement_callback=None,
        stop_event=None,
    ) -> DouyinActionResult:
        start = time.time()
        session.status.last_action = "dwell_on_current_video"
        engagement_trace = self._initial_engagement_trace(session, scheduled_actions)
        if self._stop_requested(stop_event):
            return self._build_manual_stop_result(
                session=session,
                start=start,
                dwell_seconds=dwell_seconds,
                engagement_trace=engagement_trace,
            )
        snapshot = session.capture_page()
        snapshot, guard_trace = self._ensure_collectable_feed(session, snapshot)
        scene_type = self._scene_type_for_snapshot(snapshot, session)
        if snapshot is None or (guard_trace and guard_trace[-1].get("decision") != "keep"):
            error_message = self._guard_error_or_default(guard_trace, "not_on_collectable_feed_page")
            self._apply_result_status(session, success=False, error_message=error_message)
            return DouyinActionResult(
                udid=session.profile.udid,
                action_name="dwell_on_current_video",
                success=False,
                scene_type=scene_type,
                video_signature="",
                duration_ms=int((time.time() - start) * 1000),
                dwell_seconds=dwell_seconds,
                error_message=error_message,
                engagement_trace=engagement_trace,
                **self._guard_fields(guard_trace),
            )
        if not self.verifier.is_feed_page(snapshot):
            self._apply_result_status(session, success=False, error_message="not_on_feed_page")
            return DouyinActionResult(
                udid=session.profile.udid,
                action_name="dwell_on_current_video",
                success=False,
                scene_type=scene_type,
                video_signature="",
                duration_ms=int((time.time() - start) * 1000),
                dwell_seconds=dwell_seconds,
                error_message="not_on_feed_page",
                engagement_trace=engagement_trace,
                **self._guard_fields(guard_trace),
            )
        video_signature = self.verifier.build_video_signature(snapshot)
        deadline = time.time() + dwell_seconds
        guard_interval = self._keep_alive_guard_interval()
        next_guard_check = time.time() + guard_interval
        pending_actions = [
            action
            for action in scheduled_actions or []
            if bool(getattr(action, "should_record_window", False))
        ]
        pending_actions.sort(key=lambda item: int(getattr(item, "planned_at_seconds", 0)))
        fired_action_keys: set[str] = set()
        while time.time() < deadline:
            if self._stop_requested(stop_event):
                return self._build_manual_stop_result(
                    session=session,
                    start=start,
                    dwell_seconds=dwell_seconds,
                    engagement_trace=engagement_trace,
                    scene_type=scene_type,
                    video_signature=video_signature,
                    guard_trace=guard_trace,
                )
            session.touch_heartbeat()
            current_package = session.adapter.get_foreground_package()
            if current_package != session.profile.target_app_package:
                error_message = f"foreground_changed:{current_package or 'unknown'}"
                self._apply_result_status(session, success=False, error_message=error_message)
                return DouyinActionResult(
                    udid=session.profile.udid,
                    action_name="dwell_on_current_video",
                    success=False,
                    scene_type=scene_type,
                    video_signature=video_signature,
                    duration_ms=int((time.time() - start) * 1000),
                    dwell_seconds=dwell_seconds,
                    error_message=error_message,
                    engagement_trace=engagement_trace,
                    **self._guard_fields(guard_trace),
                )
            elapsed_seconds = int(time.time() - start)
            for action in pending_actions:
                action_key = self._scheduled_action_key(action)
                if action_key in fired_action_keys:
                    continue
                if self._stop_requested(stop_event):
                    return self._build_manual_stop_result(
                        session=session,
                        start=start,
                        dwell_seconds=dwell_seconds,
                        engagement_trace=engagement_trace,
                        scene_type=scene_type,
                        video_signature=video_signature,
                        guard_trace=guard_trace,
                    )
                if elapsed_seconds < int(getattr(action, "planned_at_seconds", 0)):
                    continue
                engagement_trace.append(
                    self._record_scheduled_engagement(
                        session=session,
                        action=action,
                        video_signature=video_signature,
                        elapsed_seconds=elapsed_seconds,
                        engagement_callback=engagement_callback,
                    )
                )
                fired_action_keys.add(action_key)
            if self.page_guard is not None and time.time() >= next_guard_check:
                guard_result = self.page_guard.decide(session=session, attempt=0)
                guard_trace.append(guard_result.as_dict())
                if not guard_result.success:
                    error_message = f"page_guard_changed:{guard_result.reason}"
                    self._apply_result_status(session, success=False, error_message=error_message)
                    return DouyinActionResult(
                        udid=session.profile.udid,
                        action_name="dwell_on_current_video",
                        success=False,
                        scene_type=guard_result.scene_type,
                        video_signature=video_signature,
                        duration_ms=int((time.time() - start) * 1000),
                        dwell_seconds=dwell_seconds,
                        error_message=error_message,
                        engagement_trace=engagement_trace,
                        **self._guard_fields(guard_trace),
                    )
                next_guard_check = time.time() + guard_interval
            if stop_event is not None:
                if stop_event.wait(min(1.0, max(0.0, deadline - time.time()))):
                    return self._build_manual_stop_result(
                        session=session,
                        start=start,
                        dwell_seconds=dwell_seconds,
                        engagement_trace=engagement_trace,
                        scene_type=scene_type,
                        video_signature=video_signature,
                        guard_trace=guard_trace,
                    )
            else:
                time.sleep(min(1.0, max(0.0, deadline - time.time())))
        self._apply_result_status(session, success=True, error_message="")
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name="dwell_on_current_video",
            success=True,
            scene_type=scene_type,
            video_signature=video_signature,
            duration_ms=int((time.time() - start) * 1000),
            dwell_seconds=dwell_seconds,
            engagement_trace=engagement_trace,
            **self._guard_fields(guard_trace),
        )

    def like_current_video(self, session) -> DouyinActionResult:
        if self.policy is not None and not self.policy.enable_like:
            return self.build_generic_failure(
                session,
                "like_current_video",
                "disabled_by_policy: enable_like=false",
            )
        return self._tap_current_video_semantic(
            session,
            action_name="like_current_video",
            semantic_roles=("video_like", "live_like"),
        )

    # Marker: this is the reserved comment-action slot for later manual-prompt
    # traffic experiments. It must not auto-execute in this iteration.
    def comment_current_video(self, session, comment_text: str) -> DouyinActionResult:
        _ = comment_text
        raise RuntimeError(
            "disabled_by_policy: manual_comment_prompt_only"
        )

    def build_generic_failure(
        self,
        session,
        action_name: str,
        error_message: str,
        dwell_seconds: int = 0,
    ) -> DouyinActionResult:
        self._apply_result_status(session, success=False, error_message=error_message)
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name=action_name,
            success=False,
            scene_type=session.status.last_scene,
            video_signature="",
            duration_ms=0,
            dwell_seconds=dwell_seconds,
            error_message=error_message,
        )

    @staticmethod
    def _stop_requested(stop_event) -> bool:
        return bool(stop_event is not None and stop_event.is_set())

    def _build_manual_stop_result(
        self,
        session,
        start: float,
        dwell_seconds: int,
        engagement_trace: list[dict[str, Any]],
        scene_type: str = "",
        video_signature: str = "",
        guard_trace: list[dict[str, Any]] | None = None,
    ) -> DouyinActionResult:
        session.touch_heartbeat()
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name="dwell_on_current_video",
            success=False,
            scene_type=scene_type or session.status.last_scene,
            video_signature=video_signature,
            duration_ms=int((time.time() - start) * 1000),
            dwell_seconds=dwell_seconds,
            error_message="manual_stop_requested",
            engagement_trace=engagement_trace,
            **self._guard_fields(guard_trace or []),
        )

    @staticmethod
    def _apply_result_status(session, success: bool, error_message: str) -> None:
        if hasattr(session, "record_action_success") and success:
            session.record_action_success()
        elif hasattr(session, "record_network_slow") and error_message.startswith("network_slow:"):
            session.record_network_slow(error_message)
        elif hasattr(session, "record_action_failure") and not success:
            session.record_action_failure(error_message, category=DouyinActionExecutor._failure_category(error_message))
        else:
            session.status.health_state = DeviceHealthState.READY if success else DeviceHealthState.STALLED
            session.status.last_error = error_message
        session.touch_heartbeat()

    @staticmethod
    def _failure_category(error_message: str) -> str:
        if error_message.startswith("page_guard:"):
            return "page_guard_failed"
        if error_message.startswith("foreground_changed:"):
            return "foreground_changed"
        if "timeout" in error_message:
            return "action_timeout"
        if "capture" in error_message:
            return "capture_page_failed"
        return "action_failed"

    def _ensure_collectable_feed(self, session, snapshot=None) -> tuple[Any, list[dict[str, Any]]]:
        if self.page_guard is None:
            return snapshot, []
        outcome = self.page_guard.ensure_collectable_feed(session, initial_snapshot=snapshot)
        return outcome.snapshot, outcome.trace_as_dicts()

    def _keep_alive_guard_interval(self) -> int:
        if self.page_guard is None:
            return 5
        return max(1, int(self.page_guard.config.keep_alive_check_interval_seconds))

    @staticmethod
    def _scene_type_for_snapshot(snapshot, session) -> str:
        if snapshot is None:
            return session.status.last_scene
        return describe_scene(infer_scene(snapshot))

    @staticmethod
    def _guard_fields(guard_trace: list[dict[str, Any]]) -> dict[str, Any]:
        if not guard_trace:
            return {
                "guard_decision": "",
                "guard_reason": "",
                "guard_attempts": 0,
                "guard_trace": [],
            }
        last = guard_trace[-1]
        return {
            "guard_decision": str(last.get("decision", "")),
            "guard_reason": str(last.get("reason", "")),
            "guard_attempts": len(guard_trace),
            "guard_trace": guard_trace,
        }

    @staticmethod
    def _initial_engagement_trace(session, scheduled_actions: list[Any] | None) -> list[dict[str, Any]]:
        trace: list[dict[str, Any]] = []
        for action in scheduled_actions or []:
            if bool(getattr(action, "should_record_window", False)):
                continue
            trace.append(
                {
                    "event": "scheduled_engagement_skipped",
                    "udid": session.profile.udid,
                    "action_type": getattr(action, "action_type", ""),
                    "planned_at_seconds": int(getattr(action, "planned_at_seconds", 0)),
                    "success": False,
                    "skip_reason": getattr(action, "skip_reason", "") or "not_in_dwell_window",
                    "error_message": getattr(action, "skip_reason", "") or "not_in_dwell_window",
                    "ts": time.time(),
                }
            )
        return trace

    @staticmethod
    def _scheduled_action_key(action: Any) -> str:
        return f"{getattr(action, 'action_type', '')}:{getattr(action, 'planned_at_seconds', 0)}"

    @staticmethod
    def _record_scheduled_engagement(
        session,
        action: Any,
        video_signature: str,
        elapsed_seconds: int,
        engagement_callback=None,
    ) -> dict[str, Any]:
        payload = {
            "event": "scheduled_engagement_window",
            "udid": session.profile.udid,
            "action_type": getattr(action, "action_type", ""),
            "planned_at_seconds": int(getattr(action, "planned_at_seconds", 0)),
            "actual_elapsed_seconds": elapsed_seconds,
            "video_signature": video_signature,
            "success": False,
            "execution_mode": "audit_only",
            "error_message": "automatic_engagement_disabled",
            "ts": time.time(),
        }
        if engagement_callback is not None:
            callback_payload = engagement_callback(
                session=session,
                action=action,
                video_signature=video_signature,
                elapsed_seconds=elapsed_seconds,
            )
            if callback_payload:
                payload.update(callback_payload)
        return payload

    @staticmethod
    def _guard_error_or_default(guard_trace: list[dict[str, Any]], default: str) -> str:
        if not guard_trace:
            return default
        last = guard_trace[-1]
        reason = str(last.get("reason", "")).strip()
        decision = str(last.get("decision", "")).strip()
        if reason:
            return f"page_guard:{decision}:{reason}" if decision else f"page_guard:{reason}"
        return default

    def favorite_current_video(self, session) -> DouyinActionResult:
        if self.policy is not None and not self.policy.enable_favorite:
            return self.build_generic_failure(
                session,
                "favorite_current_video",
                "disabled_by_policy: enable_favorite=false",
            )
        return self._tap_current_video_semantic(
            session,
            action_name="favorite_current_video",
            semantic_roles=("video_favorite",),
        )

    def _tap_current_video_semantic(
        self,
        session,
        action_name: str,
        semantic_roles: tuple[str, ...],
    ) -> DouyinActionResult:
        start = time.time()
        session.status.last_action = action_name
        snapshot = session.capture_page()
        scene = infer_scene(snapshot)
        scene_type = describe_scene(scene)
        video_signature = self.verifier.build_video_signature(snapshot)
        candidate = self._select_candidate(snapshot, scene, semantic_roles)
        if candidate is None:
            error_message = f"candidate_not_found:{','.join(semantic_roles)}"
            self._apply_result_status(session, success=False, error_message=error_message)
            return DouyinActionResult(
                udid=session.profile.udid,
                action_name=action_name,
                success=False,
                scene_type=scene_type,
                video_signature=video_signature,
                duration_ms=int((time.time() - start) * 1000),
                error_message=error_message,
            )
        session.adapter.click_control(candidate.control_id)
        time.sleep(0.8)
        next_snapshot = session.capture_page()
        next_scene = infer_scene(next_snapshot)
        next_signature = self.verifier.build_video_signature(next_snapshot)
        self._apply_result_status(session, success=True, error_message="")
        return DouyinActionResult(
            udid=session.profile.udid,
            action_name=action_name,
            success=True,
            scene_type=describe_scene(next_scene),
            video_signature=next_signature or video_signature,
            duration_ms=int((time.time() - start) * 1000),
        )

    @staticmethod
    def _select_candidate(snapshot, scene, semantic_roles: tuple[str, ...]):
        candidates = build_action_candidates(snapshot, scene)
        for semantic_role in semantic_roles:
            for candidate in candidates:
                if candidate.semantic_role == semantic_role:
                    return candidate
        return None
