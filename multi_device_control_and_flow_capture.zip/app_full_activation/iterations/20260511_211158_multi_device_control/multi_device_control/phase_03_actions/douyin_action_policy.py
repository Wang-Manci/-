from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass(slots=True)
class ScheduledEngagementAction:
    """A planned engagement timing marker within one video dwell window."""

    action_type: str
    planned_at_seconds: int
    should_record_window: bool
    skip_reason: str = ""

    def as_dict(self) -> dict[str, object]:
        return {
            "action_type": self.action_type,
            "planned_at_seconds": self.planned_at_seconds,
            "should_record_window": self.should_record_window,
            "skip_reason": self.skip_reason,
        }


@dataclass(slots=True)
class DouyinActionPolicy:
    """Centralize feed dwell timing and disabled engagement feature flags."""

    dwell_min_seconds: int = 15
    dwell_max_seconds: int = 40
    enable_like: bool = False
    enable_favorite: bool = False
    record_like_window: bool = True
    record_favorite_window: bool = True
    like_schedule_min_seconds: int = 5
    like_schedule_max_seconds: int = 15
    favorite_schedule_min_seconds: int = 16
    favorite_schedule_max_seconds: int = 55
    engagement_marker_window_seconds: float = 1.0

    def next_dwell_seconds(self) -> int:
        lower = max(1, min(self.dwell_min_seconds, self.dwell_max_seconds))
        upper = max(lower, self.dwell_max_seconds)
        return random.SystemRandom().randint(lower, upper)

    def build_engagement_schedule(self, dwell_seconds: int) -> list[ScheduledEngagementAction]:
        """Create per-video like/favorite timing markers bounded by dwell duration."""

        schedule: list[ScheduledEngagementAction] = []
        if self.record_like_window:
            like_at = self._random_second(self.like_schedule_min_seconds, self.like_schedule_max_seconds)
            schedule.append(
                ScheduledEngagementAction(
                    action_type="like_current_video",
                    planned_at_seconds=like_at,
                    should_record_window=like_at <= dwell_seconds,
                    skip_reason="" if like_at <= dwell_seconds else "planned_after_page_turn",
                )
            )
        if self.record_favorite_window:
            favorite_at = self._random_second(
                self.favorite_schedule_min_seconds,
                self.favorite_schedule_max_seconds,
            )
            schedule.append(
                ScheduledEngagementAction(
                    action_type="favorite_current_video",
                    planned_at_seconds=favorite_at,
                    should_record_window=favorite_at <= dwell_seconds,
                    skip_reason="" if favorite_at <= dwell_seconds else "planned_after_page_turn",
                )
            )
        schedule.sort(key=lambda item: item.planned_at_seconds)
        return schedule

    @staticmethod
    def _random_second(lower: int, upper: int) -> int:
        safe_lower = max(1, min(int(lower), int(upper)))
        safe_upper = max(safe_lower, int(upper))
        return random.SystemRandom().randint(safe_lower, safe_upper)
