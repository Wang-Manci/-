from __future__ import annotations

import hashlib
import json

from full_activation.core.edge_classifier_v2 import infer_scene
from full_activation.core.page_signature import build_page_signature
from full_activation.models import SceneType


class DouyinStateVerifier:
    """Interpret snapshots specifically for the Douyin video feed."""

    _FEED_SCENES = {
        SceneType.FEED_HOME,
        SceneType.VIDEO_DETAIL,
    }

    def is_feed_page(self, snapshot) -> bool:
        scene = infer_scene(snapshot)
        if scene.scene_type in self._FEED_SCENES and "ugc.aweme" in (snapshot.package_name or ""):
            return True
        return (
            "ugc.aweme" in (snapshot.package_name or "")
            and str(snapshot.raw_source_excerpt or "").startswith("screenshot_sha1:")
        )

    def build_video_signature(self, snapshot) -> str:
        base_signature = build_page_signature(snapshot)
        payload = {
            "base_signature": base_signature,
            "page_name": snapshot.page_name,
            "title": snapshot.title,
            "visible_texts": [control.text for control in snapshot.controls if control.text][:12],
            "resource_ids": [control.resource_id for control in snapshot.controls if control.resource_id][:12],
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()[:24]

    @staticmethod
    def did_video_change(before_signature: str, after_signature: str) -> bool:
        return bool(before_signature and after_signature and before_signature != after_signature)
