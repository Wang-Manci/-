from __future__ import annotations

import json
import locale
import struct
import subprocess
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import BinaryIO


@dataclass(slots=True)
class PktMonCaptureSession:
    run_id: str
    etl_path: str
    pcapng_path: str
    pcap_path: str
    started_at: str
    status: str = "created"
    error_message: str = ""


@dataclass(slots=True)
class PktMonCaptureResult:
    run_id: str
    etl_path: str
    pcapng_path: str
    pcap_path: str
    started_at: str
    ended_at: str
    status: str
    selected_devices: list[str]
    target_package: str
    backend: str = "pktmon"
    file_size_mb: int = 512
    error_message: str = ""


class PktMonCaptureManager:
    """Capture host traffic with pktmon and export both pcapng and pcap artifacts."""

    def __init__(self, artifact_registry, file_size_mb: int = 512, pkt_size_bytes: int = 0) -> None:
        self.artifact_registry = artifact_registry
        self.file_size_mb = max(32, int(file_size_mb))
        self.pkt_size_bytes = max(0, int(pkt_size_bytes))

    def start_capture(self, run_id: str, selected_devices: list[str], target_package: str) -> PktMonCaptureSession:
        started_at = datetime.now().isoformat(timespec="seconds")
        session = PktMonCaptureSession(
            run_id=run_id,
            etl_path=self.artifact_registry.traffic_capture_etl_path(run_id),
            pcapng_path=self.artifact_registry.traffic_capture_pcapng_path(run_id),
            pcap_path=self.artifact_registry.traffic_capture_pcap_path(run_id),
            started_at=started_at,
        )
        self._cleanup_existing_files(session)
        self._run(["pktmon", "filter", "remove"], allow_failure=True)
        command = [
            "pktmon",
            "start",
            "--capture",
            "--file-name",
            session.etl_path,
            "--file-size",
            str(self.file_size_mb),
        ]
        if self.pkt_size_bytes > 0:
            command.extend(["--pkt-size", str(self.pkt_size_bytes)])
        completed = self._run(command, allow_failure=True)
        if completed.returncode != 0:
            session.status = "start_failed"
            session.error_message = self._format_error(completed)
        else:
            session.status = "running"
        self._write_summary(
            PktMonCaptureResult(
                run_id=run_id,
                etl_path=session.etl_path,
                pcapng_path=session.pcapng_path,
                pcap_path=session.pcap_path,
                started_at=started_at,
                ended_at=started_at,
                status=session.status,
                selected_devices=list(selected_devices),
                target_package=target_package,
                file_size_mb=self.file_size_mb,
                error_message=session.error_message,
            )
        )
        return session

    def stop_capture(
        self,
        session: PktMonCaptureSession,
        selected_devices: list[str],
        target_package: str,
    ) -> PktMonCaptureResult:
        ended_at = datetime.now().isoformat(timespec="seconds")
        status = session.status
        error_message = session.error_message
        try:
            if session.status != "start_failed":
                stop_result = self._run(["pktmon", "stop"], allow_failure=True)
                if stop_result.returncode != 0:
                    status = "stop_failed"
                    error_message = self._format_error(stop_result)
                else:
                    convert_result = self._run(
                        [
                            "pktmon",
                            "etl2pcap",
                            session.etl_path,
                            "--out",
                            session.pcapng_path,
                        ],
                        allow_failure=True,
                    )
                    if convert_result.returncode != 0:
                        status = "convert_failed"
                        error_message = self._format_error(convert_result)
                    else:
                        conversion_error = self._convert_pcapng_to_pcap(
                            Path(session.pcapng_path),
                            Path(session.pcap_path),
                        )
                        if conversion_error:
                            status = "pcap_conversion_failed"
                            error_message = conversion_error
                        else:
                            status = "completed"
                            error_message = ""
        except Exception as exc:
            status = "stop_exception"
            error_message = f"{type(exc).__name__}: {exc}"
        result = PktMonCaptureResult(
            run_id=session.run_id,
            etl_path=session.etl_path,
            pcapng_path=session.pcapng_path,
            pcap_path=session.pcap_path,
            started_at=session.started_at,
            ended_at=ended_at,
            status=status,
            selected_devices=list(selected_devices),
            target_package=target_package,
            file_size_mb=self.file_size_mb,
            error_message=error_message,
        )
        self._write_summary(result)
        return result

    def _cleanup_existing_files(self, session: PktMonCaptureSession) -> None:
        for path_str in (session.etl_path, session.pcapng_path, session.pcap_path):
            path = Path(path_str)
            if path.exists():
                path.unlink()

    def _write_summary(self, result: PktMonCaptureResult) -> None:
        path = Path(self.artifact_registry.traffic_capture_summary_path(result.run_id))
        path.write_text(json.dumps(asdict(result), ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def _run(command: list[str], allow_failure: bool) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding=locale.getpreferredencoding(False),
            errors="replace",
            check=False,
        )

    @staticmethod
    def _format_error(completed: subprocess.CompletedProcess[str]) -> str:
        stdout = PktMonCaptureManager._clean_text(completed.stdout)
        stderr = PktMonCaptureManager._clean_text(completed.stderr)
        chunks = [f"exit_code={completed.returncode}"]
        if stdout:
            chunks.append(f"stdout={stdout}")
        if stderr:
            chunks.append(f"stderr={stderr}")
        if completed.returncode == 5:
            chunks.append("hint=run the terminal as administrator for pktmon capture")
        return " | ".join(chunks)

    @staticmethod
    def _clean_text(value: str | None) -> str:
        return (value or "").replace("\ufffd", "?").strip()

    def _convert_pcapng_to_pcap(self, pcapng_path: Path, pcap_path: Path) -> str:
        if not pcapng_path.exists():
            return f"pcapng file not found: {pcapng_path}"
        try:
            with pcapng_path.open("rb") as source, pcap_path.open("wb") as target:
                self._stream_pcapng_to_pcap(source, target)
        except Exception as exc:
            return str(exc)
        return ""

    def _stream_pcapng_to_pcap(self, source: BinaryIO, target: BinaryIO) -> None:
        current_endian = "<"
        interfaces: list[dict[str, int]] = []
        wrote_header = False
        first_linktype = 1
        first_snaplen = 65535

        while True:
            header = source.read(8)
            if not header:
                break
            if len(header) != 8:
                raise ValueError("truncated pcapng block header")

            raw_block_type = header[:4]
            if raw_block_type == b"\x0a\x0d\x0d\x0a":
                bom = self._read_exact(source, 4)
                if bom == b"\x4d\x3c\x2b\x1a":
                    current_endian = "<"
                elif bom == b"\x1a\x2b\x3c\x4d":
                    current_endian = ">"
                else:
                    raise ValueError("invalid pcapng section byte-order magic")
                block_total_length = struct.unpack(current_endian + "I", header[4:8])[0]
                remaining = self._read_exact(source, block_total_length - 12)
                trailer_length = struct.unpack(current_endian + "I", remaining[-4:])[0]
                if trailer_length != block_total_length:
                    raise ValueError("pcapng section length trailer mismatch")
                interfaces = []
                continue

            block_type = struct.unpack(current_endian + "I", raw_block_type)[0]
            block_total_length = struct.unpack(current_endian + "I", header[4:8])[0]
            if block_total_length < 12:
                raise ValueError("invalid pcapng block length")
            remaining = self._read_exact(source, block_total_length - 8)
            body = remaining[:-4]
            trailer_length = struct.unpack(current_endian + "I", remaining[-4:])[0]
            if trailer_length != block_total_length:
                raise ValueError("pcapng block length trailer mismatch")

            if block_type == 0x00000001:
                linktype, snaplen, ts_divisor = self._parse_interface_description_block(body, current_endian)
                interfaces.append(
                    {
                        "linktype": linktype,
                        "snaplen": snaplen,
                        "ts_divisor": ts_divisor,
                    }
                )
                if not wrote_header:
                    first_linktype = linktype
                    first_snaplen = snaplen
                    self._write_pcap_header(target, linktype=first_linktype, snaplen=first_snaplen)
                    wrote_header = True
                continue

            if block_type == 0x00000006:
                if not interfaces:
                    raise ValueError("enhanced packet block arrived before interface description block")
                if not wrote_header:
                    self._write_pcap_header(target, linktype=first_linktype, snaplen=first_snaplen)
                    wrote_header = True
                self._write_enhanced_packet_block(
                    target=target,
                    body=body,
                    endian=current_endian,
                    interfaces=interfaces,
                )
                continue

            if block_type == 0x00000002:
                if not interfaces:
                    raise ValueError("packet block arrived before interface description block")
                if not wrote_header:
                    self._write_pcap_header(target, linktype=first_linktype, snaplen=first_snaplen)
                    wrote_header = True
                self._write_obsolete_packet_block(
                    target=target,
                    body=body,
                    endian=current_endian,
                    interfaces=interfaces,
                )

        if not wrote_header:
            self._write_pcap_header(target, linktype=first_linktype, snaplen=first_snaplen)

    @staticmethod
    def _read_exact(source: BinaryIO, size: int) -> bytes:
        data = source.read(size)
        if len(data) != size:
            raise ValueError("unexpected end of pcapng file")
        return data

    @staticmethod
    def _write_pcap_header(target: BinaryIO, linktype: int, snaplen: int) -> None:
        target.write(
            struct.pack(
                "<IHHIIII",
                0xA1B2C3D4,
                2,
                4,
                0,
                0,
                max(1, snaplen),
                linktype,
            )
        )

    @staticmethod
    def _parse_interface_description_block(body: bytes, endian: str) -> tuple[int, int, int]:
        if len(body) < 8:
            raise ValueError("truncated interface description block")
        linktype = struct.unpack(endian + "H", body[:2])[0]
        snaplen = struct.unpack(endian + "I", body[4:8])[0]
        ts_divisor = 1_000_000
        option_offset = 8
        while option_offset + 4 <= len(body):
            option_code, option_length = struct.unpack(endian + "HH", body[option_offset : option_offset + 4])
            option_offset += 4
            padded_length = (option_length + 3) & ~3
            option_value = body[option_offset : option_offset + option_length]
            option_offset += padded_length
            if option_code == 0:
                break
            if option_code == 9 and option_length >= 1:
                raw_value = option_value[0]
                if raw_value & 0x80:
                    ts_divisor = 1 << (raw_value & 0x7F)
                else:
                    ts_divisor = 10 ** raw_value
        return linktype, snaplen, ts_divisor

    def _write_enhanced_packet_block(
        self,
        target: BinaryIO,
        body: bytes,
        endian: str,
        interfaces: list[dict[str, int]],
    ) -> None:
        if len(body) < 20:
            raise ValueError("truncated enhanced packet block")
        interface_id, ts_high, ts_low, captured_len, original_len = struct.unpack(endian + "IIIII", body[:20])
        if interface_id >= len(interfaces):
            raise ValueError("pcapng interface index out of range")
        packet_data = body[20 : 20 + captured_len]
        ts_sec, ts_usec = self._split_timestamp(
            raw_timestamp=(ts_high << 32) | ts_low,
            ts_divisor=interfaces[interface_id]["ts_divisor"],
        )
        target.write(struct.pack("<IIII", ts_sec, ts_usec, captured_len, original_len))
        target.write(packet_data)

    def _write_obsolete_packet_block(
        self,
        target: BinaryIO,
        body: bytes,
        endian: str,
        interfaces: list[dict[str, int]],
    ) -> None:
        if len(body) < 20:
            raise ValueError("truncated obsolete packet block")
        interface_id, _drops_count = struct.unpack(endian + "HH", body[:4])
        ts_high, ts_low, captured_len, original_len = struct.unpack(endian + "IIII", body[4:20])
        if interface_id >= len(interfaces):
            raise ValueError("pcapng interface index out of range")
        packet_data = body[20 : 20 + captured_len]
        ts_sec, ts_usec = self._split_timestamp(
            raw_timestamp=(ts_high << 32) | ts_low,
            ts_divisor=interfaces[interface_id]["ts_divisor"],
        )
        target.write(struct.pack("<IIII", ts_sec, ts_usec, captured_len, original_len))
        target.write(packet_data)

    @staticmethod
    def _split_timestamp(raw_timestamp: int, ts_divisor: int) -> tuple[int, int]:
        divisor = max(1, int(ts_divisor))
        seconds = raw_timestamp // divisor
        remainder = raw_timestamp % divisor
        microseconds = (remainder * 1_000_000) // divisor
        return int(seconds), int(microseconds)
