from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

if __package__ in {None, ""}:
    current_file = Path(__file__).resolve()
    iteration_root = current_file.parents[2]
    project_root = current_file.parents[4]
    sys.path.insert(0, str(iteration_root))
    sys.path.insert(0, str(project_root))

from full_activation.core.edge_classifier_v2 import build_action_candidates, describe_scene, infer_scene
from multi_device_control.phase_01_inventory import DeviceInventoryService
from multi_device_control.phase_02_runtime import FleetConfigLoader, SessionFactory
from multi_device_control.phase_06_entry_and_artifacts import ArtifactRegistry


TARGET_SEMANTICS = ("video_like", "live_like", "video_favorite")
DIAGNOSTIC_TOKENS = (
    "like",
    "favorite",
    "\u70b9\u8d5e",
    "\u559c\u6b22",
    "\u6536\u85cf",
)


def capture_douyin_page_diagnostics(
    config_path: str,
    udid: str = "",
    output_root: str = "",
    source_chars: int = 8000,
    max_controls: int = 250,
) -> str:
    config_loader = FleetConfigLoader()
    config = config_loader.load(config_path)
    experiment_root = Path(config_path).resolve().parents[1]
    artifact_registry = ArtifactRegistry(str(experiment_root), external_artifact_root="")

    target_package = config.devices[0].target_app_package if config.devices else ""
    inventory_service = DeviceInventoryService()
    inventory = inventory_service.scan(
        target_package=target_package,
        allowed_udids=[profile.udid for profile in config.devices if profile.enabled],
    )
    session_factory = SessionFactory(config=config, artifact_registry=artifact_registry)
    sessions = session_factory.create_sessions(inventory)
    session = _select_session(sessions, udid)

    snapshot = session.capture_page()
    scene = infer_scene(snapshot)
    candidates = build_action_candidates(snapshot, scene)
    xml_source = _safe_dump_xml(session)
    now = datetime.now()
    output_dir = _build_output_dir(
        output_root=output_root,
        experiment_root=experiment_root,
        timestamp=now,
        udid=session.profile.udid,
    )
    payload = {
        "captured_at": now.isoformat(timespec="seconds"),
        "udid": session.profile.udid,
        "device_alias": session.profile.device_alias,
        "target_package": session.profile.target_app_package,
        "foreground_package": snapshot.package_name,
        "activity": snapshot.page_name,
        "route_name": snapshot.route_name,
        "title": snapshot.title,
        "scene": {
            "scene_type": scene.scene_type.value,
            "scene_label": describe_scene(scene),
            "confidence": scene.confidence,
            "keywords": list(scene.keywords),
        },
        "counts": {
            "controls": len(snapshot.controls),
            "clickable_controls": sum(1 for control in snapshot.controls if control.clickable),
            "action_candidates": len(candidates),
        },
        "target_semantic_matches": {
            semantic: [
                _candidate_summary(candidate)
                for candidate in candidates
                if candidate.semantic_role == semantic
            ]
            for semantic in TARGET_SEMANTICS
        },
        "action_candidates": [_candidate_summary(candidate) for candidate in candidates],
        "clickable_controls": [
            _control_summary(control)
            for control in snapshot.controls
            if control.clickable
        ][: max(1, max_controls)],
        "diagnostic_token_controls": [
            _control_summary(control)
            for control in snapshot.controls
            if _matches_diagnostic_token(control)
        ],
        "source": {
            "snapshot_digest": snapshot.source_digest,
            "xml_sha1": hashlib.sha1(xml_source.encode("utf-8")).hexdigest() if xml_source else "",
            "xml_length": len(xml_source),
            "excerpt_limit": max(0, source_chars),
            "excerpt": (xml_source or snapshot.raw_source_excerpt or "")[: max(0, source_chars)],
        },
    }
    output_path = output_dir / "diagnostic.json"
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(output_path)


def _select_session(sessions, udid: str):
    if not sessions:
        raise RuntimeError("no eligible configured adb devices found")
    if udid:
        for session in sessions:
            if session.profile.udid == udid:
                return session
        raise RuntimeError(f"configured eligible device not found: {udid}")
    return sessions[0]


def _safe_dump_xml(session) -> str:
    try:
        return session.adapter._dump_ui_xml()
    except Exception:
        return ""


def _build_output_dir(output_root: str, experiment_root: Path, timestamp: datetime, udid: str) -> Path:
    root = Path(output_root) if output_root else experiment_root / "artifacts" / "diagnostics"
    output_dir = root / f"douyin_page_{timestamp.strftime('%Y%m%d_%H%M%S')}_{_safe_name(udid)}"
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def _candidate_summary(candidate) -> dict[str, Any]:
    return {
        "semantic_role": candidate.semantic_role,
        "display_name": candidate.display_name,
        "control_id": candidate.control_id,
        "edge_type": getattr(candidate.edge_type, "value", str(candidate.edge_type)),
        "priority": candidate.priority,
        "repeatable": candidate.repeatable,
        "expected_scene": candidate.expected_scene,
        "source_text": candidate.source_text,
        "novelty_key": candidate.novelty_key,
        "goal_hint": candidate.goal_hint,
    }


def _control_summary(control) -> dict[str, Any]:
    return {
        "control_id": control.control_id,
        "text": control.text,
        "type_name": control.type_name,
        "clickable": control.clickable,
        "resource_id": control.resource_id,
        "bounds": control.bounds,
        "route_target": control.route_target,
    }


def _matches_diagnostic_token(control) -> bool:
    signal = " ".join(
        [
            control.control_id or "",
            control.text or "",
            control.resource_id or "",
            control.route_target or "",
            control.type_name or "",
        ]
    ).lower()
    return any(token.lower() in signal for token in DIAGNOSTIC_TOKENS)


def _safe_name(value: str) -> str:
    safe = []
    for char in value:
        if char.isalnum() or char in "._-":
            safe.append(char)
        else:
            safe.append("_")
    return "".join(safe) or "device"


def main() -> None:
    current_file = Path(__file__).resolve()
    default_config = current_file.parents[2] / "config" / "fleet_config.sample.json"
    parser = argparse.ArgumentParser(description="Capture one read-only Douyin page diagnostic snapshot.")
    parser.add_argument("--config", default=str(default_config), help="Fleet config path.")
    parser.add_argument("--udid", default="", help="Optional device udid. Defaults to the first eligible configured device.")
    parser.add_argument("--output-root", default="", help="Optional diagnostics output root.")
    parser.add_argument("--source-chars", type=int, default=8000, help="Max XML source excerpt characters to store.")
    parser.add_argument("--max-controls", type=int, default=250, help="Max clickable controls to store.")
    args = parser.parse_args()
    output_path = capture_douyin_page_diagnostics(
        config_path=args.config,
        udid=args.udid,
        output_root=args.output_root,
        source_chars=args.source_chars,
        max_controls=args.max_controls,
    )
    print(output_path)


if __name__ == "__main__":
    main()
