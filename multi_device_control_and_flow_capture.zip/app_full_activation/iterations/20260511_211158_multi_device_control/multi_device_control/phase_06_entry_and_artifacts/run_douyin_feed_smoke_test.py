from __future__ import annotations

import sys
from pathlib import Path

if __package__ in {None, ""}:
    current_file = Path(__file__).resolve()
    iteration_root = current_file.parents[2]
    project_root = current_file.parents[4]
    sys.path.insert(0, str(iteration_root))
    sys.path.insert(0, str(project_root))

from multi_device_control.phase_01_inventory import DeviceInventoryService
from multi_device_control.phase_02_runtime import FleetConfigLoader, SessionFactory
from multi_device_control.phase_03_actions import (
    DouyinActionExecutor,
    DouyinActionPolicy,
    DouyinPageGuard,
    DouyinPageGuardConfig,
    DouyinStateVerifier,
)
from multi_device_control.phase_04_control import DouyinGroupOrchestrator
from multi_device_control.phase_05_control_fallback import RecoveryPolicy
from multi_device_control.phase_06_entry_and_artifacts import (
    ArtifactRegistry,
    CaptureRepairManager,
    PktMonCaptureManager,
    StatusSnapshotWriter,
    TrafficProbeManager,
)


def run_douyin_feed_smoke_test(config_path: str):
    config_loader = FleetConfigLoader()
    config = config_loader.load(config_path)
    experiment_root = str(Path(config_path).resolve().parents[1])
    artifact_registry = ArtifactRegistry(
        experiment_root,
        external_artifact_root=config.external_artifact_root,
    )
    inventory_service = DeviceInventoryService()
    session_factory = SessionFactory(config=config, artifact_registry=artifact_registry)
    policy = DouyinActionPolicy(
        dwell_min_seconds=config.dwell_min_seconds,
        dwell_max_seconds=config.dwell_max_seconds,
        enable_like=config.enable_like,
        enable_favorite=config.enable_favorite,
        record_like_window=config.record_like_window,
        record_favorite_window=config.record_favorite_window,
        like_schedule_min_seconds=config.like_schedule_min_seconds,
        like_schedule_max_seconds=config.like_schedule_max_seconds,
        favorite_schedule_min_seconds=config.favorite_schedule_min_seconds,
        favorite_schedule_max_seconds=config.favorite_schedule_max_seconds,
        engagement_marker_window_seconds=config.engagement_marker_window_seconds,
    )
    verifier = DouyinStateVerifier()
    page_guard = DouyinPageGuard(
        verifier=verifier,
        config=DouyinPageGuardConfig(
            enabled=config.page_guard_enabled,
            skip_product_pages=config.page_guard_skip_product_pages,
            skip_ad_pages=config.page_guard_skip_ad_pages,
            skip_live_pages=config.page_guard_skip_live_pages,
            recover_non_feed_pages=config.page_guard_recover_non_feed_pages,
            max_skip_attempts=config.page_guard_max_skip_attempts,
            keep_alive_check_interval_seconds=config.page_guard_keep_alive_check_interval_seconds,
            unknown_page_policy=config.page_guard_unknown_page_policy,
        ),
    )
    action_executor = DouyinActionExecutor(verifier=verifier, policy=policy, page_guard=page_guard)
    recovery_policy = RecoveryPolicy(
        retry_limit=config.recovery_retry_limit,
        max_consecutive_failures=config.max_consecutive_failures,
        quarantine_failed_devices=config.quarantine_failed_devices,
        quarantine_duration_seconds=config.quarantine_duration_seconds,
        session_reconnect_enabled=config.session_reconnect_enabled,
        recovery_back_press_limit=config.recovery_back_press_limit,
        restart_app_on_foreground_lost=config.restart_app_on_foreground_lost,
    )
    status_writer = StatusSnapshotWriter(artifact_registry=artifact_registry)
    traffic_probe_manager = TrafficProbeManager(artifact_registry=artifact_registry)
    capture_manager = None
    if getattr(config, "real_capture_enabled", False) and str(config.capture_backend).lower() == "pktmon":
        capture_manager = PktMonCaptureManager(
            artifact_registry=artifact_registry,
            file_size_mb=config.capture_file_size_mb,
            pkt_size_bytes=config.capture_pkt_size_bytes,
        )
    if capture_manager is not None and getattr(config, "capture_repair_on_start", True):
        CaptureRepairManager(
            artifact_registry=artifact_registry,
            capture_manager=capture_manager,
        ).repair_unconverted_captures()
    orchestrator = DouyinGroupOrchestrator(
        config=config,
        session_factory=session_factory,
        action_policy=policy,
        action_executor=action_executor,
        recovery_policy=recovery_policy,
        status_writer=status_writer,
        traffic_probe_manager=traffic_probe_manager,
        capture_manager=capture_manager,
    )

    target_package = ""
    if config.devices:
        target_package = config.devices[0].target_app_package
    inventory = inventory_service.scan(
        target_package=target_package,
        allowed_udids=[profile.udid for profile in config.devices if profile.enabled],
    )
    inventory_service.write_result(inventory, artifact_registry.inventory_path())
    sessions = session_factory.create_sessions(inventory)
    for session in sessions:
        session.connect()
        status_writer.write_session_status(session.snapshot_status(), session.profile.udid)
    try:
        return orchestrator.run_feed_smoke_test(sessions, duration_seconds=config.run_duration_seconds)
    finally:
        for session in sessions:
            try:
                session.disconnect()
            except Exception:
                pass


def main() -> None:
    current_file = Path(__file__).resolve()
    default_config = current_file.parents[2] / "config" / "fleet_config.sample.json"
    result = run_douyin_feed_smoke_test(str(default_config))
    print(result.summary)
    print(result.traffic_probe_dir)
    print(result.traffic_capture_dir)


if __name__ == "__main__":
    main()
