from __future__ import annotations

import json
import locale
import subprocess
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path


@dataclass(slots=True)
class CaptureRepairRecord:
    """Result of one startup repair attempt for an unfinished capture directory."""

    run_id: str
    capture_dir: str
    etl_path: str
    pcapng_path: str
    pcap_path: str
    status: str
    error_message: str = ""


class CaptureRepairManager:
    """Repair leftover pktmon ETL files that were not converted after an abnormal stop."""

    def __init__(self, artifact_registry, capture_manager) -> None:
        self.artifact_registry = artifact_registry
        self.capture_manager = capture_manager

    def repair_unconverted_captures(self) -> dict[str, object]:
        records: list[CaptureRepairRecord] = []
        capture_root = Path(self.artifact_registry.traffic_capture_root())
        for etl_path in self._iter_unconverted_etl_paths(capture_root):
            capture_dir = etl_path.parent
            run_id = self._run_id_from_capture_dir(capture_dir)
            pcapng_path = capture_dir / "capture.pcapng"
            pcap_path = capture_dir / "capture.pcap"
            summary_status = self._capture_summary_status(capture_dir / "capture_summary.json")
            if pcap_path.exists() and pcap_path.stat().st_size > 24 and summary_status == "completed":
                continue
            records.append(self._repair_one(run_id, capture_dir, etl_path, pcapng_path, pcap_path))
        summary = {
            "repaired_at": datetime.now().isoformat(timespec="seconds"),
            "repair_count": len(records),
            "records": [asdict(record) for record in records],
        }
        if records:
            summary_path = capture_root / "capture_repair_summary.json"
            summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        return summary

    @staticmethod
    def _iter_unconverted_etl_paths(capture_root: Path) -> list[Path]:
        """Support both old and external per-run capture directory layouts."""
        paths = list(capture_root.glob("*/capture.etl"))
        paths.extend(capture_root.glob("*/traffic_capture/capture.etl"))
        return sorted(set(paths))

    @staticmethod
    def _run_id_from_capture_dir(capture_dir: Path) -> str:
        if capture_dir.name == "traffic_capture" and capture_dir.parent.name:
            return capture_dir.parent.name
        return capture_dir.name

    @staticmethod
    def _capture_summary_status(summary_path: Path) -> str:
        if not summary_path.exists():
            return ""
        try:
            payload = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception:
            return ""
        return str(payload.get("status", ""))

    def _repair_one(
        self,
        run_id: str,
        capture_dir: Path,
        etl_path: Path,
        pcapng_path: Path,
        pcap_path: Path,
    ) -> CaptureRepairRecord:
        if not pcapng_path.exists() or pcapng_path.stat().st_size == 0:
            convert_result = subprocess.run(
                ["pktmon", "etl2pcap", str(etl_path), "--out", str(pcapng_path)],
                capture_output=True,
                text=True,
                encoding=locale.getpreferredencoding(False),
                errors="replace",
                check=False,
            )
            if convert_result.returncode != 0:
                return CaptureRepairRecord(
                    run_id=run_id,
                    capture_dir=str(capture_dir),
                    etl_path=str(etl_path),
                    pcapng_path=str(pcapng_path),
                    pcap_path=str(pcap_path),
                    status="etl2pcap_failed",
                    error_message=self._format_error(convert_result),
                )
        conversion_error = self.capture_manager._convert_pcapng_to_pcap(pcapng_path, pcap_path)
        if conversion_error:
            return CaptureRepairRecord(
                run_id=run_id,
                capture_dir=str(capture_dir),
                etl_path=str(etl_path),
                pcapng_path=str(pcapng_path),
                pcap_path=str(pcap_path),
                status="pcap_conversion_failed",
                error_message=conversion_error,
            )
        return CaptureRepairRecord(
            run_id=run_id,
            capture_dir=str(capture_dir),
            etl_path=str(etl_path),
            pcapng_path=str(pcapng_path),
            pcap_path=str(pcap_path),
            status="repaired",
        )

    @staticmethod
    def _format_error(completed: subprocess.CompletedProcess[str]) -> str:
        chunks = [f"exit_code={completed.returncode}"]
        stdout = (completed.stdout or "").strip()
        stderr = (completed.stderr or "").strip()
        if stdout:
            chunks.append(f"stdout={stdout}")
        if stderr:
            chunks.append(f"stderr={stderr}")
        return " | ".join(chunks)
