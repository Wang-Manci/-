from __future__ import annotations

import re
from pathlib import Path


class ArtifactRegistry:
    """Centralize filenames so multi-device outputs stay collision-free."""

    def __init__(self, experiment_root: str, external_artifact_root: str = "") -> None:
        self.experiment_root = Path(experiment_root)
        self.artifact_root = self.experiment_root / "artifacts"
        self.external_artifact_root = Path(external_artifact_root) if external_artifact_root else None
        self.artifact_root.mkdir(parents=True, exist_ok=True)
        if self.external_artifact_root is not None:
            self.external_artifact_root.mkdir(parents=True, exist_ok=True)

    def inventory_path(self) -> str:
        return str(self.artifact_root / "inventory_result.json")

    def runtime_log_path(self, udid: str) -> str:
        return str(self.artifact_root / f"device_{self._safe_name(udid)}_runtime.log")

    def state_snapshot_path(self, udid: str) -> str:
        return str(self.artifact_root / f"device_{self._safe_name(udid)}_state.json")

    def page_debug_path(self, udid: str) -> str:
        return str(self.artifact_root / f"device_{self._safe_name(udid)}_page_debug.json")

    def page_source_dir(self, udid: str) -> str:
        path = self.artifact_root / "page_sources" / self._safe_name(udid)
        path.mkdir(parents=True, exist_ok=True)
        return str(path)

    def group_results_path(self) -> str:
        return str(self.artifact_root / "group_action_results.json")

    def experiment_summary_path(self) -> str:
        return str(self.artifact_root / "experiment_summary.json")

    def traffic_probe_root(self) -> str:
        if self.external_artifact_root is not None:
            path = self.external_artifact_root
            path.mkdir(parents=True, exist_ok=True)
            return str(path)
        path = self.artifact_root / "traffic_probe"
        path.mkdir(parents=True, exist_ok=True)
        return str(path)

    def traffic_probe_run_dir(self, run_id: str) -> str:
        if self.external_artifact_root is not None:
            path = self.external_artifact_root / self._safe_name(run_id) / "traffic_probe"
        else:
            path = Path(self.traffic_probe_root()) / self._safe_name(run_id)
        path.mkdir(parents=True, exist_ok=True)
        return str(path)

    def action_ledger_path(self, run_id: str) -> str:
        return str(Path(self.traffic_probe_run_dir(run_id)) / "action_ledger.jsonl")

    def traffic_probe_windows_path(self, run_id: str) -> str:
        return str(Path(self.traffic_probe_run_dir(run_id)) / "windows.json")

    def traffic_probe_summary_path(self, run_id: str) -> str:
        return str(Path(self.traffic_probe_run_dir(run_id)) / "run_summary.json")

    def traffic_probe_events_path(self, run_id: str) -> str:
        return str(Path(self.traffic_probe_run_dir(run_id)) / "events.jsonl")

    def traffic_capture_root(self) -> str:
        if self.external_artifact_root is not None:
            path = self.external_artifact_root
            path.mkdir(parents=True, exist_ok=True)
            return str(path)
        path = self.artifact_root / "traffic_capture"
        path.mkdir(parents=True, exist_ok=True)
        return str(path)

    def traffic_capture_run_dir(self, run_id: str) -> str:
        if self.external_artifact_root is not None:
            path = self.external_artifact_root / self._safe_name(run_id) / "traffic_capture"
        else:
            path = Path(self.traffic_capture_root()) / self._safe_name(run_id)
        path.mkdir(parents=True, exist_ok=True)
        return str(path)

    def traffic_capture_etl_path(self, run_id: str) -> str:
        return str(Path(self.traffic_capture_run_dir(run_id)) / "capture.etl")

    def traffic_capture_pcapng_path(self, run_id: str) -> str:
        return str(Path(self.traffic_capture_run_dir(run_id)) / "capture.pcapng")

    def traffic_capture_pcap_path(self, run_id: str) -> str:
        return str(Path(self.traffic_capture_run_dir(run_id)) / "capture.pcap")

    def traffic_capture_summary_path(self, run_id: str) -> str:
        return str(Path(self.traffic_capture_run_dir(run_id)) / "capture_summary.json")

    def tmp_root(self) -> str:
        path = self.artifact_root / "tmp"
        path.mkdir(parents=True, exist_ok=True)
        return str(path)

    def network_health_temp_path(self, run_id: str) -> str:
        return str(Path(self.tmp_root()) / f"network_health_{self._safe_name(run_id)}.jsonl")

    @staticmethod
    def _safe_name(value: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)
