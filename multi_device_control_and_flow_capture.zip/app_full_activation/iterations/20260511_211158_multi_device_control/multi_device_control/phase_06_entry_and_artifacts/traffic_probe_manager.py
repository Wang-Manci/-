from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any


class TrafficProbeManager:
    """Persist action-window timing so later packet capture can align to it."""

    def __init__(self, artifact_registry) -> None:
        self.artifact_registry = artifact_registry
        self._lock = threading.Lock()
        self.current_run_id: str = ""
        self.current_run_dir: str = ""
        self._windows: dict[str, dict[str, Any]] = {}

    def start_run(self, run_id: str) -> str:
        with self._lock:
            self.current_run_id = run_id
            self.current_run_dir = self.artifact_registry.traffic_probe_run_dir(run_id)
            self._windows = {}
            self._write_windows()
            Path(self.artifact_registry.traffic_probe_events_path(run_id)).write_text("", encoding="utf-8")
            return self.current_run_dir

    def open_window(
        self,
        udid: str,
        action_type: str,
        video_signature: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        if not self.current_run_id:
            raise RuntimeError("traffic probe run has not been started")
        window_id = uuid.uuid4().hex
        payload = {
            "window_id": window_id,
            "udid": udid,
            "action_type": action_type,
            "video_signature": video_signature,
            "start_ts": time.time(),
            "end_ts": 0.0,
            "success": None,
            "error_message": "",
            "metadata": metadata or {},
        }
        with self._lock:
            self._windows[window_id] = payload
            self._write_windows()
        return window_id

    def close_window(
        self,
        window_id: str,
        success: bool = True,
        error_message: str = "",
        extra: dict[str, Any] | None = None,
    ) -> None:
        with self._lock:
            payload = self._windows.get(window_id)
            if payload is None:
                return
            payload["end_ts"] = time.time()
            payload["success"] = success
            payload["error_message"] = error_message
            if extra:
                payload["metadata"].update(extra)
            self._write_windows()

    def close_open_windows(
        self,
        success: bool = False,
        error_message: str = "run_finalized",
        extra: dict[str, Any] | None = None,
    ) -> int:
        """Close all still-open windows so manual stops keep usable metadata."""

        closed_count = 0
        with self._lock:
            for payload in self._windows.values():
                if payload.get("end_ts"):
                    continue
                payload["end_ts"] = time.time()
                payload["success"] = success
                payload["error_message"] = error_message
                if extra:
                    payload["metadata"].update(extra)
                closed_count += 1
            if closed_count:
                self._write_windows()
        return closed_count

    def write_summary(self, summary: dict[str, Any] | None = None) -> str:
        if not self.current_run_id:
            raise RuntimeError("traffic probe run has not been started")
        payload = {
            "run_id": self.current_run_id,
            "run_dir": self.current_run_dir,
            "window_count": len(self._windows),
            "closed_window_count": sum(1 for item in self._windows.values() if item["end_ts"]),
            "summary": summary or {},
        }
        path = Path(self.artifact_registry.traffic_probe_summary_path(self.current_run_id))
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def windows_path(self) -> str:
        if not self.current_run_id:
            raise RuntimeError("traffic probe run has not been started")
        return self.artifact_registry.traffic_probe_windows_path(self.current_run_id)

    def append_event(self, event_name: str, payload: dict[str, Any] | None = None) -> str:
        if not self.current_run_id:
            raise RuntimeError("traffic probe run has not been started")
        event = {
            "ts": time.time(),
            "event": event_name,
            "payload": payload or {},
        }
        path = Path(self.artifact_registry.traffic_probe_events_path(self.current_run_id))
        with self._lock:
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(event, ensure_ascii=False))
                handle.write("\n")
        return str(path)

    def _write_windows(self) -> None:
        path = Path(self.artifact_registry.traffic_probe_windows_path(self.current_run_id))
        payload = list(self._windows.values())
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
