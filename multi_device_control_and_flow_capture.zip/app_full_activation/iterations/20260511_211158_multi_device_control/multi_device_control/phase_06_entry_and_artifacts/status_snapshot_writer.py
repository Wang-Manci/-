from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from enum import Enum
from pathlib import Path
from typing import Any


class StatusSnapshotWriter:
    """Write session and experiment artifacts as plain JSON files."""

    def __init__(self, artifact_registry) -> None:
        self.artifact_registry = artifact_registry

    def write_session_status(self, status, udid: str) -> str:
        payload = self._json_ready(asdict(status) if is_dataclass(status) else status)
        path = Path(self.artifact_registry.state_snapshot_path(udid))
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def write_group_result(self, result) -> str:
        path = Path(self.artifact_registry.group_results_path())
        payload = []
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                payload = []
        payload.append(self._json_ready(asdict(result) if is_dataclass(result) else result))
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def write_experiment_result(self, result) -> str:
        path = Path(self.artifact_registry.experiment_summary_path())
        payload = self._json_ready(asdict(result) if is_dataclass(result) else result)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def _json_ready(self, value: Any) -> Any:
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, dict):
            return {key: self._json_ready(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._json_ready(item) for item in value]
        return value
