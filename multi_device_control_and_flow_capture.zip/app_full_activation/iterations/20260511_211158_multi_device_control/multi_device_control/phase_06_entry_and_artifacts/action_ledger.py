from __future__ import annotations

import json
import threading
from enum import Enum
from pathlib import Path
from typing import Any


class ActionLedger:
    """Append one JSON line per device action for later audit and correlation."""

    def __init__(self, artifact_registry, run_id: str) -> None:
        self.artifact_registry = artifact_registry
        self.run_id = run_id
        self.path = Path(self.artifact_registry.action_ledger_path(run_id))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)
        self._lock = threading.Lock()

    def append(self, row: dict[str, Any]) -> None:
        payload = json.dumps(self._json_ready(row), ensure_ascii=False)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(payload)
                handle.write("\n")

    def flush(self) -> str:
        return str(self.path)

    def _json_ready(self, value: Any) -> Any:
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, dict):
            return {key: self._json_ready(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._json_ready(item) for item in value]
        return value
