from __future__ import annotations

import time

from multi_device_control.phase_02_runtime import DeviceHealthState


class RecoveryPolicy:
    """Small policy object so retry decisions stay consistent."""

    def __init__(
        self,
        retry_limit: int,
        max_consecutive_failures: int = 3,
        quarantine_failed_devices: bool = True,
        quarantine_duration_seconds: int = 0,
        session_reconnect_enabled: bool = True,
        recovery_back_press_limit: int = 3,
        restart_app_on_foreground_lost: bool = True,
    ) -> None:
        self.retry_limit = retry_limit
        self.max_consecutive_failures = max(1, int(max_consecutive_failures))
        self.quarantine_failed_devices = quarantine_failed_devices
        self.quarantine_duration_seconds = max(0, int(quarantine_duration_seconds))
        self.session_reconnect_enabled = session_reconnect_enabled
        self.recovery_back_press_limit = max(0, int(recovery_back_press_limit))
        self.restart_app_on_foreground_lost = restart_app_on_foreground_lost

    def can_retry(self, session) -> bool:
        return (
            session.status.health_state != DeviceHealthState.QUARANTINED
            and session.recovery_attempts < self.retry_limit
        )

    def recover_session(self, session, reason: str) -> bool:
        if session.status.health_state == DeviceHealthState.QUARANTINED:
            return False
        if self._should_quarantine(session):
            self._quarantine(session, reason=f"max_consecutive_failures:{reason}")
            return False
        if not self.can_retry(session):
            if self.quarantine_failed_devices:
                self._quarantine(session, reason=f"retry_limit_reached:{reason}")
            else:
                session.status.health_state = DeviceHealthState.FAILED
                session.status.last_error = f"retry_limit_reached:{reason}"
            return False
        session.status.health_state = DeviceHealthState.RECOVERING
        session.status.recovery_attempts += 1

        recovery_steps = []
        if session.status.last_failure_category == "network_slow":
            recovery_steps.append(("level_1_network_slow_wait", self._level_1_network_slow_wait))
        recovery_steps.append(("level_1_soft_back", self._level_1_soft_back))
        if self.restart_app_on_foreground_lost and self._foreground_lost(session):
            recovery_steps.append(("level_3_restart_douyin", self._level_3_restart_douyin))
        recovery_steps.append(("level_2_feed_recover", self._level_2_feed_recover))
        if self.session_reconnect_enabled:
            recovery_steps.append(("level_4_reconnect_session", self._level_4_reconnect_session))

        for level, step in recovery_steps:
            session.status.last_recovery_level = level
            try:
                if step(session, reason):
                    if hasattr(session, "record_action_success"):
                        session.record_action_success()
                    else:
                        session.status.health_state = DeviceHealthState.READY
                        session.status.last_error = ""
                    return True
            except Exception as exc:
                session.status.last_error = str(exc)

        error_message = session.status.last_error or f"recover_failed:{reason}"
        if hasattr(session, "record_action_failure"):
            session.record_action_failure(
                error_message,
                category="recovery_failed",
                health_state=DeviceHealthState.FAILED,
            )
        else:
            session.status.health_state = DeviceHealthState.FAILED
            session.status.last_error = error_message
        if self._should_quarantine(session):
            self._quarantine(session, reason=error_message)
        return False

    def _level_1_network_slow_wait(self, session, reason: str) -> bool:
        _ = reason
        time.sleep(1.5)
        return self._wait_for_feed_ready(session, timeout_seconds=8.0)

    def _level_1_soft_back(self, session, reason: str) -> bool:
        _ = reason
        for _index in range(self.recovery_back_press_limit):
            try:
                session.adapter.go_back()
            except Exception:
                break
            time.sleep(0.8)
            if self._wait_for_feed_ready(session, timeout_seconds=4.0):
                return True
        return False

    def _level_2_feed_recover(self, session, reason: str) -> bool:
        if not session.adapter.is_connected:
            return session.connect()
        recovered = session.adapter.recover_target_app(reason=f"level_2_feed_recover:{reason}")
        return recovered and self._wait_for_feed_ready(session, timeout_seconds=8.0)

    def _level_3_restart_douyin(self, session, reason: str) -> bool:
        if not session.adapter.is_connected and not session.connect():
            return False
        recovered = session.adapter.recover_target_app(reason=f"level_3_restart_douyin:{reason}")
        return recovered and self._wait_for_feed_ready(session, timeout_seconds=10.0)

    def _level_4_reconnect_session(self, session, reason: str) -> bool:
        _ = reason
        try:
            session.disconnect()
        except Exception:
            pass
        if not session.connect():
            return False
        return session.ensure_feed_ready()

    @staticmethod
    def _wait_for_feed_ready(session, timeout_seconds: float) -> bool:
        wait_for_feed_ready = getattr(session.adapter, "wait_for_feed_ready", None)
        if callable(wait_for_feed_ready):
            return bool(wait_for_feed_ready(timeout_seconds=timeout_seconds))
        return True

    def _foreground_lost(self, session) -> bool:
        try:
            return session.adapter.get_foreground_package() != session.profile.target_app_package
        except Exception:
            return True

    def _should_quarantine(self, session) -> bool:
        return (
            self.quarantine_failed_devices
            and session.status.consecutive_failures >= self.max_consecutive_failures
        )

    def _quarantine(self, session, reason: str) -> None:
        if hasattr(session, "quarantine"):
            session.quarantine(reason, duration_seconds=self.quarantine_duration_seconds)
            return
        session.status.health_state = DeviceHealthState.QUARANTINED
        session.status.last_error = reason
