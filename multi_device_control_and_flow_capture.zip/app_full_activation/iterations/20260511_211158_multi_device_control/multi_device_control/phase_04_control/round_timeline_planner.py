from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class TimelineSegment:
    """One planned page-turn plus the following dwell window for one device."""

    udid: str
    device_alias: str
    video_index: int
    original_page_turn_offset: int
    page_turn_offset: int
    dwell_seconds: int
    engagement_schedule: list[Any] = field(default_factory=list)
    staggered: bool = False
    skipped: bool = False
    skip_reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "udid": self.udid,
            "device_alias": self.device_alias,
            "video_index": self.video_index,
            "original_page_turn_offset": self.original_page_turn_offset,
            "page_turn_offset": self.page_turn_offset,
            "dwell_seconds": self.dwell_seconds,
            "engagement_schedule": [
                item.as_dict() if hasattr(item, "as_dict") else dict(item)
                for item in self.engagement_schedule
            ],
            "staggered": self.staggered,
            "skipped": self.skipped,
            "skip_reason": self.skip_reason,
        }


@dataclass(slots=True)
class RoundTimeline:
    """Full per-device timeline for one scheduling round."""

    round_index: int
    round_seconds: int
    max_page_turns_per_window: int
    page_turn_window_seconds: int
    segments_by_udid: dict[str, list[TimelineSegment]]

    def as_dict(self) -> dict[str, Any]:
        segments = [
            segment.as_dict()
            for segments in self.segments_by_udid.values()
            for segment in segments
        ]
        return {
            "round_index": self.round_index,
            "round_seconds": self.round_seconds,
            "max_page_turns_per_window": self.max_page_turns_per_window,
            "page_turn_window_seconds": self.page_turn_window_seconds,
            "segments": segments,
            "staggered_count": sum(1 for item in segments if item["staggered"]),
            "skipped_count": sum(1 for item in segments if item["skipped"]),
        }


class RoundTimelinePlanner:
    """Pre-generate and stagger page turns for a 3-minute scheduling round."""

    def __init__(
        self,
        action_policy,
        round_seconds: int = 180,
        max_page_turns_per_window: int = 3,
        page_turn_window_seconds: int = 3,
    ) -> None:
        self.action_policy = action_policy
        self.round_seconds = max(30, int(round_seconds))
        self.max_page_turns_per_window = max(1, int(max_page_turns_per_window))
        self.page_turn_window_seconds = max(1, int(page_turn_window_seconds))

    def build(self, sessions: list[Any], round_index: int, round_seconds: int | None = None) -> RoundTimeline:
        effective_round_seconds = max(1, int(round_seconds or self.round_seconds))
        raw_segments = self._build_raw_segments(sessions, effective_round_seconds)
        staggered_segments = self._stagger_page_turns(raw_segments, effective_round_seconds)
        self._rebuild_dwell_and_engagement(staggered_segments, effective_round_seconds)
        return RoundTimeline(
            round_index=round_index,
            round_seconds=effective_round_seconds,
            max_page_turns_per_window=self.max_page_turns_per_window,
            page_turn_window_seconds=self.page_turn_window_seconds,
            segments_by_udid=staggered_segments,
        )

    def _build_raw_segments(self, sessions: list[Any], round_seconds: int) -> dict[str, list[TimelineSegment]]:
        segments_by_udid: dict[str, list[TimelineSegment]] = {}
        for session in sessions:
            offset = 0
            video_index = 1
            segments: list[TimelineSegment] = []
            while offset < round_seconds - 1:
                dwell_seconds = self.action_policy.next_dwell_seconds()
                segments.append(
                    TimelineSegment(
                        udid=session.profile.udid,
                        device_alias=session.profile.device_alias,
                        video_index=video_index,
                        original_page_turn_offset=offset,
                        page_turn_offset=offset,
                        dwell_seconds=min(dwell_seconds, max(1, round_seconds - offset)),
                    )
                )
                offset += dwell_seconds
                video_index += 1
            segments_by_udid[session.profile.udid] = segments
        return segments_by_udid

    def _stagger_page_turns(
        self,
        segments_by_udid: dict[str, list[TimelineSegment]],
        round_seconds: int,
    ) -> dict[str, list[TimelineSegment]]:
        all_segments = [
            segment
            for segments in segments_by_udid.values()
            for segment in segments
        ]
        all_segments.sort(key=lambda item: (item.original_page_turn_offset, item.udid, item.video_index))
        bucket_counts: dict[int, int] = {}
        last_offset_by_udid: dict[str, int] = {}
        for segment in all_segments:
            candidate = max(segment.original_page_turn_offset, last_offset_by_udid.get(segment.udid, -1) + 1)
            assigned = self._find_available_offset(candidate, bucket_counts, round_seconds)
            if assigned >= round_seconds:
                segment.skipped = True
                segment.skip_reason = "page_turn_deferred_past_round"
                segment.page_turn_offset = round_seconds
                continue
            segment.page_turn_offset = assigned
            segment.staggered = assigned != segment.original_page_turn_offset
            bucket_index = assigned // self.page_turn_window_seconds
            bucket_counts[bucket_index] = bucket_counts.get(bucket_index, 0) + 1
            last_offset_by_udid[segment.udid] = assigned
        for segments in segments_by_udid.values():
            segments.sort(key=lambda item: item.page_turn_offset)
        return segments_by_udid

    def _find_available_offset(self, candidate: int, bucket_counts: dict[int, int], round_seconds: int) -> int:
        offset = max(0, candidate)
        while offset < round_seconds:
            bucket_index = offset // self.page_turn_window_seconds
            if bucket_counts.get(bucket_index, 0) < self.max_page_turns_per_window:
                return offset
            offset = (bucket_index + 1) * self.page_turn_window_seconds
        return round_seconds

    def _rebuild_dwell_and_engagement(
        self,
        segments_by_udid: dict[str, list[TimelineSegment]],
        round_seconds: int,
    ) -> None:
        for segments in segments_by_udid.values():
            active_segments = [segment for segment in segments if not segment.skipped]
            for index, segment in enumerate(active_segments):
                if index + 1 < len(active_segments):
                    next_offset = active_segments[index + 1].page_turn_offset
                else:
                    next_offset = round_seconds
                segment.dwell_seconds = max(1, next_offset - segment.page_turn_offset)
                segment.engagement_schedule = self.action_policy.build_engagement_schedule(segment.dwell_seconds)
