from __future__ import annotations

import json
import locale
import re
import subprocess
import threading
import time
from collections import Counter, deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

from multi_device_control.phase_02_runtime import DeviceHealthState


@dataclass(slots=True)
class NetworkHealthSample:
    """One host/network health observation used for adaptive scheduling."""

    ts: float
    monotonic_ts: float
    bytes_sent: int
    bytes_received: int
    tx_bps: float
    rx_bps: float
    ping_ms: float
    packet_loss_percent: float
    active_device_count: int
    network_slow_device_count: int
    state: str
    reason: str


class HotspotCongestionDetector:
    """Classify network health from host metrics plus device slow signals."""

    def __init__(
        self,
        warn_ping_ms: float = 120.0,
        congested_ping_ms: float = 250.0,
        congested_device_ratio: float = 0.5,
        min_slow_devices: int = 2,
    ) -> None:
        self.warn_ping_ms = warn_ping_ms
        self.congested_ping_ms = congested_ping_ms
        self.congested_device_ratio = max(0.0, min(1.0, congested_device_ratio))
        self.min_slow_devices = max(1, int(min_slow_devices))

    def classify(self, ping_ms: float, packet_loss_percent: float, active_devices: int, slow_devices: int) -> tuple[str, str]:
        if active_devices > 0:
            slow_ratio = slow_devices / active_devices
        else:
            slow_ratio = 0.0
        if slow_devices >= self.min_slow_devices and slow_ratio >= self.congested_device_ratio:
            return "CONGESTED", "multiple_devices_network_slow"
        if ping_ms >= self.congested_ping_ms or packet_loss_percent >= 50.0:
            return "CONGESTED", "host_probe_congested"
        if slow_devices > 0:
            return "WARN", "single_or_partial_device_network_slow"
        if ping_ms >= self.warn_ping_ms or packet_loss_percent > 0.0:
            return "WARN", "host_probe_warning"
        return "NORMAL", "network_healthy"


class NetworkHealthMonitor:
    """Sample network state into a temporary file and keep a small in-memory summary."""

    def __init__(
        self,
        artifact_registry,
        sample_interval_seconds: float = 5.0,
        probe_host: str = "223.5.5.5",
        ping_timeout_ms: int = 800,
        detector: HotspotCongestionDetector | None = None,
        cleanup_temp_file: bool = True,
    ) -> None:
        self.artifact_registry = artifact_registry
        self.sample_interval_seconds = max(1.0, float(sample_interval_seconds))
        self.probe_host = probe_host
        self.ping_timeout_ms = max(100, int(ping_timeout_ms))
        self.detector = detector or HotspotCongestionDetector()
        self.cleanup_temp_file = cleanup_temp_file
        self.temp_path: Path | None = None
        self._sessions_provider: Callable[[], list[Any]] | None = None
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._samples: deque[NetworkHealthSample] = deque(maxlen=240)
        self._last_bytes: tuple[int, int, float] | None = None
        self._latest_state = "NORMAL"

    @property
    def latest_state(self) -> str:
        with self._lock:
            return self._latest_state

    def start(self, run_id: str, sessions_provider: Callable[[], list[Any]]) -> str:
        self.temp_path = Path(self.artifact_registry.network_health_temp_path(run_id))
        self.temp_path.write_text("", encoding="utf-8")
        self._sessions_provider = sessions_provider
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._sample_loop, name=f"network-health-{run_id}", daemon=True)
        self._thread.start()
        return str(self.temp_path)

    def stop(self) -> dict[str, Any]:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=max(2.0, self.sample_interval_seconds + 1.0))
        summary = self.summary()
        if self.cleanup_temp_file and self.temp_path is not None:
            try:
                self.temp_path.unlink(missing_ok=True)
            except Exception:
                pass
        return summary

    def summary(self) -> dict[str, Any]:
        with self._lock:
            samples = list(self._samples)
        state_counts = Counter(sample.state for sample in samples)
        ping_values = [sample.ping_ms for sample in samples if sample.ping_ms >= 0]
        return {
            "sample_count": len(samples),
            "latest_state": samples[-1].state if samples else "UNKNOWN",
            "state_counts": dict(state_counts),
            "max_rx_bps": max((sample.rx_bps for sample in samples), default=0.0),
            "max_tx_bps": max((sample.tx_bps for sample in samples), default=0.0),
            "avg_ping_ms": (sum(ping_values) / len(ping_values)) if ping_values else -1.0,
            "temp_file_deleted": self.cleanup_temp_file,
            "probe_host": self.probe_host,
        }

    def _sample_loop(self) -> None:
        while not self._stop_event.is_set():
            sample = self._collect_sample()
            self._record_sample(sample)
            self._stop_event.wait(self.sample_interval_seconds)

    def _collect_sample(self) -> NetworkHealthSample:
        now = time.time()
        mono = time.monotonic()
        bytes_sent, bytes_received = self._read_netstat_bytes()
        tx_bps, rx_bps = self._compute_rates(bytes_sent, bytes_received, mono)
        ping_ms, packet_loss = self._ping_probe()
        sessions = self._sessions_provider() if self._sessions_provider is not None else []
        active_count = len(sessions)
        slow_count = sum(
            1
            for session in sessions
            if getattr(session.status, "health_state", None) == DeviceHealthState.NETWORK_SLOW
        )
        state, reason = self.detector.classify(
            ping_ms=ping_ms,
            packet_loss_percent=packet_loss,
            active_devices=active_count,
            slow_devices=slow_count,
        )
        return NetworkHealthSample(
            ts=now,
            monotonic_ts=mono,
            bytes_sent=bytes_sent,
            bytes_received=bytes_received,
            tx_bps=tx_bps,
            rx_bps=rx_bps,
            ping_ms=ping_ms,
            packet_loss_percent=packet_loss,
            active_device_count=active_count,
            network_slow_device_count=slow_count,
            state=state,
            reason=reason,
        )

    def _record_sample(self, sample: NetworkHealthSample) -> None:
        with self._lock:
            self._samples.append(sample)
            self._latest_state = sample.state
        if self.temp_path is None:
            return
        with self.temp_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(asdict(sample), ensure_ascii=False))
            handle.write("\n")

    def _compute_rates(self, bytes_sent: int, bytes_received: int, monotonic_ts: float) -> tuple[float, float]:
        if self._last_bytes is None:
            self._last_bytes = (bytes_sent, bytes_received, monotonic_ts)
            return 0.0, 0.0
        last_sent, last_received, last_ts = self._last_bytes
        elapsed = max(0.001, monotonic_ts - last_ts)
        self._last_bytes = (bytes_sent, bytes_received, monotonic_ts)
        tx_bps = max(0.0, (bytes_sent - last_sent) * 8 / elapsed)
        rx_bps = max(0.0, (bytes_received - last_received) * 8 / elapsed)
        return tx_bps, rx_bps

    @staticmethod
    def _read_netstat_bytes() -> tuple[int, int]:
        completed = subprocess.run(
            ["netstat", "-e"],
            capture_output=True,
            text=True,
            encoding=locale.getpreferredencoding(False),
            errors="replace",
            check=False,
        )
        if completed.returncode != 0:
            return 0, 0
        numbers: list[int] = []
        for line in completed.stdout.splitlines():
            if "Bytes" not in line and "字节" not in line:
                continue
            numbers = [int(item) for item in re.findall(r"\d+", line)]
            break
        if len(numbers) >= 2:
            return numbers[0], numbers[1]
        return 0, 0

    def _ping_probe(self) -> tuple[float, float]:
        completed = subprocess.run(
            ["ping", "-n", "1", "-w", str(self.ping_timeout_ms), self.probe_host],
            capture_output=True,
            text=True,
            encoding=locale.getpreferredencoding(False),
            errors="replace",
            check=False,
        )
        output = f"{completed.stdout}\n{completed.stderr}"
        if completed.returncode != 0:
            return float(self.ping_timeout_ms), 100.0
        match = re.search(r"(?:time[=<]|时间[=<])\s*(\d+)\s*ms", output, re.IGNORECASE)
        if match:
            return float(match.group(1)), 0.0
        return -1.0, 0.0
