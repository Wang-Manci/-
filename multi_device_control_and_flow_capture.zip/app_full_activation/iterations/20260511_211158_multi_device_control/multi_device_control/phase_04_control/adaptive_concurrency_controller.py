from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from multi_device_control.phase_02_runtime import DeviceHealthState


@dataclass(slots=True)
class AdaptiveConcurrencyDecision:
    """Decision about how many devices may participate in the next timeline round."""

    network_state: str
    active_limit: int
    selected_udids: list[str]
    paused_udids: list[str]
    reason: str

    def as_dict(self) -> dict[str, object]:
        return {
            "network_state": self.network_state,
            "active_limit": self.active_limit,
            "selected_udids": list(self.selected_udids),
            "paused_udids": list(self.paused_udids),
            "reason": self.reason,
        }


class AdaptiveConcurrencyController:
    """Lower or restore device count according to hotspot/network health."""

    def __init__(
        self,
        max_devices: int,
        min_devices_on_congestion: int = 3,
        recovery_rounds_before_add: int = 2,
        enabled: bool = True,
    ) -> None:
        self.max_devices = max(1, int(max_devices))
        self.min_devices_on_congestion = max(1, int(min_devices_on_congestion))
        self.recovery_rounds_before_add = max(1, int(recovery_rounds_before_add))
        self.enabled = enabled
        self.current_limit = self.max_devices
        self._stable_rounds = 0

    def select_sessions(self, sessions: list[Any], network_state: str) -> AdaptiveConcurrencyDecision:
        eligible = [session for session in sessions if self._eligible(session)]
        if not self.enabled:
            selected = eligible[: self.max_devices]
            return AdaptiveConcurrencyDecision(
                network_state=network_state,
                active_limit=self.max_devices,
                selected_udids=[session.profile.udid for session in selected],
                paused_udids=[session.profile.udid for session in eligible[self.max_devices :]],
                reason="adaptive_concurrency_disabled",
            )

        reason = self._update_limit(network_state)
        selected = eligible[: self.current_limit]
        paused = eligible[self.current_limit :]
        for session in paused:
            session.status.last_failure_category = session.status.last_failure_category or "paused_by_network"
        return AdaptiveConcurrencyDecision(
            network_state=network_state,
            active_limit=self.current_limit,
            selected_udids=[session.profile.udid for session in selected],
            paused_udids=[session.profile.udid for session in paused],
            reason=reason,
        )

    def _update_limit(self, network_state: str) -> str:
        state = (network_state or "NORMAL").upper()
        if state == "CONGESTED":
            self._stable_rounds = 0
            next_limit = min(self.current_limit, self.min_devices_on_congestion)
            self.current_limit = max(1, next_limit)
            return "network_congested_reduce_to_minimum"
        if state == "WARN":
            self._stable_rounds = 0
            self.current_limit = max(self.min_devices_on_congestion, self.current_limit - 1)
            return "network_warning_reduce_one"
        self._stable_rounds += 1
        if self._stable_rounds >= self.recovery_rounds_before_add and self.current_limit < self.max_devices:
            self.current_limit += 1
            self._stable_rounds = 0
            return "network_stable_add_one"
        return "network_normal_keep_limit"

    @staticmethod
    def _eligible(session) -> bool:
        status = session.refresh_state()
        return status.health_state in {
            DeviceHealthState.INIT,
            DeviceHealthState.READY,
            DeviceHealthState.OFFLINE,
            DeviceHealthState.BUSY,
        }
