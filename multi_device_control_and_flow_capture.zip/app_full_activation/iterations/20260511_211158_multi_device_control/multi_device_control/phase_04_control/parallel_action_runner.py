from __future__ import annotations

import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from typing import Any, Callable

@dataclass(slots=True)
class ParallelRunStats:
    """Small telemetry bundle for one parallel action batch."""

    action_name: str
    started_at: float
    ended_at: float = 0.0
    completed_udids: list[str] = field(default_factory=list)
    timed_out_udids: list[str] = field(default_factory=list)
    failed_udids: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        """Return JSON-ready execution stats."""

        return {
            "action_name": self.action_name,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "duration_ms": int((self.ended_at - self.started_at) * 1000) if self.ended_at else 0,
            "completed_udids": list(self.completed_udids),
            "timed_out_udids": list(self.timed_out_udids),
            "failed_udids": list(self.failed_udids),
        }


class ParallelActionRunner:
    """Run per-device actions with deadlines so one stuck phone cannot block the group."""

    def __init__(
        self,
        failure_builder: Callable[..., Any],
        event_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> None:
        self.failure_builder = failure_builder
        self.event_callback = event_callback

    def run(
        self,
        sessions: list[Any],
        operation: Callable[[Any], Any],
        action_name: str,
        timeout_seconds: float,
        timeout_by_udid: dict[str, float] | None = None,
        dwell_seconds_by_udid: dict[str, int] | None = None,
    ) -> list[Any]:
        """Execute the same operation for each session and return results in session order."""

        if not sessions:
            return []
        timeout_by_udid = timeout_by_udid or {}
        dwell_seconds_by_udid = dwell_seconds_by_udid or {}
        stats = ParallelRunStats(action_name=action_name, started_at=time.time())
        results_by_udid: dict[str, Any] = {}
        executor = ThreadPoolExecutor(max_workers=max(1, len(sessions)))
        future_map = {executor.submit(operation, session): session for session in sessions}
        deadlines = {
            session.profile.udid: time.time() + max(0.1, float(timeout_by_udid.get(session.profile.udid, timeout_seconds)))
            for session in sessions
        }
        pending = set(future_map)

        while pending:
            now = time.time()
            expired = [future for future in pending if now >= deadlines[future_map[future].profile.udid]]
            for future in expired:
                session = future_map[future]
                pending.remove(future)
                future.cancel()
                results_by_udid[session.profile.udid] = self._build_timeout_result(
                    session=session,
                    action_name=action_name,
                    timeout_seconds=timeout_by_udid.get(session.profile.udid, timeout_seconds),
                    dwell_seconds=dwell_seconds_by_udid.get(session.profile.udid, 0),
                )
                stats.timed_out_udids.append(session.profile.udid)
                self._event(
                    "parallel_action_timeout",
                    {
                        "udid": session.profile.udid,
                        "action_name": action_name,
                        "timeout_seconds": timeout_by_udid.get(session.profile.udid, timeout_seconds),
                    },
                )
            if not pending:
                break
            next_deadline = min(deadlines[future_map[future].profile.udid] for future in pending)
            done, pending = wait(
                pending,
                timeout=max(0.05, min(0.5, next_deadline - time.time())),
                return_when=FIRST_COMPLETED,
            )
            for future in done:
                session = future_map[future]
                try:
                    result = future.result()
                    results_by_udid[session.profile.udid] = result
                    stats.completed_udids.append(session.profile.udid)
                except Exception as exc:
                    results_by_udid[session.profile.udid] = self._build_exception_result(
                        session=session,
                        action_name=action_name,
                        error_message=str(exc),
                        dwell_seconds=dwell_seconds_by_udid.get(session.profile.udid, 0),
                    )
                    stats.failed_udids.append(session.profile.udid)
                    self._event(
                        "parallel_action_exception",
                        {
                            "udid": session.profile.udid,
                            "action_name": action_name,
                            "error_message": str(exc),
                        },
                    )

        stats.ended_at = time.time()
        executor.shutdown(wait=False, cancel_futures=True)
        self._event("parallel_action_completed", stats.as_dict())
        return [results_by_udid[session.profile.udid] for session in sessions if session.profile.udid in results_by_udid]

    def _build_timeout_result(self, session, action_name: str, timeout_seconds: float, dwell_seconds: int):
        error_message = f"action_timeout:{action_name}:{timeout_seconds:.1f}s"
        session.action_started_at = 0.0
        return self.failure_builder(
            session=session,
            action_name=action_name,
            error_message=error_message,
            dwell_seconds=dwell_seconds,
        )

    def _build_exception_result(self, session, action_name: str, error_message: str, dwell_seconds: int):
        session.action_started_at = 0.0
        return self.failure_builder(
            session=session,
            action_name=action_name,
            error_message=error_message,
            dwell_seconds=dwell_seconds,
        )

    def _event(self, event_name: str, payload: dict[str, Any]) -> None:
        if self.event_callback is None:
            return
        self.event_callback(event_name, payload)
