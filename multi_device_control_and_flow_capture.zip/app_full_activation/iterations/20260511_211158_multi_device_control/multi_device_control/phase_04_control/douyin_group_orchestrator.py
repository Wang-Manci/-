from __future__ import annotations

import random
import signal
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from multi_device_control.phase_02_runtime import DeviceHealthState

from .adaptive_concurrency_controller import AdaptiveConcurrencyController
from .network_health_monitor import HotspotCongestionDetector, NetworkHealthMonitor
from .parallel_action_runner import ParallelActionRunner
from .round_timeline_planner import RoundTimelinePlanner, TimelineSegment


@dataclass(slots=True)
class DouyinFeedRunResult:
    experiment_id: str
    started_at: str
    ended_at: str
    selected_devices: list[str]
    rounds_completed: int
    final_mode: str
    traffic_probe_dir: str
    traffic_capture_dir: str
    summary: str


class DouyinGroupOrchestrator:
    """Run a timed Douyin feed smoke test across 1-n sessions."""

    def __init__(
        self,
        config,
        session_factory,
        action_policy,
        action_executor,
        recovery_policy,
        status_writer,
        traffic_probe_manager,
        capture_manager=None,
    ) -> None:
        self.config = config
        self.session_factory = session_factory
        self.action_policy = action_policy
        self.action_executor = action_executor
        self.recovery_policy = recovery_policy
        self.status_writer = status_writer
        self.traffic_probe_manager = traffic_probe_manager
        self.capture_manager = capture_manager
        self.parallel_action_runner = ParallelActionRunner(
            failure_builder=self._build_parallel_failure,
            event_callback=self._event,
        )
        self.timeline_planner = RoundTimelinePlanner(
            action_policy=self.action_policy,
            round_seconds=getattr(self.config, "scheduling_round_seconds", 180),
            max_page_turns_per_window=getattr(self.config, "max_page_turns_per_window", 3),
            page_turn_window_seconds=getattr(self.config, "page_turn_window_seconds", 3),
        )
        self.network_monitor = NetworkHealthMonitor(
            artifact_registry=self.status_writer.artifact_registry,
            sample_interval_seconds=getattr(self.config, "network_sample_interval_seconds", 5.0),
            probe_host=getattr(self.config, "network_probe_host", "223.5.5.5"),
            ping_timeout_ms=getattr(self.config, "network_ping_timeout_ms", 800),
            detector=HotspotCongestionDetector(
                warn_ping_ms=getattr(self.config, "network_warn_ping_ms", 120.0),
                congested_ping_ms=getattr(self.config, "network_congested_ping_ms", 250.0),
                congested_device_ratio=getattr(self.config, "network_congested_device_ratio", 0.5),
                min_slow_devices=getattr(self.config, "network_min_slow_devices", 2),
            ),
            cleanup_temp_file=getattr(self.config, "network_temp_cleanup", True),
        )
        self.concurrency_controller = AdaptiveConcurrencyController(
            max_devices=self.config.sync_device_limit,
            min_devices_on_congestion=getattr(self.config, "min_devices_on_congestion", 3),
            recovery_rounds_before_add=getattr(self.config, "recovery_rounds_before_add", 2),
            enabled=getattr(self.config, "network_adaptive_enabled", True),
        )
        self._stop_event = threading.Event()

    def run_feed_smoke_test(self, sessions, duration_seconds: int | None = None) -> DouyinFeedRunResult:
        self._stop_event.clear()
        started_at = datetime.now().isoformat(timespec="seconds")
        run_id = f"{self.config.experiment_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        selected = self.session_factory.select_sync_group(sessions, self.config.sync_device_limit)
        selected_udids = [session.profile.udid for session in selected]
        traffic_probe_dir = self.traffic_probe_manager.start_run(run_id)
        traffic_capture_dir = ""
        target_package = selected[0].profile.target_app_package if selected else ""
        self._event("run_started", {"run_id": run_id, "selected_devices": selected_udids})
        from multi_device_control.phase_06_entry_and_artifacts import ActionLedger

        ledger = ActionLedger(self.status_writer.artifact_registry, run_id=run_id)
        rounds_completed = 0
        final_mode = "sync"
        run_duration = max(30, int(duration_seconds or self.config.run_duration_seconds))
        deadline = time.time() + run_duration
        capture_session = None
        interrupted = False
        network_monitor_started = False
        network_summary: dict[str, Any] = {}

        self._write_session_snapshots(sessions)
        if not selected:
            ended_at = datetime.now().isoformat(timespec="seconds")
            summary = "no eligible sessions selected for the Douyin feed smoke test"
            self._finalize_probe(
                run_id=run_id,
                selected_udids=selected_udids,
                rounds_completed=0,
                final_mode="sync",
                summary=summary,
                started_at=started_at,
                ended_at=ended_at,
                ledger=ledger,
            )
            run_result = DouyinFeedRunResult(
                experiment_id=run_id,
                started_at=started_at,
                ended_at=ended_at,
                selected_devices=selected_udids,
                rounds_completed=0,
                final_mode="sync",
                traffic_probe_dir=traffic_probe_dir,
                traffic_capture_dir=traffic_capture_dir,
                summary=summary,
            )
            self.status_writer.write_experiment_result(run_result)
            return run_result

        if getattr(self.config, "network_adaptive_enabled", True):
            temp_path = self.network_monitor.start(run_id, sessions_provider=lambda: selected)
            network_monitor_started = True
            self._event(
                "network_health_monitor_started",
                {
                    "temp_path": temp_path,
                    "cleanup_temp_file": getattr(self.config, "network_temp_cleanup", True),
                },
            )

        if self.capture_manager and getattr(self.config, "real_capture_enabled", False):
            capture_session = self.capture_manager.start_capture(
                run_id=run_id,
                selected_devices=selected_udids,
                target_package=target_package,
            )
            traffic_capture_dir = str(Path(capture_session.etl_path).parent)
            self._event(
                "traffic_capture_started",
                {
                    "status": capture_session.status,
                    "etl_path": capture_session.etl_path,
                    "pcapng_path": capture_session.pcapng_path,
                    "pcap_path": capture_session.pcap_path,
                    "error_message": capture_session.error_message,
                },
            )

        try:
            self._event("prepare_sessions_started", {"selected_devices": selected_udids})
            self._prepare_sessions(selected, ledger)
            self._event("prepare_sessions_completed", {"selected_devices": selected_udids})
            self._recover_unhealthy_sessions(selected, ledger)
            self._write_session_snapshots(selected)
            while time.time() < deadline and not self._stop_requested():
                remaining = int(deadline - time.time())
                if remaining <= max(2, self.action_policy.dwell_min_seconds // 3):
                    self._event("run_stopped_due_to_remaining_budget", {"remaining_seconds": remaining})
                    break
                healthy = self._healthy_sessions(selected)
                if not healthy:
                    self._recover_unhealthy_sessions(selected, ledger)
                    self._write_session_snapshots(selected)
                    healthy = self._healthy_sessions(selected)
                if not healthy:
                    final_mode = "degraded"
                    self._event("no_healthy_sessions", {"selected_devices": selected_udids})
                    break
                if len(healthy) < len(selected):
                    final_mode = "degraded"
                round_index = rounds_completed + 1
                network_state = self.network_monitor.latest_state if network_monitor_started else "NORMAL"
                concurrency_decision = self.concurrency_controller.select_sessions(healthy, network_state)
                selected_for_round = set(concurrency_decision.selected_udids)
                round_sessions = [session for session in healthy if session.profile.udid in selected_for_round]
                if not round_sessions:
                    final_mode = "degraded"
                    self._event("no_active_sessions_after_network_adaptation", concurrency_decision.as_dict())
                    break
                self._event(
                    "round_started",
                    {
                        "round_index": round_index,
                        "healthy_devices": [session.profile.udid for session in healthy],
                        "network_adaptation": concurrency_decision.as_dict(),
                    },
                )
                if getattr(self.config, "timeline_scheduler_enabled", True):
                    round_seconds = min(
                        int(getattr(self.config, "scheduling_round_seconds", 180)),
                        max(1, int(deadline - time.time())),
                    )
                    round_artifact = self._run_timeline_round(
                        round_sessions,
                        round_index=round_index,
                        round_seconds=round_seconds,
                        deadline=deadline,
                        ledger=ledger,
                        network_adaptation=concurrency_decision.as_dict(),
                    )
                else:
                    round_artifact = self._run_one_round(
                        round_sessions,
                        round_index=round_index,
                        deadline=deadline,
                        ledger=ledger,
                    )
                self.status_writer.write_group_result(round_artifact)
                self._write_session_snapshots(selected)
                self._recover_unhealthy_sessions(selected, ledger)
                rounds_completed = round_index
                self._event("round_completed", {"round_index": round_index, "artifact": round_artifact})
        except KeyboardInterrupt:
            interrupted = True
            final_mode = "interrupted"
            self._request_stop(
                "keyboard_interrupt",
                {
                    "run_id": run_id,
                    "rounds_completed": rounds_completed,
                    "selected_devices": selected_udids,
                },
            )
            self._event(
                "manual_stop_requested",
                {
                    "run_id": run_id,
                    "rounds_completed": rounds_completed,
                    "selected_devices": selected_udids,
                },
            )
        finally:
            with self._defer_keyboard_interrupt_during_finalization(run_id):
                closed_windows = self.traffic_probe_manager.close_open_windows(
                    success=False,
                    error_message="manual_stop_requested" if interrupted else "run_finalized",
                    extra={"final_mode": final_mode},
                )
                if closed_windows:
                    self._event(
                        "open_windows_closed",
                        {
                            "closed_window_count": closed_windows,
                            "reason": "manual_stop_requested" if interrupted else "run_finalized",
                        },
                    )
                if network_monitor_started:
                    network_summary = self.network_monitor.stop()
                    self._event("network_health_monitor_stopped", network_summary)
                if capture_session is not None:
                    capture_result = self.capture_manager.stop_capture(
                        capture_session,
                        selected_devices=selected_udids,
                        target_package=target_package,
                    )
                    traffic_capture_dir = str(Path(capture_result.etl_path).parent)
                    self._event(
                        "traffic_capture_stopped",
                        {
                            "status": capture_result.status,
                            "etl_path": capture_result.etl_path,
                            "pcapng_path": capture_result.pcapng_path,
                            "pcap_path": capture_result.pcap_path,
                            "error_message": capture_result.error_message,
                        },
                    )
        with self._defer_keyboard_interrupt_during_finalization(run_id):
            ended_at = datetime.now().isoformat(timespec="seconds")
            if interrupted:
                summary = (
                    f"manual stop after {rounds_completed} Douyin feed rounds across "
                    f"{len(selected_udids)} selected devices; artifacts finalized"
                )
            else:
                summary = (
                    f"completed {rounds_completed} Douyin feed rounds across "
                    f"{len(selected_udids)} selected devices in {final_mode} mode"
                )
            self._finalize_probe(
                run_id=run_id,
                selected_udids=selected_udids,
                rounds_completed=rounds_completed,
                final_mode=final_mode,
                summary=summary,
                started_at=started_at,
                ended_at=ended_at,
                ledger=ledger,
                network_summary=network_summary,
            )
            run_result = DouyinFeedRunResult(
                experiment_id=run_id,
                started_at=started_at,
                ended_at=ended_at,
                selected_devices=selected_udids,
                rounds_completed=rounds_completed,
                final_mode=final_mode,
                traffic_probe_dir=traffic_probe_dir,
                traffic_capture_dir=traffic_capture_dir,
                summary=summary,
            )
            self.status_writer.write_experiment_result(run_result)
            return run_result

    def _prepare_sessions(self, sessions, ledger) -> None:
        results = []
        for session in sessions:
            self._event("prepare_session_begin", {"udid": session.profile.udid})
            result = self.action_executor.ensure_feed(session)
            results.append(result)
            self._write_session_snapshots([session])
            self._event(
                "prepare_session_end",
                {
                    "udid": session.profile.udid,
                    "success": result.success,
                    "scene_type": result.scene_type,
                    "error_message": result.error_message,
                },
            )
        for result in results:
            ledger.append(
                {
                    "event": "ensure_feed",
                    "udid": result.udid,
                    "success": result.success,
                    "scene_type": result.scene_type,
                    "video_signature": result.video_signature,
                    "duration_ms": result.duration_ms,
                    "error_message": result.error_message,
                    "ts": time.time(),
                }
            )
            self._append_guard_trace(ledger, source_event="ensure_feed", result=result)

    def _run_timeline_round(
        self,
        sessions,
        round_index: int,
        round_seconds: int,
        deadline: float,
        ledger,
        network_adaptation: dict[str, Any],
    ) -> dict[str, Any]:
        mode = "timeline"
        timeline = self.timeline_planner.build(sessions, round_index=round_index, round_seconds=round_seconds)
        timeline_payload = timeline.as_dict()
        self._event(
            "timeline_round_planned",
            {
                "round_index": round_index,
                "round_seconds": round_seconds,
                "network_adaptation": network_adaptation,
                "timeline": timeline_payload,
            },
        )
        ledger.append(
            {
                "event": "timeline_round_planned",
                "round_index": round_index,
                "round_seconds": round_seconds,
                "active_devices": [session.profile.udid for session in sessions],
                "network_adaptation": network_adaptation,
                "staggered_count": timeline_payload["staggered_count"],
                "skipped_count": timeline_payload["skipped_count"],
                "ts": time.time(),
            }
        )
        round_start_monotonic = time.monotonic()
        executor = ThreadPoolExecutor(max_workers=max(1, len(sessions)))
        future_map = {
            executor.submit(
                self._run_device_timeline,
                session,
                timeline.segments_by_udid.get(session.profile.udid, []),
                round_start_monotonic,
                deadline,
                round_index,
                mode,
                ledger,
            ): session
            for session in sessions
        }
        timeout_seconds = round_seconds + float(getattr(self.config, "per_action_timeout_seconds", 20.0))
        try:
            done, pending = wait(set(future_map), timeout=timeout_seconds)
        except KeyboardInterrupt:
            self._request_stop(
                "keyboard_interrupt_timeline_round",
                {
                    "round_index": round_index,
                    "active_devices": [session.profile.udid for session in sessions],
                },
            )
            stop_wait_seconds = max(0.5, float(getattr(self.config, "manual_stop_grace_seconds", 8.0)))
            done, pending = wait(set(future_map), timeout=stop_wait_seconds)
            for future in pending:
                future.cancel()
            self._event(
                "timeline_round_interrupted",
                {
                    "round_index": round_index,
                    "completed_devices": [future_map[future].profile.udid for future in done],
                    "pending_devices": [future_map[future].profile.udid for future in pending],
                    "stop_wait_seconds": stop_wait_seconds,
                },
            )
            executor.shutdown(wait=False, cancel_futures=True)
            raise
        device_results: list[dict[str, Any]] = []
        for future in done:
            session = future_map[future]
            try:
                device_results.append(future.result())
            except Exception as exc:
                failure = {
                    "udid": session.profile.udid,
                    "success": False,
                    "error_message": str(exc),
                    "successful_swipes": 0,
                    "successful_dwells": 0,
                    "scheduled_engagement_results": [],
                }
                device_results.append(failure)
                ledger.append({"event": "timeline_device_exception", "round_index": round_index, **failure, "ts": time.time()})
        for future in pending:
            session = future_map[future]
            future.cancel()
            if hasattr(session, "record_action_failure"):
                session.record_action_failure("timeline_round_timeout", category="action_timeout")
            timeout_result = {
                "udid": session.profile.udid,
                "success": False,
                "error_message": "timeline_round_timeout",
                "successful_swipes": 0,
                "successful_dwells": 0,
                "scheduled_engagement_results": [],
            }
            device_results.append(timeout_result)
            ledger.append({"event": "timeline_device_timeout", "round_index": round_index, **timeout_result, "ts": time.time()})
            self._event("timeline_device_timeout", {"round_index": round_index, **timeout_result})
        executor.shutdown(wait=False, cancel_futures=True)
        return {
            "round_index": round_index,
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "mode": mode,
            "round_seconds": round_seconds,
            "active_devices": [session.profile.udid for session in sessions],
            "network_adaptation": network_adaptation,
            "timeline": timeline_payload,
            "device_results": device_results,
            "successful_swipes": sum(item.get("successful_swipes", 0) for item in device_results),
            "successful_dwells": sum(item.get("successful_dwells", 0) for item in device_results),
            "scheduled_engagement_results": [
                engagement
                for item in device_results
                for engagement in item.get("scheduled_engagement_results", [])
            ],
            "successful_likes": 0,
            "successful_favorites": 0,
        }

    def _run_device_timeline(
        self,
        session,
        segments: list[TimelineSegment],
        round_start_monotonic: float,
        deadline: float,
        round_index: int,
        mode: str,
        ledger,
    ) -> dict[str, Any]:
        successful_swipes = 0
        successful_dwells = 0
        engagement_results: list[dict[str, Any]] = []
        for segment in segments:
            if self._stop_requested():
                return self._build_timeline_stop_result(
                    session=session,
                    successful_swipes=successful_swipes,
                    successful_dwells=successful_dwells,
                    engagement_results=engagement_results,
                    round_index=round_index,
                    mode=mode,
                    ledger=ledger,
                )
            if segment.skipped:
                row = {
                    "event": "timeline_page_turn_skipped",
                    "round_index": round_index,
                    "mode": mode,
                    "udid": session.profile.udid,
                    "video_index": segment.video_index,
                    "skip_reason": segment.skip_reason,
                    "original_page_turn_offset": segment.original_page_turn_offset,
                    "page_turn_offset": segment.page_turn_offset,
                    "ts": time.time(),
                }
                ledger.append(row)
                self._event("timeline_page_turn_skipped", row)
                continue
            self._sleep_until(round_start_monotonic + segment.page_turn_offset, deadline)
            if self._stop_requested():
                return self._build_timeline_stop_result(
                    session=session,
                    successful_swipes=successful_swipes,
                    successful_dwells=successful_dwells,
                    engagement_results=engagement_results,
                    round_index=round_index,
                    mode=mode,
                    ledger=ledger,
                )
            if time.time() >= deadline:
                break
            attempt_index = 0
            while time.time() < deadline and not self._stop_requested():
                attempt_index += 1
                attempt_meta = {
                    "attempt_index": attempt_index,
                    "effective_video_retry": attempt_index > 1,
                }
                self._event(
                    "timeline_page_turn_due",
                    {
                        "round_index": round_index,
                        "segment": segment.as_dict(),
                        **attempt_meta,
                    },
                )
                if self._stop_requested():
                    return self._build_timeline_stop_result(
                        session=session,
                        successful_swipes=successful_swipes,
                        successful_dwells=successful_dwells,
                        engagement_results=engagement_results,
                        round_index=round_index,
                        mode=mode,
                        ledger=ledger,
                    )
                swipe_result = self.action_executor.advance_to_next_collectable_video(session)
                ledger.append(
                    {
                        "event": "timeline_swipe_next_video",
                        "executor_action": swipe_result.action_name,
                        "round_index": round_index,
                        "mode": mode,
                        "udid": swipe_result.udid,
                        "success": swipe_result.success,
                        "scene_type": swipe_result.scene_type,
                        "video_signature": swipe_result.video_signature,
                        "duration_ms": swipe_result.duration_ms,
                        "error_message": swipe_result.error_message,
                        "segment": segment.as_dict(),
                        **attempt_meta,
                        "ts": time.time(),
                    }
                )
                self._append_guard_trace(
                    ledger,
                    source_event="timeline_swipe_next_video",
                    result=swipe_result,
                    round_index=round_index,
                    mode=mode,
                )
                if not swipe_result.success:
                    if self._is_immediate_skip_result(swipe_result):
                        self._record_content_skip(
                            ledger=ledger,
                            source_event="timeline_swipe_next_video",
                            result=swipe_result,
                            segment=segment,
                            round_index=round_index,
                            mode=mode,
                            attempt_meta=attempt_meta,
                        )
                        self._sleep_before_immediate_retry(deadline)
                        if self._stop_requested():
                            return self._build_timeline_stop_result(
                                session=session,
                                successful_swipes=successful_swipes,
                                successful_dwells=successful_dwells,
                                engagement_results=engagement_results,
                                round_index=round_index,
                                mode=mode,
                                ledger=ledger,
                            )
                        continue
                    break
                successful_swipes += 1
                dwell_seconds = min(segment.dwell_seconds, max(1, int(deadline - time.time())))
                window_id = self.traffic_probe_manager.open_window(
                    udid=session.profile.udid,
                    action_type="view_window",
                    video_signature=swipe_result.video_signature,
                    metadata={
                        "round_index": round_index,
                        "mode": mode,
                        "timeline_segment": segment.as_dict(),
                        "planned_dwell_seconds": dwell_seconds,
                        **attempt_meta,
                    },
                )
                dwell_result = self.action_executor.dwell_on_current_video(
                    session,
                    dwell_seconds,
                    scheduled_actions=segment.engagement_schedule,
                    engagement_callback=self._record_engagement_marker,
                    stop_event=self._stop_event,
                )
                self.traffic_probe_manager.close_window(
                    window_id,
                    success=dwell_result.success,
                    error_message=dwell_result.error_message,
                    extra={
                        "actual_dwell_seconds": dwell_seconds,
                        "duration_ms": dwell_result.duration_ms,
                        "timeline_segment": segment.as_dict(),
                        **attempt_meta,
                    },
                )
                if dwell_result.success:
                    successful_dwells += 1
                engagement_results.extend(getattr(dwell_result, "engagement_trace", []) or [])
                ledger.append(
                    {
                        "event": "timeline_dwell_on_current_video",
                        "round_index": round_index,
                        "mode": mode,
                        "udid": dwell_result.udid,
                        "success": dwell_result.success,
                        "scene_type": dwell_result.scene_type,
                        "video_signature": dwell_result.video_signature,
                        "duration_ms": dwell_result.duration_ms,
                        "dwell_seconds": dwell_result.dwell_seconds,
                        "error_message": dwell_result.error_message,
                        "segment": segment.as_dict(),
                        **attempt_meta,
                        "ts": time.time(),
                    }
                )
                self._append_guard_trace(
                    ledger,
                    source_event="timeline_dwell_on_current_video",
                    result=dwell_result,
                    round_index=round_index,
                    mode=mode,
                )
                self._append_engagement_trace(
                    ledger,
                    source_event="timeline_dwell_on_current_video",
                    result=dwell_result,
                    round_index=round_index,
                    mode=mode,
                )
                if dwell_result.success:
                    break
                if self._is_immediate_skip_result(dwell_result):
                    self._record_content_skip(
                        ledger=ledger,
                        source_event="timeline_dwell_on_current_video",
                        result=dwell_result,
                        segment=segment,
                        round_index=round_index,
                        mode=mode,
                        attempt_meta=attempt_meta,
                    )
                    self._sleep_before_immediate_retry(deadline)
                    if self._stop_requested():
                        return self._build_timeline_stop_result(
                            session=session,
                            successful_swipes=successful_swipes,
                            successful_dwells=successful_dwells,
                            engagement_results=engagement_results,
                            round_index=round_index,
                            mode=mode,
                            ledger=ledger,
                        )
                    continue
                break
        return {
            "udid": session.profile.udid,
            "success": True,
            "successful_swipes": successful_swipes,
            "successful_dwells": successful_dwells,
            "scheduled_engagement_results": engagement_results,
        }

    def _build_timeline_stop_result(
        self,
        session,
        successful_swipes: int,
        successful_dwells: int,
        engagement_results: list[dict[str, Any]],
        round_index: int,
        mode: str,
        ledger,
    ) -> dict[str, Any]:
        result = {
            "udid": session.profile.udid,
            "success": False,
            "error_message": "manual_stop_requested",
            "successful_swipes": successful_swipes,
            "successful_dwells": successful_dwells,
            "scheduled_engagement_results": engagement_results,
        }
        row = {
            "event": "timeline_device_stop_ack",
            "round_index": round_index,
            "mode": mode,
            **result,
            "ts": time.time(),
        }
        ledger.append(row)
        self._event("timeline_device_stop_ack", row)
        return result

    def _record_content_skip(
        self,
        ledger,
        source_event: str,
        result,
        segment: TimelineSegment,
        round_index: int,
        mode: str,
        attempt_meta: dict[str, Any],
    ) -> None:
        row = {
            "event": "timeline_content_skipped_without_consuming_segment",
            "source_event": source_event,
            "round_index": round_index,
            "mode": mode,
            "udid": result.udid,
            "reason": result.error_message or result.guard_reason,
            "guard_reason": result.guard_reason,
            "guard_decision": result.guard_decision,
            "scene_type": result.scene_type,
            "video_signature": result.video_signature,
            "segment": segment.as_dict(),
            **attempt_meta,
            "ts": time.time(),
        }
        ledger.append(row)
        self._event(row["event"], row)

    def _is_immediate_skip_result(self, result) -> bool:
        reasons = [
            str(getattr(result, "error_message", "")),
            str(getattr(result, "guard_reason", "")),
            str(getattr(result, "guard_decision", "")),
        ]
        for item in getattr(result, "guard_trace", []) or []:
            reasons.append(str(item.get("reason", "")))
            reasons.append(str(item.get("decision", "")))
        text = " ".join(reasons).lower()
        retry_tokens = (
            "skip_ad",
            "skip_product",
            "skip_live",
            "skip_scene:product",
            "skip_scene:shop",
            "page_guard_skip_failed",
            "page_guard_changed:skip_",
        )
        return any(token in text for token in retry_tokens)

    def _sleep_before_immediate_retry(self, deadline: float) -> None:
        remaining = max(0.0, deadline - time.time())
        if remaining <= 0.3:
            return
        self._stop_event.wait(min(random.SystemRandom().uniform(0.3, 1.2), remaining))

    def _sleep_until(self, target_monotonic: float, deadline: float) -> None:
        while time.monotonic() < target_monotonic and time.time() < deadline and not self._stop_requested():
            self._stop_event.wait(min(0.5, max(0.0, target_monotonic - time.monotonic())))

    def _run_one_round(self, sessions, round_index: int, deadline: float, ledger) -> dict[str, Any]:
        mode = "sync" if len(sessions) == self.config.sync_device_limit else "degraded"
        swipe_results = self._run_parallel(
            sessions,
            lambda session: self.action_executor.swipe_next_video(session),
            action_name="swipe_next_video",
        )
        swipe_rows = [self._result_to_dict(result) for result in swipe_results]
        successful_sessions = {
            result.udid: session
            for session, result in zip(sessions, swipe_results)
            if result.success
        }
        dwell_windows: dict[str, tuple[str, int]] = {}
        dwell_plan: list[tuple[Any, int, list[Any]]] = []
        for result in swipe_results:
            ledger.append(
                {
                    "event": "swipe_next_video",
                    "round_index": round_index,
                    "mode": mode,
                    "udid": result.udid,
                    "success": result.success,
                    "scene_type": result.scene_type,
                    "video_signature": result.video_signature,
                    "duration_ms": result.duration_ms,
                    "error_message": result.error_message,
                    "ts": time.time(),
                }
            )
            self._append_guard_trace(
                ledger,
                source_event="swipe_next_video",
                result=result,
                round_index=round_index,
                mode=mode,
            )
            session = successful_sessions.get(result.udid)
            if session is None:
                continue
            remaining_budget = max(1, int(deadline - time.time()) - 1)
            dwell_seconds = min(self.action_policy.next_dwell_seconds(), remaining_budget)
            if dwell_seconds <= 0:
                continue
            engagement_schedule = self.action_policy.build_engagement_schedule(dwell_seconds)
            window_id = self.traffic_probe_manager.open_window(
                udid=result.udid,
                action_type="view_window",
                video_signature=result.video_signature,
                metadata={
                    "round_index": round_index,
                    "mode": mode,
                    "planned_dwell_seconds": dwell_seconds,
                    "engagement_schedule": [item.as_dict() for item in engagement_schedule],
                },
            )
            dwell_windows[result.udid] = (window_id, dwell_seconds)
            dwell_plan.append((session, dwell_seconds, engagement_schedule))

        dwell_results = self._run_parallel_dwell(dwell_plan)
        dwell_rows = [self._result_to_dict(result) for result in dwell_results]
        engagement_sessions = [
            session
            for session, result in zip((item[0] for item in dwell_plan), dwell_results)
            if result.success
        ]
        for result in dwell_results:
            window_id, dwell_seconds = dwell_windows.get(result.udid, ("", result.dwell_seconds))
            if window_id:
                self.traffic_probe_manager.close_window(
                    window_id,
                    success=result.success,
                    error_message=result.error_message,
                    extra={
                        "actual_dwell_seconds": dwell_seconds,
                        "duration_ms": result.duration_ms,
                    },
                )
            ledger.append(
                {
                    "event": "dwell_on_current_video",
                    "round_index": round_index,
                    "mode": mode,
                    "udid": result.udid,
                    "success": result.success,
                    "scene_type": result.scene_type,
                    "video_signature": result.video_signature,
                    "duration_ms": result.duration_ms,
                    "dwell_seconds": result.dwell_seconds,
                    "error_message": result.error_message,
                    "ts": time.time(),
                }
            )
            self._append_guard_trace(
                ledger,
                source_event="dwell_on_current_video",
                result=result,
                round_index=round_index,
                mode=mode,
            )
            self._append_engagement_trace(
                ledger,
                source_event="dwell_on_current_video",
                result=result,
                round_index=round_index,
                mode=mode,
            )

        successful_scheduled_engagements = self._successful_scheduled_engagements(dwell_results)

        like_results = []
        like_sessions = [
            session
            for session in engagement_sessions
            if (session.profile.udid, "like_current_video") not in successful_scheduled_engagements
        ]
        if self._automatic_engagement_enabled("like_current_video") and self.action_policy.enable_like and like_sessions:
            like_results = self._run_parallel_action_window(
                like_sessions,
                action_type="like_current_video",
                round_index=round_index,
                mode=mode,
                operation=lambda session: self.action_executor.like_current_video(session),
            )
            self._append_action_results(
                ledger,
                event_name="like_current_video",
                round_index=round_index,
                mode=mode,
                results=like_results,
            )

        favorite_results = []
        favorite_sessions = [
            session
            for session in engagement_sessions
            if (session.profile.udid, "favorite_current_video") not in successful_scheduled_engagements
        ]
        if self._automatic_engagement_enabled("favorite_current_video") and self.action_policy.enable_favorite and favorite_sessions:
            favorite_results = self._run_parallel_action_window(
                favorite_sessions,
                action_type="favorite_current_video",
                round_index=round_index,
                mode=mode,
                operation=lambda session: self.action_executor.favorite_current_video(session),
            )
            self._append_action_results(
                ledger,
                event_name="favorite_current_video",
                round_index=round_index,
                mode=mode,
                results=favorite_results,
            )

        return {
            "round_index": round_index,
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "mode": mode,
            "active_devices": [session.profile.udid for session in sessions],
            "swipe_results": swipe_rows,
            "dwell_results": dwell_rows,
            "scheduled_engagement_results": self._collect_engagement_traces(dwell_results),
            "like_results": [self._result_to_dict(result) for result in like_results],
            "favorite_results": [self._result_to_dict(result) for result in favorite_results],
            "successful_swipes": sum(1 for item in swipe_results if item.success),
            "successful_dwells": sum(1 for item in dwell_results if item.success),
            "successful_likes": sum(1 for item in like_results if item.success),
            "successful_favorites": sum(1 for item in favorite_results if item.success),
        }

    @staticmethod
    def _append_action_results(ledger, event_name: str, round_index: int, mode: str, results) -> None:
        for result in results:
            ledger.append(
                {
                    "event": event_name,
                    "round_index": round_index,
                    "mode": mode,
                    "udid": result.udid,
                    "success": result.success,
                    "scene_type": result.scene_type,
                    "video_signature": result.video_signature,
                    "duration_ms": result.duration_ms,
                    "error_message": result.error_message,
                    "ts": time.time(),
                }
            )

    def _append_guard_trace(
        self,
        ledger,
        source_event: str,
        result,
        round_index: int | None = None,
        mode: str = "",
    ) -> None:
        for guard_item in getattr(result, "guard_trace", []) or []:
            row = {
                "event": "page_guard_decision",
                "source_event": source_event,
                "round_index": round_index,
                "mode": mode,
                "udid": result.udid,
                "decision": guard_item.get("decision", ""),
                "reason": guard_item.get("reason", ""),
                "scene_type": guard_item.get("scene_type", ""),
                "scene_value": guard_item.get("scene_value", ""),
                "confidence": guard_item.get("confidence", 0.0),
                "package_name": guard_item.get("package_name", ""),
                "activity_name": guard_item.get("activity_name", ""),
                "attempt": guard_item.get("attempt", 0),
                "keywords": guard_item.get("keywords", []),
                "duration_ms": guard_item.get("duration_ms", 0),
                "ts": time.time(),
            }
            ledger.append(row)
            self._event("page_guard_decision", row)

    def _append_engagement_trace(
        self,
        ledger,
        source_event: str,
        result,
        round_index: int | None = None,
        mode: str = "",
    ) -> None:
        for engagement_item in getattr(result, "engagement_trace", []) or []:
            row = {
                "event": engagement_item.get("event", "scheduled_engagement_window"),
                "source_event": source_event,
                "round_index": round_index,
                "mode": mode,
                "udid": result.udid,
                "action_type": engagement_item.get("action_type", ""),
                "planned_at_seconds": engagement_item.get("planned_at_seconds", 0),
                "actual_elapsed_seconds": engagement_item.get("actual_elapsed_seconds", 0),
                "video_signature": engagement_item.get("video_signature", result.video_signature),
                "window_id": engagement_item.get("window_id", ""),
                "success": engagement_item.get("success", False),
                "execution_mode": engagement_item.get("execution_mode", "audit_only"),
                "skip_reason": engagement_item.get("skip_reason", ""),
                "duration_ms": engagement_item.get("duration_ms", 0),
                "scene_type": engagement_item.get("scene_type", ""),
                "result_video_signature": engagement_item.get("result_video_signature", ""),
                "error_message": engagement_item.get("error_message", ""),
                "ts": engagement_item.get("ts", time.time()),
            }
            ledger.append(row)
            self._event(row["event"], row)

    @staticmethod
    def _collect_engagement_traces(results) -> list[dict[str, Any]]:
        traces: list[dict[str, Any]] = []
        for result in results:
            traces.extend(getattr(result, "engagement_trace", []) or [])
        return traces

    @staticmethod
    def _successful_scheduled_engagements(results) -> set[tuple[str, str]]:
        successful: set[tuple[str, str]] = set()
        for result in results:
            for item in getattr(result, "engagement_trace", []) or []:
                if not bool(item.get("success", False)):
                    continue
                action_type = str(item.get("action_type", ""))
                if action_type:
                    successful.add((result.udid, action_type))
        return successful

    def _automatic_engagement_enabled(self, action_type: str) -> bool:
        if not bool(getattr(self.config, "automatic_engagement_enabled", True)):
            return False
        if action_type == "like_current_video":
            return bool(getattr(self.config, "enable_like", False))
        if action_type == "favorite_current_video":
            return bool(getattr(self.config, "enable_favorite", False))
        return False

    def _healthy_sessions(self, sessions):
        healthy = []
        for session in sessions:
            status = session.refresh_state()
            if status.health_state in {DeviceHealthState.INIT, DeviceHealthState.READY, DeviceHealthState.OFFLINE}:
                healthy.append(session)
                continue
            if status.health_state == DeviceHealthState.BUSY:
                healthy.append(session)
        return healthy

    def _recover_unhealthy_sessions(self, sessions, ledger) -> None:
        for session in sessions:
            status = session.refresh_state()
            if session.state_monitor.should_recover(status):
                recovered = self.recovery_policy.recover_session(
                    session,
                    reason=f"feed_round_recovery:{status.last_failure_category or status.health_state.value}",
                )
                ledger.append(
                    {
                        "event": "recovery",
                        "udid": session.profile.udid,
                        "success": recovered,
                        "health_state": session.status.health_state,
                        "failure_category": session.status.last_failure_category,
                        "recovery_level": session.status.last_recovery_level,
                        "consecutive_failures": session.status.consecutive_failures,
                        "error_message": session.status.last_error,
                        "ts": time.time(),
                    }
                )
                self._event(
                    "recovery",
                    {
                        "udid": session.profile.udid,
                        "success": recovered,
                        "health_state": session.status.health_state,
                        "failure_category": session.status.last_failure_category,
                        "recovery_level": session.status.last_recovery_level,
                        "consecutive_failures": session.status.consecutive_failures,
                        "error_message": session.status.last_error,
                    },
                )

    def _run_parallel(self, sessions, operation: Callable[[Any], Any], action_name: str = "parallel_operation") -> list[Any]:
        return self.parallel_action_runner.run(
            sessions=sessions,
            operation=operation,
            action_name=action_name,
            timeout_seconds=float(getattr(self.config, "per_action_timeout_seconds", self.config.action_timeout_seconds)),
        )

    def _run_parallel_dwell(self, plan: list[tuple[Any, int, list[Any]]]) -> list[Any]:
        if not plan:
            return []
        dwell_seconds_by_udid = {session.profile.udid: dwell_seconds for session, dwell_seconds, _ in plan}
        schedule_by_udid = {session.profile.udid: schedule for session, _, schedule in plan}
        timeout_by_udid = {
            session.profile.udid: dwell_seconds + float(getattr(self.config, "per_dwell_extra_timeout_seconds", 8))
            for session, dwell_seconds, _ in plan
        }
        return self.parallel_action_runner.run(
            sessions=[session for session, _, _ in plan],
            operation=lambda session: self.action_executor.dwell_on_current_video(
                session,
                dwell_seconds_by_udid[session.profile.udid],
                scheduled_actions=schedule_by_udid.get(session.profile.udid, []),
                engagement_callback=self._record_engagement_marker,
                stop_event=self._stop_event,
            ),
            action_name="dwell_on_current_video",
            timeout_seconds=max(timeout_by_udid.values()),
            timeout_by_udid=timeout_by_udid,
            dwell_seconds_by_udid=dwell_seconds_by_udid,
        )

    def _record_engagement_marker(
        self,
        session,
        action,
        video_signature: str,
        elapsed_seconds: int,
    ) -> dict[str, Any]:
        action_type = getattr(action, "action_type", "")
        enabled = self._automatic_engagement_enabled(action_type)
        window_id = self.traffic_probe_manager.open_window(
            udid=session.profile.udid,
            action_type=action_type,
            video_signature=video_signature,
            metadata={
                "planned_at_seconds": int(getattr(action, "planned_at_seconds", 0)),
                "actual_elapsed_seconds": elapsed_seconds,
                "execution_mode": "auto_click" if enabled else "audit_only",
            },
        )
        marker_seconds = 0.0
        result = None
        error_message = "automatic_engagement_disabled"
        if enabled:
            if action_type == "like_current_video":
                result = self.action_executor.like_current_video(session)
            elif action_type == "favorite_current_video":
                result = self.action_executor.favorite_current_video(session)
            else:
                error_message = f"unsupported_engagement_action:{action_type}"
        else:
            marker_seconds = max(0.0, float(getattr(self.action_policy, "engagement_marker_window_seconds", 1.0)))
            if marker_seconds:
                self._stop_event.wait(marker_seconds)
        success = bool(result.success) if result is not None else False
        if result is not None:
            error_message = result.error_message
        self.traffic_probe_manager.close_window(
            window_id,
            success=success,
            error_message=error_message,
            extra={
                "planned_at_seconds": int(getattr(action, "planned_at_seconds", 0)),
                "actual_elapsed_seconds": elapsed_seconds,
                "execution_mode": "auto_click" if enabled else "audit_only",
                "duration_ms": result.duration_ms if result is not None else int(marker_seconds * 1000),
                "scene_type": result.scene_type if result is not None else session.status.last_scene,
                "result_video_signature": result.video_signature if result is not None else video_signature,
            },
        )
        return {
            "window_id": window_id,
            "success": success,
            "execution_mode": "auto_click" if enabled else "audit_only",
            "error_message": error_message,
            "duration_ms": result.duration_ms if result is not None else int(marker_seconds * 1000),
            "scene_type": result.scene_type if result is not None else session.status.last_scene,
            "result_video_signature": result.video_signature if result is not None else video_signature,
            "marker_duration_ms": int(marker_seconds * 1000),
        }

    def _build_parallel_failure(
        self,
        session,
        action_name: str,
        error_message: str,
        dwell_seconds: int = 0,
    ):
        return self.action_executor.build_generic_failure(
            session=session,
            action_name=action_name,
            error_message=error_message,
            dwell_seconds=dwell_seconds,
        )

    def _run_parallel_action_window(
        self,
        sessions,
        action_type: str,
        round_index: int,
        mode: str,
        operation: Callable[[Any], Any],
    ) -> list[Any]:
        windows_by_udid: dict[str, str] = {}
        for session in sessions:
            video_signature = ""
            try:
                snapshot = session.capture_page()
                video_signature = self.action_executor.verifier.build_video_signature(snapshot)
            except Exception:
                video_signature = session.status.last_scene or ""
            windows_by_udid[session.profile.udid] = self.traffic_probe_manager.open_window(
                udid=session.profile.udid,
                action_type=action_type,
                video_signature=video_signature,
                metadata={
                    "round_index": round_index,
                    "mode": mode,
                },
            )
        results = self._run_parallel(sessions, operation, action_name=action_type)
        for result in results:
            window_id = windows_by_udid.get(result.udid, "")
            if not window_id:
                continue
            self.traffic_probe_manager.close_window(
                window_id,
                success=result.success,
                error_message=result.error_message,
                extra={
                    "duration_ms": result.duration_ms,
                    "scene_type": result.scene_type,
                    "result_video_signature": result.video_signature,
                },
            )
        return results

    def _write_session_snapshots(self, sessions) -> None:
        for session in sessions:
            self.status_writer.write_session_status(session.snapshot_status(), session.profile.udid)

    def _request_stop(self, reason: str, payload: dict[str, Any] | None = None) -> None:
        already_requested = self._stop_event.is_set()
        self._stop_event.set()
        if already_requested:
            return
        event_payload = {"reason": reason}
        if payload:
            event_payload.update(payload)
        self._event("cooperative_stop_requested", event_payload)

    def _stop_requested(self) -> bool:
        return self._stop_event.is_set()

    @contextmanager
    def _defer_keyboard_interrupt_during_finalization(self, run_id: str):
        previous_handler = signal.getsignal(signal.SIGINT)

        def _handler(signum, _frame):
            self._event(
                "finalization_interrupt_deferred",
                {
                    "run_id": run_id,
                    "signal": int(signum),
                    "message": "Ctrl+C received during artifact finalization and deferred",
                },
            )

        installed = False
        try:
            try:
                signal.signal(signal.SIGINT, _handler)
                installed = True
            except ValueError:
                installed = False
            yield
        finally:
            if installed:
                signal.signal(signal.SIGINT, previous_handler)

    def _finalize_probe(
        self,
        run_id: str,
        selected_udids: list[str],
        rounds_completed: int,
        final_mode: str,
        summary: str,
        started_at: str,
        ended_at: str,
        ledger,
        network_summary: dict[str, Any] | None = None,
    ) -> None:
        ledger.flush()
        self.traffic_probe_manager.write_summary(
            {
                "run_id": run_id,
                "selected_devices": selected_udids,
                "rounds_completed": rounds_completed,
                "final_mode": final_mode,
                "summary": summary,
                "started_at": started_at,
                "ended_at": ended_at,
                "action_ledger_path": str(ledger.path),
                "network_summary": network_summary or {},
            }
        )

    @staticmethod
    def _result_to_dict(result) -> dict[str, Any]:
        return asdict(result)

    def _event(self, event_name: str, payload: dict[str, Any]) -> None:
        self.traffic_probe_manager.append_event(event_name, payload)
