"""Multi-device automation experiment package.

This package lives under a timestamped iteration folder so the original
`full_activation` code remains untouched.
"""

from __future__ import annotations

import sys
from pathlib import Path

iteration_root = Path(__file__).resolve().parents[1]
project_root = Path(__file__).resolve().parents[3]
if str(iteration_root) not in sys.path:
    sys.path.insert(0, str(iteration_root))
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

__all__ = ["__version__"]

__version__ = "0.1.0"
