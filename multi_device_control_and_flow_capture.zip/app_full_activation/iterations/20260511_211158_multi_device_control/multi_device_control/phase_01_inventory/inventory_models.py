from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class InventoryDeviceRecord:
    """One device snapshot collected from adb during precheck."""

    udid: str
    adb_state: str
    model: str = ""
    brand: str = ""
    android_version: str = ""
    screen_size: str = ""
    foreground_package: str = ""
    is_target_app_foreground: bool = False
    eligible: bool = False
    reason: str = ""
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class InventoryResult:
    """Full precheck result for all visible devices."""

    scanned_at: str
    total_count: int
    eligible_count: int
    target_package: str = ""
    devices: list[InventoryDeviceRecord] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "scanned_at": self.scanned_at,
            "total_count": self.total_count,
            "eligible_count": self.eligible_count,
            "target_package": self.target_package,
            "devices": [device.to_dict() for device in self.devices],
        }
