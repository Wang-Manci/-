from __future__ import annotations

import json
import re
import subprocess
from datetime import datetime
from pathlib import Path

from .inventory_models import InventoryDeviceRecord, InventoryResult


class DeviceInventoryService:
    """Discover adb-visible devices and collect stable runtime facts."""

    def __init__(self, adb_path: str = "adb") -> None:
        self.adb_path = adb_path

    def scan(self, target_package: str = "", allowed_udids: list[str] | None = None) -> InventoryResult:
        """Return a structured inventory snapshot for the current host."""

        allowed = set(allowed_udids or [])
        raw_devices = self._list_devices()
        records: list[InventoryDeviceRecord] = []
        for raw in raw_devices:
            udid = raw["udid"]
            if allowed and udid not in allowed:
                continue
            record = self.inspect_device(udid=udid, target_package=target_package)
            record.metadata.update(raw["metadata"])
            records.append(record)
        eligible_count = sum(record.eligible for record in records)
        return InventoryResult(
            scanned_at=datetime.now().isoformat(timespec="seconds"),
            total_count=len(records),
            eligible_count=eligible_count,
            target_package=target_package,
            devices=records,
        )

    def inspect_device(self, udid: str, target_package: str = "") -> InventoryDeviceRecord:
        """Collect one device status and normalize it into a single record."""

        adb_state = self._safe_command(["-s", udid, "get-state"]).stdout.strip() or "unknown"
        model = self._get_prop(udid, "ro.product.model")
        brand = self._get_prop(udid, "ro.product.brand")
        android_version = self._get_prop(udid, "ro.build.version.release")
        screen_size = self._get_screen_size(udid)
        foreground_package = self._get_foreground_package(udid)
        is_target_app_foreground = bool(target_package and foreground_package == target_package)
        eligible, reason = self._evaluate_eligibility(adb_state)
        return InventoryDeviceRecord(
            udid=udid,
            adb_state=adb_state,
            model=model,
            brand=brand,
            android_version=android_version,
            screen_size=screen_size,
            foreground_package=foreground_package,
            is_target_app_foreground=is_target_app_foreground,
            eligible=eligible,
            reason=reason,
        )

    def write_result(self, result: InventoryResult, output_path: str) -> str:
        """Persist the inventory result as UTF-8 JSON."""

        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def _list_devices(self) -> list[dict[str, object]]:
        completed = self._safe_command(["devices", "-l"])
        devices: list[dict[str, object]] = []
        for raw_line in completed.stdout.splitlines()[1:]:
            line = raw_line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            udid, state = parts[0], parts[1]
            metadata: dict[str, str] = {}
            for token in parts[2:]:
                if ":" not in token:
                    continue
                key, value = token.split(":", 1)
                metadata[key] = value
            devices.append({"udid": udid, "state": state, "metadata": metadata})
        return devices

    def _get_prop(self, udid: str, prop_name: str) -> str:
        completed = self._safe_command(["-s", udid, "shell", "getprop", prop_name])
        return completed.stdout.strip()

    def _get_screen_size(self, udid: str) -> str:
        completed = self._safe_command(["-s", udid, "shell", "wm", "size"])
        line = completed.stdout.strip()
        if ":" in line:
            return line.split(":", 1)[1].strip()
        return line

    def _get_foreground_package(self, udid: str) -> str:
        completed = self._safe_command(["-s", udid, "shell", "dumpsys", "window", "windows"], timeout_seconds=15)
        candidates = ("mCurrentFocus", "mFocusedApp")
        lines = [line.strip() for line in completed.stdout.splitlines() if any(token in line for token in candidates)]
        for line in lines:
            package = self._extract_package_name(line)
            if package:
                return package
        return ""

    @staticmethod
    def _extract_package_name(line: str) -> str:
        package_match = re.search(r"([A-Za-z0-9_.]+)/(?:[A-Za-z0-9_.$]+)", line)
        if package_match:
            return package_match.group(1)
        fallback = re.search(r"u\d+\s+([A-Za-z0-9_.]+)", line)
        if fallback:
            return fallback.group(1)
        return ""

    @staticmethod
    def _evaluate_eligibility(adb_state: str) -> tuple[bool, str]:
        normalized = adb_state.strip().lower()
        if normalized == "device":
            return True, "ready"
        if normalized == "offline":
            return False, "adb_offline"
        if normalized == "unauthorized":
            return False, "adb_unauthorized"
        if normalized:
            return False, f"adb_{normalized}"
        return False, "adb_unknown"

    def _safe_command(self, args: list[str], timeout_seconds: int = 10) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [self.adb_path, *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
