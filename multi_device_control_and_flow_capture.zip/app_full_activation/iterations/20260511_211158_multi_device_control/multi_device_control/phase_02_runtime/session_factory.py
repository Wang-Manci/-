from __future__ import annotations

from multi_device_control.phase_01_inventory import InventoryResult
from multi_device_control.phase_06_entry_and_artifacts.artifact_registry import ArtifactRegistry

from .device_adapter_v3 import DeviceAdapterV3
from .device_session import DeviceSession
from .device_state_monitor import DeviceHealthState, DeviceStateMonitor
from .fleet_config import FleetConfig


class SessionFactory:
    """Build runtime sessions from config and the latest inventory snapshot."""

    def __init__(self, config: FleetConfig, artifact_registry: ArtifactRegistry) -> None:
        self.config = config
        self.artifact_registry = artifact_registry
        self.state_monitor = DeviceStateMonitor(
            config.stalled_threshold_seconds,
            capture_page_failure_limit=config.capture_page_failure_limit,
            video_signature_stall_limit=config.video_signature_stall_limit,
            max_consecutive_failures=config.max_consecutive_failures,
        )

    def create_sessions(self, inventory: InventoryResult) -> list[DeviceSession]:
        eligible_by_udid = {device.udid: device for device in inventory.devices if device.eligible}
        sessions: list[DeviceSession] = []
        for profile in sorted(self.config.devices, key=lambda item: (item.priority, item.device_alias)):
            if not profile.enabled:
                continue
            if profile.udid not in eligible_by_udid:
                continue
            adapter = DeviceAdapterV3(profile=profile, artifact_registry=self.artifact_registry)
            sessions.append(DeviceSession(profile=profile, adapter=adapter, state_monitor=self.state_monitor))
        return sessions[: self.config.max_device_limit]

    def select_sync_group(self, sessions: list[DeviceSession], limit: int) -> list[DeviceSession]:
        ready_like = [
            session
            for session in sessions
            if session.status.health_state in {DeviceHealthState.INIT, DeviceHealthState.READY, DeviceHealthState.OFFLINE}
        ]
        return ready_like[:limit]
