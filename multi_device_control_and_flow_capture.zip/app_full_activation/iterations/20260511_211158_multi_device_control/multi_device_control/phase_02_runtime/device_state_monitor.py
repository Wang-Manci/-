from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum


class DeviceHealthState(str, Enum):
    INIT = "init"
    CONNECTING = "connecting"
    READY = "ready"
    BUSY = "busy"
    NETWORK_SLOW = "network_slow"
    STALLED = "stalled"
    RECOVERING = "recovering"
    QUARANTINED = "quarantined"
    OFFLINE = "offline"
    FAILED = "failed"


@dataclass(slots=True)
class DeviceSessionStatus:
    """Current coarse-grained health for one device session."""

    udid: str
    health_state: DeviceHealthState
    last_scene: str = ""
    last_action: str = ""
    last_error: str = ""
    recovery_attempts: int = 0
    last_heartbeat_ts: float = 0.0
    last_success_ts: float = 0.0
    consecutive_failures: int = 0
    capture_page_failures: int = 0
    signature_stall_count: int = 0
    last_video_signature: str = ""
    last_failure_category: str = ""
    last_recovery_level: str = ""
    quarantined_until_ts: float = 0.0


class DeviceStateMonitor:
    """Centralize device health transitions so controllers stay simple."""

    def __init__(
        self,
        stalled_threshold_seconds: float,
        capture_page_failure_limit: int = 2,
        video_signature_stall_limit: int = 2,
        max_consecutive_failures: int = 3,
    ) -> None:
        self.stalled_threshold_seconds = stalled_threshold_seconds
        self.capture_page_failure_limit = max(1, int(capture_page_failure_limit))
        self.video_signature_stall_limit = max(1, int(video_signature_stall_limit))
        self.max_consecutive_failures = max(1, int(max_consecutive_failures))

    def evaluate(self, session: "DeviceSession") -> DeviceSessionStatus:
        """Inspect session fields and return the most current status snapshot."""

        status = session.status
        now = time.time()
        if status.health_state == DeviceHealthState.QUARANTINED:
            if status.quarantined_until_ts and now >= status.quarantined_until_ts:
                status.health_state = DeviceHealthState.READY
                status.last_error = ""
            else:
                status.last_heartbeat_ts = now
                return status
        if not session.adapter.is_connected:
            if status.health_state not in {DeviceHealthState.INIT, DeviceHealthState.FAILED}:
                status.health_state = DeviceHealthState.OFFLINE
        elif status.health_state == DeviceHealthState.BUSY and session.action_started_at:
            if now - session.action_started_at > self.stalled_threshold_seconds:
                status.health_state = DeviceHealthState.STALLED
                if not status.last_error:
                    status.last_error = "action_stalled"
        if status.capture_page_failures >= self.capture_page_failure_limit:
            status.health_state = DeviceHealthState.STALLED
            status.last_failure_category = "capture_page_failed"
            if not status.last_error:
                status.last_error = "capture_page_failure_limit_reached"
        if status.signature_stall_count >= self.video_signature_stall_limit:
            status.health_state = DeviceHealthState.NETWORK_SLOW
            status.last_failure_category = "network_slow"
            if not status.last_error:
                status.last_error = "video_signature_stall_limit_reached"
        if status.consecutive_failures >= self.max_consecutive_failures:
            status.last_failure_category = status.last_failure_category or "consecutive_failures"
        status.last_heartbeat_ts = now
        return status

    def is_stalled(self, session: "DeviceSession") -> bool:
        return self.evaluate(session).health_state == DeviceHealthState.STALLED

    def should_recover(self, status: DeviceSessionStatus) -> bool:
        return status.health_state in {
            DeviceHealthState.STALLED,
            DeviceHealthState.NETWORK_SLOW,
            DeviceHealthState.OFFLINE,
            DeviceHealthState.FAILED,
        }
