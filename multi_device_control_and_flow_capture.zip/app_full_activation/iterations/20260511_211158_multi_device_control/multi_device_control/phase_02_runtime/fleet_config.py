from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class DeviceProfile:
    """Runtime connection settings for one device."""

    udid: str
    device_alias: str
    appium_server_url: str
    system_port: int
    target_app_package: str
    target_app_activity: str
    enabled: bool = True
    priority: int = 100
    appium_device_name: str = "Android"
    appium_platform_name: str = "Android"
    appium_automation_name: str = "UiAutomator2"
    appium_no_reset: bool = True
    appium_new_command_timeout: int = 120


@dataclass(slots=True)
class FleetConfig:
    """Top-level experiment settings for a synchronized device group."""

    experiment_name: str
    sync_device_limit: int
    max_device_limit: int
    run_duration_seconds: int
    action_timeout_seconds: float
    stalled_threshold_seconds: float
    recovery_retry_limit: int
    per_action_timeout_seconds: float = 20.0
    per_dwell_extra_timeout_seconds: float = 8.0
    network_slow_threshold_seconds: float = 12.0
    video_signature_stall_limit: int = 2
    capture_page_failure_limit: int = 2
    max_consecutive_failures: int = 3
    quarantine_failed_devices: bool = True
    quarantine_duration_seconds: int = 0
    session_reconnect_enabled: bool = True
    recovery_back_press_limit: int = 3
    restart_app_on_foreground_lost: bool = True
    timeline_scheduler_enabled: bool = True
    scheduling_round_seconds: int = 180
    max_page_turns_per_window: int = 3
    page_turn_window_seconds: int = 3
    network_adaptive_enabled: bool = True
    network_sample_interval_seconds: float = 5.0
    network_probe_host: str = "223.5.5.5"
    network_ping_timeout_ms: int = 800
    network_warn_ping_ms: float = 120.0
    network_congested_ping_ms: float = 250.0
    network_congested_device_ratio: float = 0.5
    network_min_slow_devices: int = 2
    min_devices_on_congestion: int = 3
    recovery_rounds_before_add: int = 2
    network_temp_cleanup: bool = True
    capture_repair_on_start: bool = True
    external_artifact_root: str = ""
    dwell_min_seconds: int = 15
    dwell_max_seconds: int = 40
    enable_like: bool = False
    enable_favorite: bool = False
    automatic_engagement_enabled: bool = True
    record_like_window: bool = True
    record_favorite_window: bool = True
    like_schedule_min_seconds: int = 5
    like_schedule_max_seconds: int = 15
    favorite_schedule_min_seconds: int = 16
    favorite_schedule_max_seconds: int = 55
    engagement_marker_window_seconds: float = 1.0
    real_capture_enabled: bool = True
    capture_backend: str = "pktmon"
    capture_file_size_mb: int = 512
    capture_pkt_size_bytes: int = 0
    page_guard_enabled: bool = True
    page_guard_skip_product_pages: bool = True
    page_guard_skip_ad_pages: bool = True
    page_guard_skip_live_pages: bool = True
    page_guard_recover_non_feed_pages: bool = True
    page_guard_max_skip_attempts: int = 3
    page_guard_keep_alive_check_interval_seconds: int = 5
    page_guard_unknown_page_policy: str = "skip_once_then_recover"
    safe_action_sequence: list[str] = field(default_factory=list)
    devices: list[DeviceProfile] = field(default_factory=list)


class FleetConfigLoader:
    """Load fleet config from a JSON file so experiments stay reproducible."""

    def load(self, config_path: str) -> FleetConfig:
        path = Path(config_path)
        payload = json.loads(path.read_text(encoding="utf-8"))
        devices = [self._build_device_profile(item) for item in payload.get("devices", [])]
        return FleetConfig(
            experiment_name=str(payload.get("experiment_name", "multi_device_trial")),
            sync_device_limit=int(payload.get("sync_device_limit", 3)),
            max_device_limit=int(payload.get("max_device_limit", max(3, len(devices)))),
            run_duration_seconds=int(payload.get("run_duration_seconds", 180)),
            action_timeout_seconds=float(payload.get("action_timeout_seconds", 12.0)),
            stalled_threshold_seconds=float(payload.get("stalled_threshold_seconds", 18.0)),
            recovery_retry_limit=int(payload.get("recovery_retry_limit", 2)),
            per_action_timeout_seconds=float(payload.get("per_action_timeout_seconds", 20.0)),
            per_dwell_extra_timeout_seconds=float(payload.get("per_dwell_extra_timeout_seconds", 8.0)),
            network_slow_threshold_seconds=float(payload.get("network_slow_threshold_seconds", 12.0)),
            video_signature_stall_limit=int(payload.get("video_signature_stall_limit", 2)),
            capture_page_failure_limit=int(payload.get("capture_page_failure_limit", 2)),
            max_consecutive_failures=int(payload.get("max_consecutive_failures", 3)),
            quarantine_failed_devices=bool(payload.get("quarantine_failed_devices", True)),
            quarantine_duration_seconds=int(payload.get("quarantine_duration_seconds", 0)),
            session_reconnect_enabled=bool(payload.get("session_reconnect_enabled", True)),
            recovery_back_press_limit=int(payload.get("recovery_back_press_limit", 3)),
            restart_app_on_foreground_lost=bool(payload.get("restart_app_on_foreground_lost", True)),
            timeline_scheduler_enabled=bool(payload.get("timeline_scheduler_enabled", True)),
            scheduling_round_seconds=int(payload.get("scheduling_round_seconds", 180)),
            max_page_turns_per_window=int(payload.get("max_page_turns_per_window", 3)),
            page_turn_window_seconds=int(payload.get("page_turn_window_seconds", 3)),
            network_adaptive_enabled=bool(payload.get("network_adaptive_enabled", True)),
            network_sample_interval_seconds=float(payload.get("network_sample_interval_seconds", 5.0)),
            network_probe_host=str(payload.get("network_probe_host", "223.5.5.5")),
            network_ping_timeout_ms=int(payload.get("network_ping_timeout_ms", 800)),
            network_warn_ping_ms=float(payload.get("network_warn_ping_ms", 120.0)),
            network_congested_ping_ms=float(payload.get("network_congested_ping_ms", 250.0)),
            network_congested_device_ratio=float(payload.get("network_congested_device_ratio", 0.5)),
            network_min_slow_devices=int(payload.get("network_min_slow_devices", 2)),
            min_devices_on_congestion=int(payload.get("min_devices_on_congestion", 3)),
            recovery_rounds_before_add=int(payload.get("recovery_rounds_before_add", 2)),
            network_temp_cleanup=bool(payload.get("network_temp_cleanup", True)),
            capture_repair_on_start=bool(payload.get("capture_repair_on_start", True)),
            external_artifact_root=str(payload.get("external_artifact_root", "")),
            dwell_min_seconds=int(payload.get("dwell_min_seconds", 15)),
            dwell_max_seconds=int(payload.get("dwell_max_seconds", 40)),
            enable_like=bool(payload.get("enable_like", False)),
            enable_favorite=bool(payload.get("enable_favorite", False)),
            automatic_engagement_enabled=bool(payload.get("automatic_engagement_enabled", True)),
            record_like_window=bool(payload.get("record_like_window", True)),
            record_favorite_window=bool(payload.get("record_favorite_window", True)),
            like_schedule_min_seconds=int(payload.get("like_schedule_min_seconds", 5)),
            like_schedule_max_seconds=int(payload.get("like_schedule_max_seconds", 15)),
            favorite_schedule_min_seconds=int(payload.get("favorite_schedule_min_seconds", 16)),
            favorite_schedule_max_seconds=int(payload.get("favorite_schedule_max_seconds", 55)),
            engagement_marker_window_seconds=float(payload.get("engagement_marker_window_seconds", 1.0)),
            real_capture_enabled=bool(payload.get("real_capture_enabled", True)),
            capture_backend=str(payload.get("capture_backend", "pktmon")),
            capture_file_size_mb=int(payload.get("capture_file_size_mb", 512)),
            capture_pkt_size_bytes=int(payload.get("capture_pkt_size_bytes", 0)),
            page_guard_enabled=bool(payload.get("page_guard_enabled", True)),
            page_guard_skip_product_pages=bool(payload.get("page_guard_skip_product_pages", True)),
            page_guard_skip_ad_pages=bool(payload.get("page_guard_skip_ad_pages", True)),
            page_guard_skip_live_pages=bool(payload.get("page_guard_skip_live_pages", True)),
            page_guard_recover_non_feed_pages=bool(payload.get("page_guard_recover_non_feed_pages", True)),
            page_guard_max_skip_attempts=int(payload.get("page_guard_max_skip_attempts", 3)),
            page_guard_keep_alive_check_interval_seconds=int(
                payload.get("page_guard_keep_alive_check_interval_seconds", 5)
            ),
            page_guard_unknown_page_policy=str(
                payload.get("page_guard_unknown_page_policy", "skip_once_then_recover")
            ),
            safe_action_sequence=[str(item) for item in payload.get("safe_action_sequence", [])],
            devices=devices,
        )

    @staticmethod
    def _build_device_profile(payload: dict[str, object]) -> DeviceProfile:
        return DeviceProfile(
            udid=str(payload["udid"]),
            device_alias=str(payload.get("device_alias", payload["udid"])),
            appium_server_url=str(payload.get("appium_server_url", "http://127.0.0.1:4723/wd/hub")),
            system_port=int(payload.get("system_port", 8200)),
            target_app_package=str(payload.get("target_app_package", "")),
            target_app_activity=str(payload.get("target_app_activity", "")),
            enabled=bool(payload.get("enabled", True)),
            priority=int(payload.get("priority", 100)),
            appium_device_name=str(payload.get("appium_device_name", "Android")),
            appium_platform_name=str(payload.get("appium_platform_name", "Android")),
            appium_automation_name=str(payload.get("appium_automation_name", "UiAutomator2")),
            appium_no_reset=bool(payload.get("appium_no_reset", True)),
            appium_new_command_timeout=int(payload.get("appium_new_command_timeout", 120)),
        )
