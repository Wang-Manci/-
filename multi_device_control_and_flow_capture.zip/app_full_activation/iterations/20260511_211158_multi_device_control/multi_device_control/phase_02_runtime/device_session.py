from __future__ import annotations

import time
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from full_activation.core.edge_classifier_v2 import describe_scene, infer_scene

from .device_state_monitor import DeviceHealthState, DeviceSessionStatus, DeviceStateMonitor

if TYPE_CHECKING:
    from .device_adapter_v2 import DeviceAdapterV2
    from .fleet_config import DeviceProfile


class DeviceSession:
    """Own one device runtime and expose stable control operations."""

    def __init__(self, profile: "DeviceProfile", adapter: "DeviceAdapterV2", state_monitor: DeviceStateMonitor) -> None:
        self.profile = profile
        self.adapter = adapter
        self.state_monitor = state_monitor
        self.status = DeviceSessionStatus(udid=profile.udid, health_state=DeviceHealthState.INIT)
        self.last_snapshot = None
        self.action_started_at: float = 0.0

    @property
    def recovery_attempts(self) -> int:
        return self.status.recovery_attempts

    def connect(self) -> bool:
        self.status.health_state = DeviceHealthState.CONNECTING
        try:
            self.adapter.connect()
            self.record_action_success()
            self.status.last_heartbeat_ts = time.time()
            return True
        except Exception as exc:
            self.record_action_failure(str(exc), category="connect_failed", health_state=DeviceHealthState.FAILED)
            self.status.last_heartbeat_ts = time.time()
            return False

    def disconnect(self) -> None:
        self.adapter.close()
        self.status.health_state = DeviceHealthState.OFFLINE
        self.status.last_heartbeat_ts = time.time()

    def refresh_state(self) -> DeviceSessionStatus:
        return self.state_monitor.evaluate(self)

    def ensure_ready(self) -> bool:
        status = self.refresh_state()
        if status.health_state == DeviceHealthState.QUARANTINED:
            return False
        if status.health_state == DeviceHealthState.READY:
            return True
        if status.health_state in {DeviceHealthState.INIT, DeviceHealthState.OFFLINE}:
            return self.connect()
        if status.health_state in {DeviceHealthState.NETWORK_SLOW, DeviceHealthState.STALLED}:
            return self.recover("ensure_ready_after_stall")
        return status.health_state == DeviceHealthState.READY

    def capture_page(self):
        try:
            snapshot = self.adapter.get_current_page()
            scene = infer_scene(snapshot)
            self.last_snapshot = snapshot
            self.status.last_scene = describe_scene(scene)
            self.status.capture_page_failures = 0
            self.status.last_heartbeat_ts = time.time()
            return snapshot
        except Exception as exc:
            self.status.capture_page_failures += 1
            self.status.last_error = str(exc)
            self.status.last_failure_category = "capture_page_failed"
            self.status.last_heartbeat_ts = time.time()
            raise

    def ensure_feed_ready(self) -> bool:
        if not self.ensure_ready():
            return False
        self.status.last_action = "ensure_feed_ready"
        self.status.health_state = DeviceHealthState.BUSY
        self.touch_heartbeat()
        try:
            success = self.adapter.recover_to_feed()
            if success:
                self.record_action_success()
            else:
                self.record_action_failure(
                    self.status.last_error or "ensure_feed_ready_failed",
                    category="feed_recover_failed",
                )
            self.touch_heartbeat()
            return success
        except Exception as exc:
            self.record_action_failure(str(exc), category="feed_recover_exception", health_state=DeviceHealthState.FAILED)
            self.status.last_heartbeat_ts = time.time()
            return False

    def touch_heartbeat(self) -> None:
        self.status.last_heartbeat_ts = time.time()

    def record_action_success(self, video_signature: str = "") -> None:
        if self.status.health_state == DeviceHealthState.QUARANTINED:
            return
        self.status.health_state = DeviceHealthState.READY
        self.status.last_error = ""
        self.status.last_failure_category = ""
        self.status.recovery_attempts = 0
        self.status.consecutive_failures = 0
        self.status.capture_page_failures = 0
        self.status.signature_stall_count = 0
        if video_signature:
            self.status.last_video_signature = video_signature
        self.status.last_success_ts = time.time()
        self.touch_heartbeat()

    def record_action_failure(
        self,
        error_message: str,
        category: str = "action_failed",
        health_state: DeviceHealthState = DeviceHealthState.STALLED,
    ) -> None:
        if self.status.health_state == DeviceHealthState.QUARANTINED:
            return
        self.status.consecutive_failures += 1
        self.status.last_error = error_message
        self.status.last_failure_category = category
        self.status.health_state = health_state
        self.touch_heartbeat()

    def record_network_slow(self, error_message: str = "network_slow") -> None:
        self.record_action_failure(
            error_message,
            category="network_slow",
            health_state=DeviceHealthState.NETWORK_SLOW,
        )

    def record_video_signature(self, video_signature: str) -> None:
        if not video_signature:
            return
        if self.status.last_video_signature == video_signature:
            self.status.signature_stall_count += 1
        else:
            self.status.last_video_signature = video_signature
            self.status.signature_stall_count = 0

    def quarantine(self, reason: str, duration_seconds: int = 0) -> None:
        self.status.health_state = DeviceHealthState.QUARANTINED
        self.status.last_error = reason
        self.status.last_failure_category = "quarantined"
        self.status.quarantined_until_ts = time.time() + duration_seconds if duration_seconds > 0 else 0.0
        self.touch_heartbeat()

    def recover(self, reason: str) -> bool:
        self.status.health_state = DeviceHealthState.RECOVERING
        self.status.recovery_attempts += 1
        self.status.last_recovery_level = reason
        try:
            if not self.adapter.is_connected:
                return self.connect()
            recovered = self.adapter.recover_target_app(reason=reason)
        except Exception as exc:
            recovered = False
            self.status.last_error = str(exc)
        if recovered:
            self.record_action_success()
        else:
            self.record_action_failure(
                self.status.last_error or f"recover_failed:{reason}",
                category="recovery_failed",
                health_state=DeviceHealthState.FAILED,
            )
        self.status.last_heartbeat_ts = time.time()
        return recovered

    def snapshot_status(self) -> dict[str, Any]:
        payload = asdict(self.status)
        payload["device_alias"] = self.profile.device_alias
        payload["foreground_package"] = self._safe_foreground_package()
        return payload

    def _safe_foreground_package(self) -> str:
        try:
            return self.adapter.get_foreground_package()
        except Exception:
            return ""
