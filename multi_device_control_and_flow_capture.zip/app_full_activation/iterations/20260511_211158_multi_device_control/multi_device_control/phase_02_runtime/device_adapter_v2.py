from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING

from full_activation.automation.device_adapter import AppiumDeviceAdapter
from full_activation.config import DeviceConfig

from .fleet_config import DeviceProfile

if TYPE_CHECKING:
    from multi_device_control.phase_06_entry_and_artifacts.artifact_registry import ArtifactRegistry


class PatchedAppiumDeviceAdapter(AppiumDeviceAdapter):
    """Local adapter variant that relaxes newer Android hidden API policy setup."""

    def _create_driver(self):
        try:
            from appium import webdriver
            from appium.options.android import UiAutomator2Options
        except ImportError as exc:
            raise RuntimeError("Appium Python client is not installed. Run: pip install Appium-Python-Client") from exc

        if not self.config.app_package or not self.config.app_activity:
            raise ValueError("DeviceConfig.app_package and DeviceConfig.app_activity are required when use_mock=False")

        capabilities = {
            "platformName": self.config.platform_name,
            "automationName": self.config.automation_name,
            "deviceName": self.config.device_name,
            "appPackage": self.config.app_package,
            "appActivity": self.config.app_activity,
            "noReset": self.config.no_reset,
            "newCommandTimeout": self.config.new_command_timeout,
        }
        if self.config.udid:
            capabilities["udid"] = self.config.udid
            capabilities["deviceName"] = self.config.udid
        system_port = getattr(self.config, "system_port", 0)
        if system_port:
            capabilities["systemPort"] = int(system_port)
        capabilities["adbExecTimeout"] = 60000
        capabilities["androidDeviceReadyTimeout"] = 60

        options = UiAutomator2Options().load_capabilities(capabilities)
        if self.config.udid:
            options.set_capability("appium:udid", self.config.udid)
            options.set_capability("appium:deviceName", self.config.udid)
        if system_port:
            options.set_capability("appium:systemPort", int(system_port))
        options.set_capability("appium:adbExecTimeout", 60000)
        options.set_capability("appium:androidDeviceReadyTimeout", 60)
        # Android 13+ devices may reject these settings mutations. Let the session continue.
        options.set_capability("appium:ignoreHiddenApiPolicyError", True)
        options.set_capability("ignoreHiddenApiPolicyError", True)

        last_error: Exception | None = None
        for attempt in range(2):
            try:
                return webdriver.Remote(self.config.server_url, options=options)
            except Exception as exc:
                last_error = exc
                error_text = str(exc).lower()
                if "invalidsessionid" not in error_text and "session identified by" not in error_text:
                    raise
                time.sleep(1.5)
        assert last_error is not None
        raise last_error


class DeviceAdapterV2:
    """Thin compatibility wrapper around the legacy Appium adapter.

    The old adapter already knows how to capture pages, resolve controls,
    recover the app and dump debug artifacts. This wrapper reuses that logic
    while redirecting outputs into the timestamped experiment folder.
    """

    def __init__(self, profile: DeviceProfile, artifact_registry: "ArtifactRegistry") -> None:
        self.profile = profile
        self.artifact_registry = artifact_registry
        self._adapter: AppiumDeviceAdapter | None = None

    @property
    def is_connected(self) -> bool:
        return self._adapter is not None

    @property
    def driver(self):
        if self._adapter is None:
            raise RuntimeError(f"adapter for device {self.profile.udid} is not connected")
        return self._adapter.driver

    def connect(self) -> None:
        if self._adapter is not None:
            return
        self._adapter = PatchedAppiumDeviceAdapter(self._build_device_config())
        self._adapter.debug_path = Path(self.artifact_registry.page_debug_path(self.profile.udid))
        self._adapter.runtime_log_path = Path(self.artifact_registry.runtime_log_path(self.profile.udid))
        self._adapter.page_source_dir = Path(self.artifact_registry.page_source_dir(self.profile.udid))
        self._adapter._log(
            f"adapter-connected udid={self.profile.udid} package={self.profile.target_app_package} "
            f"server_url={self.profile.appium_server_url}"
        )

    def get_current_page(self):
        return self._require_adapter().get_current_page()

    def click_control(self, control_id: str) -> None:
        self._require_adapter().click_control(control_id)

    def input_text(self, control_id: str, value: str) -> None:
        self._require_adapter().input_text(control_id, value)

    def get_foreground_package(self) -> str:
        return getattr(self.driver, "current_package", "") or ""

    def go_back(self) -> None:
        self._require_adapter().go_back()

    def recover_target_app(self, reason: str = "") -> bool:
        return self._require_adapter().recover_target_app(reason=reason)

    def close(self) -> None:
        if self._adapter is None:
            return
        try:
            self._adapter.driver.quit()
        except Exception:
            pass
        self._adapter = None

    def _require_adapter(self) -> AppiumDeviceAdapter:
        if self._adapter is None:
            raise RuntimeError(f"adapter for device {self.profile.udid} is not connected")
        return self._adapter

    def _build_device_config(self) -> DeviceConfig:
        return DeviceConfig(
            use_mock=False,
            server_url=self.profile.appium_server_url,
            platform_name=self.profile.appium_platform_name,
            automation_name=self.profile.appium_automation_name,
            device_name=self.profile.appium_device_name,
            app_package=self.profile.target_app_package,
            app_activity=self.profile.target_app_activity,
            udid=self.profile.udid,
            system_port=self.profile.system_port,
            no_reset=self.profile.appium_no_reset,
            new_command_timeout=self.profile.appium_new_command_timeout,
        )
