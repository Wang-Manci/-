from __future__ import annotations

import hashlib
import re
import subprocess
import time
import xml.etree.ElementTree as ET

from full_activation.core.edge_classifier_v2 import infer_scene
from full_activation.models import ControlNode, PageSnapshot, SceneType

from .device_adapter_v2 import DeviceAdapterV2


class DeviceAdapterV3(DeviceAdapterV2):
    """Extend the legacy-compatible adapter with feed-oriented gestures."""

    _FEED_SCENES = {
        SceneType.FEED_HOME,
        SceneType.VIDEO_DETAIL,
    }

    def get_current_page(self):
        activity = self.get_foreground_activity() or self.profile.target_app_activity
        package_name = self.get_foreground_package() or self.profile.target_app_package
        try:
            xml_source = self._dump_ui_xml()
            root = ET.fromstring(xml_source)
            controls: list[ControlNode] = []
            component_types: list[str] = []
            form_fields: list[str] = []

            for index, node in enumerate(root.iter("node")):
                class_name = node.attrib.get("class", "")
                resource_id = node.attrib.get("resource-id", "")
                text = node.attrib.get("text", "") or node.attrib.get("content-desc", "")
                clickable = node.attrib.get("clickable", "false") == "true"
                bounds = node.attrib.get("bounds", "")
                content_desc = node.attrib.get("content-desc", "")
                control_id = self._build_dump_control_id(resource_id, content_desc, text, bounds, index)
                controls.append(
                    ControlNode(
                        control_id=control_id,
                        text=text,
                        type_name=class_name or "Unknown",
                        clickable=clickable,
                        resource_id=resource_id,
                        bounds=bounds,
                        route_target="",
                    )
                )
                if class_name and class_name not in component_types:
                    component_types.append(class_name)
                if "EditText" in class_name:
                    form_fields.append(control_id)

            title = next((control.text for control in controls if control.text.strip()), activity or package_name or "douyin")
            snapshot = PageSnapshot(
                page_name=activity or package_name or "douyin",
                route_name=activity or package_name or "douyin",
                source_digest=hashlib.sha1(xml_source.encode("utf-8")).hexdigest(),
                title=title,
                controls=controls,
                form_fields=form_fields,
                component_types=component_types,
                raw_source_excerpt=xml_source[:1000],
                package_name=package_name,
            )
            self._log_runtime(
                f"adb-snapshot-collected activity={activity or '-'} package={package_name or '-'} controls={len(controls)}"
            )
            return snapshot
        except Exception as exc:
            screenshot_digest = self._capture_screenshot_digest()
            self._log_runtime(
                f"adb-snapshot-fallback activity={activity or '-'} package={package_name or '-'} error={exc}"
            )
            return PageSnapshot(
                page_name=activity or package_name or "douyin",
                route_name=activity or package_name or "douyin",
                source_digest=screenshot_digest,
                title=activity or package_name or "douyin",
                controls=[],
                form_fields=[],
                component_types=[],
                raw_source_excerpt=f"screenshot_sha1:{screenshot_digest}",
                package_name=package_name,
            )

    def swipe_up(self, duration_ms: int = 350) -> None:
        driver = self.driver
        size = driver.get_window_size()
        width = int(size["width"])
        height = int(size["height"])
        start_x = width // 2
        start_y = int(height * 0.78)
        end_x = width // 2
        end_y = int(height * 0.28)
        if hasattr(driver, "swipe"):
            driver.swipe(start_x, start_y, end_x, end_y, duration_ms)
            return
        driver.execute_script(
            "mobile: swipeGesture",
            {
                "left": int(width * 0.1),
                "top": int(height * 0.2),
                "width": int(width * 0.8),
                "height": int(height * 0.6),
                "direction": "up",
                "percent": 0.75,
            },
        )

    def swipe_down(self, duration_ms: int = 350) -> None:
        driver = self.driver
        size = driver.get_window_size()
        width = int(size["width"])
        height = int(size["height"])
        start_x = width // 2
        start_y = int(height * 0.32)
        end_x = width // 2
        end_y = int(height * 0.82)
        if hasattr(driver, "swipe"):
            driver.swipe(start_x, start_y, end_x, end_y, duration_ms)
            return
        driver.execute_script(
            "mobile: swipeGesture",
            {
                "left": int(width * 0.1),
                "top": int(height * 0.2),
                "width": int(width * 0.8),
                "height": int(height * 0.6),
                "direction": "down",
                "percent": 0.75,
            },
        )

    def get_foreground_package(self) -> str:
        output = self._adb_shell(["dumpsys", "window", "windows"], timeout_seconds=8)
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if "mCurrentFocus" not in line and "mFocusedApp" not in line:
                continue
            package_match = re.search(r"([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)", line)
            if package_match:
                return package_match.group(1)
        return self.profile.target_app_package

    def get_foreground_activity(self) -> str:
        output = self._adb_shell(["dumpsys", "window", "windows"], timeout_seconds=8)
        for raw_line in output.splitlines():
            line = raw_line.strip()
            if "mCurrentFocus" not in line and "mFocusedApp" not in line:
                continue
            package_match = re.search(r"([A-Za-z0-9_.]+)/([A-Za-z0-9_.$]+)", line)
            if package_match:
                return package_match.group(2)
        return self.profile.target_app_activity

    def wait_for_feed_ready(self, timeout_seconds: float = 8.0) -> bool:
        self._log_runtime(f"wait-for-feed-start timeout_seconds={timeout_seconds}")
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            foreground_package = self.get_foreground_package()
            if foreground_package != self.profile.target_app_package:
                self._log_runtime(
                    f"wait-for-feed-foreground-mismatch current={foreground_package or '-'} "
                    f"target={self.profile.target_app_package}"
                )
                time.sleep(0.8)
                continue
            try:
                snapshot = self.get_current_page()
            except Exception as exc:
                self._log_runtime(f"wait-for-feed-snapshot-failed error={exc}")
                time.sleep(0.8)
                continue
            scene = infer_scene(snapshot)
            self._log_runtime(f"wait-for-feed-scene scene={scene.scene_type.value}")
            if scene.scene_type in self._FEED_SCENES:
                self._log_runtime("wait-for-feed-success")
                return True
            if snapshot.package_name == self.profile.target_app_package and snapshot.raw_source_excerpt.startswith("screenshot_sha1:"):
                self._log_runtime("wait-for-feed-success-screenshot-fallback")
                return True
            time.sleep(0.8)
        self._log_runtime("wait-for-feed-timeout")
        return False

    def recover_to_feed(self) -> bool:
        self._log_runtime("recover-to-feed-start")
        if self.get_foreground_package() != self.profile.target_app_package:
            self._log_runtime("recover-to-feed-activate-app")
            if not self.recover_target_app("recover_to_feed"):
                self._log_runtime("recover-to-feed-activate-failed")
                return False
        if self.wait_for_feed_ready(timeout_seconds=10.0):
            self._log_runtime("recover-to-feed-success-initial")
            return True
        for _ in range(3):
            try:
                self._log_runtime("recover-to-feed-go-back")
                self.go_back()
            except Exception:
                pass
            time.sleep(1.0)
            if self.wait_for_feed_ready(timeout_seconds=4.0):
                self._log_runtime("recover-to-feed-success-back")
                return True
        if self.recover_target_app("recover_to_feed_final"):
            self._log_runtime("recover-to-feed-final-activate")
            return self.wait_for_feed_ready(timeout_seconds=8.0)
        self._log_runtime("recover-to-feed-failed")
        return False

    def _log_runtime(self, message: str) -> None:
        try:
            self._require_adapter()._log(message)
        except Exception:
            return

    def _dump_ui_xml(self) -> str:
        dump_target = "/sdcard/window_dump.xml"
        self._adb_shell(["uiautomator", "dump", dump_target], timeout_seconds=12)
        xml_source = self._adb_shell(["cat", dump_target], timeout_seconds=12)
        xml_source = xml_source.strip()
        if not xml_source.startswith("<?xml"):
            start = xml_source.find("<?xml")
            if start >= 0:
                xml_source = xml_source[start:]
        if not xml_source:
            raise RuntimeError("uiautomator_dump_empty")
        return xml_source

    def _adb_shell(self, shell_args: list[str], timeout_seconds: int = 10) -> str:
        command = ["adb", "-s", self.profile.udid, "shell", *shell_args]
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
        if completed.returncode != 0:
            raise RuntimeError(completed.stderr.strip() or completed.stdout.strip() or "adb_shell_failed")
        return completed.stdout

    def _capture_screenshot_digest(self) -> str:
        completed = subprocess.run(
            ["adb", "-s", self.profile.udid, "exec-out", "screencap", "-p"],
            capture_output=True,
            timeout=12,
            check=False,
        )
        if completed.returncode != 0 or not completed.stdout:
            raise RuntimeError(completed.stderr.decode("utf-8", errors="replace").strip() or "screencap_failed")
        return hashlib.sha1(completed.stdout).hexdigest()

    @staticmethod
    def _build_dump_control_id(resource_id: str, content_desc: str, text: str, bounds: str, index: int) -> str:
        if resource_id:
            return f"resource-id:{resource_id}"
        if content_desc:
            return f"accessibility:{content_desc}"
        if text:
            return f"text:{text}"
        if bounds:
            return f"bounds:{bounds}"
        return f"xpath-index:{index}"
