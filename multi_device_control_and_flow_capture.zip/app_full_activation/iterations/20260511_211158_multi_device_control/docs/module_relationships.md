# Module Relationships

```mermaid
graph TD
  A["main_group_control.py"] --> B["run_three_device_trial.py"]
  B --> C["FleetConfigLoader"]
  B --> D["ArtifactRegistry"]
  B --> E["DeviceInventoryService"]
  B --> F["SessionFactory"]
  B --> G["ActionSemanticBridge"]
  B --> H["SyncGroupController"]
  B --> I["RecoveryPolicy"]
  B --> J["DistributedFallbackController"]
  B --> K["StatusSnapshotWriter"]
  B --> L["GroupOrchestrator"]
  F --> M["DeviceSession"]
  M --> N["DeviceAdapterV2"]
  M --> O["DeviceStateMonitor"]
  N --> P["Legacy AppiumDeviceAdapter"]
  G --> Q["Legacy edge_classifier_v2"]
```

## Layer Summary
- `phase_01_inventory`: host-side adb discovery and precheck facts.
- `phase_02_runtime`: config, session lifecycle, adapter reuse, and health evaluation.
- `phase_03_actions`: safe action requests mapped into per-device page actions.
- `phase_04_control`: synchronized execution and experiment orchestration.
- `phase_05_control_fallback`: retry and degraded execution path.
- `phase_06_entry_and_artifacts`: entry scripts and artifact persistence.

## Runtime Data Flow
1. `FleetConfigLoader` reads experiment config.
2. `DeviceInventoryService` builds the current device inventory.
3. `SessionFactory` filters config devices against eligible inventory rows.
4. `GroupOrchestrator` connects sessions and drives the action sequence.
5. `SyncGroupController` broadcasts safe actions to ready sessions.
6. `DistributedFallbackController` takes over when stalled devices appear.
7. `StatusSnapshotWriter` writes per-device and experiment snapshots.
