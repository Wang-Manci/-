# Multi-Device Control Design Overview

## Goals
- Preserve the original `full_activation` code untouched.
- Build all new code under a timestamped experiment directory.
- Add independent adb inventory in a standalone Python file.
- Add multi-device session management, status detection, synchronized control, and distributed fallback.
- Delay traffic collection until basic automation control is verified.

## Scope
- Safe multi-device UI automation for connection governance and smoke-test navigation.
- Reuse the old Appium page capture and scene/action parsing logic where that reduces migration risk.
- Persist outputs under a shared experiment artifact root.

## Out of Scope for This Iteration
- Rewriting the legacy explorer.
- Replacing the old reporting and LLM analysis modules.
- Tight coupling to the old `main.py` output lifecycle.

## Key Design Choices
1. `device_inventory.py` is fully independent from the old runtime so precheck can run even when Appium is unavailable.
2. `DeviceAdapterV2` reuses the legacy `AppiumDeviceAdapter` instead of duplicating its page parsing logic.
3. `DeviceSession` owns lifecycle, health state, and per-device recovery attempts.
4. `SyncGroupController` runs actions in parallel and `DistributedFallbackController` keeps healthy devices progressing after stalls.
5. Artifacts are managed through one shared registry to avoid accidental filename collisions.
