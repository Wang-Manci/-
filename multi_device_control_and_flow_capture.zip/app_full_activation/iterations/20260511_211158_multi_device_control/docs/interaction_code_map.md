# Interaction Code Map

This file marks where the current project touches like, favorite, and comment related logic.

## New iteration folder

- `multi_device_control/phase_03_actions/douyin_action_executor.py`
  - `ensure_feed()` and `swipe_next_video()` are the active smoke-test actions.
  - `like_current_video()` taps the `video_like` candidate, with `live_like` as a fallback, when `enable_like` is true.
  - `comment_current_video()` is the reserved comment-action slot and now raises `disabled_by_policy`.
  - `favorite_current_video()` taps the `video_favorite` candidate when `enable_favorite` is true.

- `multi_device_control/phase_03_actions/action_semantic_bridge.py`
  - Adds direct safe actions:
    - `like_current_video`
    - `favorite_current_video`
  - Allows semantic taps for:
    - `video_like`
    - `live_like`
    - `video_favorite`

- `config/fleet_config.sample.json`
  - `enable_like` and `enable_favorite` are the current feature flags.
  - Both remain `false` by default and must be enabled explicitly for engagement actions.

## Legacy recognition and traffic semantics

- `full_activation/core/edge_classifier_v2.py`
  - `build_action_candidates()` adds the legacy semantic candidates:
    - `video_like`
    - `video_favorite`
    - `open_comment`
    - `video_share`
  - `_pick_comment_control()` is the legacy comment-panel control picker.
  - `_pick_share_control()` is the legacy share control picker.

- `full_activation/core/explorer.py`
  - `_execute_click_step()` treats these semantics as meaningful even if page signature does not change:
    - `video_like`
    - `video_favorite`
    - `live_like`
    - `video_share`
    - `product_share`
  - `_emit_semantic_event()` maps the legacy semantics to traffic labels:
    - `video_like`
    - `video_favorite`
    - `open_comment`
    - `video_share`

## Current status

- Like and favorite execution are now wired into the new multi-device framework behind `enable_like` and `enable_favorite`.
- The reserved comment method still raises `disabled_by_policy` if called.
- Comment handling is currently limited to legacy semantic discovery (`open_comment`) and is not wired into the new smoke-test runner.
- The new smoke-test runner currently validates:
  - feed recovery
  - swipe to next video
  - dwell timing window
  - traffic-window logging
